import { getContext, setCurrentContext } from "./core/request-context.js";
import {
  usePathname,
  useSearchParams,
  useRouter,
  useNavigationLoading,
} from "./core/navigation.js";
import { redirect } from "./core/redirect.jsx";
import { ClientRedirect } from "./core/client-redirect.jsx";
import { Link } from "./core/link.jsx";

function defineConfig(config) {
  return config;
}

const dinou = {
  defineConfig,
  getContext,
  setCurrentContext,
  usePathname,
  useSearchParams,
  useRouter,
  useNavigationLoading,
  redirect,
  ClientRedirect,
  Link,
};

export {
  defineConfig,
  getContext,
  setCurrentContext,
  usePathname,
  useSearchParams,
  useRouter,
  useNavigationLoading,
  redirect,
  ClientRedirect,
  Link,
};

export default dinou;
