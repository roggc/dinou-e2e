// dinou/node/build.js
// Dual-Bundle Build script for packaging Dinou for Node.js (Pre-bundled AOT Standalone).
// Pass A & Pass B: Handled via bundleDualEngine
// Pass C: Main Node Orchestrator (.dinou/node/server.js)

import fs from "node:fs";
import path from "node:path";
import esbuild from "esbuild";
import { fileURLToPath } from "node:url";
import {
  bundleDualEngine,
  bundleServerAndNetlifyAdapters,
} from "./bundle-dual-engine.js";
import { loadEnvFiles } from "../core/env.js";
import ensureVendorMode from "../core/ensure-vendor-mode.js";
loadEnvFiles(process.cwd(), { mode: "production" });
if (!ensureVendorMode()) {
  await new Promise(() => {});
}

const projectRoot = process.cwd();
const nodeDir = path.resolve(projectRoot, ".dinou/node");
fs.mkdirSync(nodeDir, { recursive: true });

try {
  const bundlerName = process.env.DINOU_BUILD_TOOL || "esbuild";
  console.log(`\n🦖 Dinou (Node.js • ${bundlerName})`);
  console.log(`  ⚡ Compiling Pass A (RSC) and Pass B (SSR) via Dual-Engine...`);
  const engineResult = await bundleDualEngine({
    isDev: false,
    projectRoot,
    outDir: ".dinou/node",
  });
  await bundleServerAndNetlifyAdapters(engineResult);

  const {
    dinouDirSlash,
    externalList,
    banner,
    commonAlias,
    commonLoader,
    serverAssetPlugin,
    serverTsconfigAliasesPlugin,
    isWebpackBuild,
    setupFiles,
    configFile,
  } = engineResult;

  // Pass A (./rsc-engine.mjs) already bundles dinou.config with react-server +
  // clientReferencesPlugin and populates globalThis.__DINOU_AOT_CONFIG__ / __DINOU_CONFIG__.
  // Reading the RSC-compiled config from globalThis avoids duplicate config execution and
  // prevents Pass C from bundling a non-RSC copy of cache-revalidate.js / slot.js.
  const nodeConfigImportLine = `const __bundledDinouConfig = (typeof globalThis !== "undefined" && (globalThis.__DINOU_AOT_CONFIG__ || globalThis.__DINOU_CONFIG__)) || { plugins: [] };\n`;

  // Pass C: Node Orchestrator Entry
  const nodeEntryContent = `// Auto-generated main entry for Node.js (Dual-Bundle)
import http from "node:http";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { Readable } from "node:stream";
import { handleRequest } from "./rsc-engine.mjs";
import { renderHtml } from "./ssr-engine.mjs";
import {
  setStorageAdapter,
  hasExplicitStorageAdapter,
  FileSystemStorage,
  MemoryStorage,
} from "${dinouDirSlash}/core/storage-adapter.js";
import {
  nodeToWebRequest,
  sendWebResponseToNode,
} from "${dinouDirSlash}/core/http-adapter.js";
import {
  runNodeMiddlewares,
  applyConfigureServerPlugins,
} from "${dinouDirSlash}/core/node-middleware-runner.js";
import {
  getStaticContentType,
  getStaticCacheControl,
  normalizePublicRequestPath,
  parseHttpByteRange,
  resolveConfinedStaticFile,
} from "${dinouDirSlash}/core/static-assets.js";
import { loadEnvFiles } from "${dinouDirSlash}/core/env.js";
${nodeConfigImportLine}

const initialCwd = typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : ".";
loadEnvFiles(initialCwd, { mode: "production" });

if (typeof globalThis !== "undefined") {
  globalThis.__DINOU_RUNTIME__ = "node-bundle";
}

let storageInitialized = false;

function initStorage() {
  if (!storageInitialized) {
    if (!hasExplicitStorageAdapter()) {
      try {
        const cwd = typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : ".";
        const dist2Dir = path.resolve(cwd, ".dinou/dist2");
        setStorageAdapter(new FileSystemStorage(dist2Dir));
      } catch (e) {
        setStorageAdapter(new MemoryStorage());
      }
    }
    storageInitialized = true;
  }
}

const cwd = typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : ".";
const dist3Dir = path.resolve(cwd, ".dinou/dist3");

export async function fetch(req) {
  initStorage();

  const url = new URL(req.url);
  const pathname = url.pathname;

  // Static assets delivery (Zero-copy with Node streams)
  if (req.method === "GET" || req.method === "HEAD") {
    const cleanPath = normalizePublicRequestPath(pathname);
    if (cleanPath) {
      const filePath = resolveConfinedStaticFile(dist3Dir, cleanPath);
      if (filePath && fs.existsSync(filePath)) {
        try {
          const stat = fs.statSync(filePath);
          if (stat.isFile()) {
            const contentType = getStaticContentType(cleanPath);
            const cacheControl = getStaticCacheControl(cleanPath);
            const rangeHeader = req.method === "GET" ? req.headers.get("range") : null;
            const range = rangeHeader ? parseHttpByteRange(rangeHeader, stat.size) : null;

            if (range && range.unsatisfiable) {
              return new Response(null, {
                status: 416,
                headers: {
                  "content-range": range.contentRange,
                  "accept-ranges": "bytes",
                },
              });
            }

            if (range) {
              const stream = fs.createReadStream(filePath, {
                start: range.start,
                end: range.end,
              });
              return new Response(Readable.toWeb(stream), {
                status: 206,
                headers: {
                  "content-type": contentType,
                  "content-length": String(range.length),
                  "content-range": range.contentRange,
                  "accept-ranges": "bytes",
                  "cache-control": cacheControl,
                },
              });
            }

            const body =
              req.method === "HEAD"
                ? null
                : Readable.toWeb(fs.createReadStream(filePath));
            return new Response(body, {
              headers: {
                "content-type": contentType,
                "content-length": String(stat.size),
                "accept-ranges": "bytes",
                "cache-control": cacheControl,
              },
            });
          }
        } catch (e) {}
      }
    }
  }

  return handleRequest(req, {
    runtime: "node-bundle",
    renderHtmlStream: renderHtml,
  });
}

const PORT = Number(process.env.PORT || 3000);

const nodeMiddlewares = [];

export async function startServer(port = PORT, host = process.env.HOST || undefined) {
  const server = http.createServer(async (req, res) => {
    try {
      if (res.writableEnded || res.headersSent || res.destroyed) {
        return;
      }

      if (nodeMiddlewares.length > 0) {
        const shouldContinue = await runNodeMiddlewares(nodeMiddlewares, req, res);
        if (!shouldContinue || res.writableEnded || res.headersSent || res.destroyed) {
          return;
        }
      }

      const webReq = nodeToWebRequest(req);
      const webRes = await fetch(webReq);
      if (!res.writableEnded && !res.headersSent && !res.destroyed) {
        await sendWebResponseToNode(webRes, res);
      }
    } catch (err) {
      console.error("[Dinou Node Server] Request error:", err);
      if (!res.headersSent) {
        res.statusCode = 500;
        res.setHeader("content-type", "text/plain; charset=utf-8");
        res.end("Internal Server Error");
      } else if (!res.writableEnded && !res.destroyed) {
        res.end();
      }
    }
  });

  if (__bundledDinouConfig && Array.isArray(__bundledDinouConfig.plugins)) {
    await applyConfigureServerPlugins({
      plugins: __bundledDinouConfig.plugins,
      server,
      isDev: false,
      middlewares: nodeMiddlewares,
    });
  }

  return new Promise((resolve, reject) => {
    server.on("error", reject);
    server.listen(port, host, () => {
      console.log(\`🚀 Dinou (Node.js AOT Dual-Bundle) server running on http://\${host || "localhost"}:\${port}\`);
      resolve(server);
    });
  });
}

export default {
  port: PORT,
  startServer,
};

const isMain = Boolean(
  (typeof import.meta !== "undefined" && import.meta.main) ||
  (typeof process !== "undefined" &&
    process.argv[1] &&
    (path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))))
);

if (isMain) {
  startServer(PORT);
}

`;
  const nodeEntryPath = path.join(nodeDir, "node-entry.mjs");
  fs.writeFileSync(nodeEntryPath, nodeEntryContent, "utf8");

  const passCConfigAliasPlugin = configFile
    ? {
        name: "dinou-passc-config-alias",
        setup(build) {
          const normConfig = path.resolve(configFile).toLowerCase();
          build.onResolve({ filter: /^dinou$/ }, (args) => {
            if (
              args.importer &&
              path.resolve(args.importer).toLowerCase() === normConfig
            ) {
              return { path: path.resolve(dinouDirSlash, "core/config.js") };
            }
            return null;
          });
        },
      }
    : null;

  // Pass C: Final Node Orchestrator
  const finalOutfile = path.join(nodeDir, "server.mjs");
  console.log("  🚀 Bundling Pass C: Node Orchestrator (.dinou/node/server.mjs)...");
  await esbuild.build({
    entryPoints: [nodeEntryPath],
    outfile: finalOutfile,
    bundle: true,
    format: "esm",
    target: "node20",
    platform: "node",
    jsx: "automatic",
    mainFields: ["module", "main"],
    conditions: ["node", "worker", "browser"],
    external: [...externalList, "./rsc-engine.mjs", "./ssr-engine.mjs"],
    banner,
    plugins: [
      passCConfigAliasPlugin,
      serverTsconfigAliasesPlugin,
      serverAssetPlugin,
    ].filter(Boolean),
    alias: commonAlias,
    loader: commonLoader,
    define: {
      "process.env.NODE_ENV": '"production"',
      "process.env.DINOU_RUNTIME": '"node-bundle"',
      "process.env.DINOU_BUILD_TOOL": JSON.stringify(isWebpackBuild ? "webpack" : (process.env.DINOU_BUILD_TOOL || "esbuild")),
    },
    logLevel: "warning",
  });

  const relOutfile = path.relative(projectRoot, finalOutfile).replace(/\\/g, "/");
  console.log(`\n✓ Node.js production build complete!`);
  console.log(`  Output: ${relOutfile}`);
  console.log(`  👉 Run with: npm start  (or node ${relOutfile})\n`);
} catch (err) {
  console.error("❌ [Dinou Node] Build failed:", err);
  process.exit(1);
}
