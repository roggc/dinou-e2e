// dinou/node/bundle-dual-engine.mjs
// Reusable Dual-Bundle Compiler for Dinou:
// Compiles Pass A (RSC Engine) and Pass B (SSR Engine) using esbuild
// in a single process without React collisions.

import fs from "node:fs";
import path from "node:path";
import esbuild from "esbuild";
import { fileURLToPath, pathToFileURL } from "node:url";

import { generateRouteModulesCode, generateRouteTypes } from "../core/route-generator.js";
import parseExports from "../core/parse-exports.js";
import { useClientRegex, useServerRegex } from "../constants.js";
import { transformServerFunctions, hasServerFunctions } from "../core/transform-server-functions.js";
import createScopedName from "../core/createScopedName.js";
import { regex as assetRegex } from "../core/asset-extensions.js";
import {
  isSupportedClientModule,
  scanProjectDependenciesForClientComponents,
} from "../core/scan-dependency-components.js";
import { getDinouConfig } from "../core/load-dinou-config.js";
import { resolveSetupFiles } from "../core/resolve-setup-files.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export async function bundleDualEngine(options = {}) {
  const isDev = Boolean(options.isDev);
  const projectRoot = path.resolve(options.projectRoot || process.cwd());
  const nodeDir = path.resolve(projectRoot, options.outDir || ".dinou/node");
  fs.mkdirSync(nodeDir, { recursive: true });

  const dinouConfig = await getDinouConfig();
  const setupFiles = resolveSetupFiles(projectRoot, dinouConfig);
  if (setupFiles.length > 0) {
    console.log(`  🔌 [Dinou Setup] Active setup files (${setupFiles.length}):`, setupFiles.map((f) => path.relative(projectRoot, f)).join(", "));
  }

  try {
    generateRouteTypes(projectRoot);
  } catch (e) {}

  // Locate dinou root
  const dinouDir = fs.existsSync(path.resolve(projectRoot, "dinou"))
    ? path.resolve(projectRoot, "dinou")
    : path.resolve(__dirname, "..");
  const dinouDirSlash = dinouDir.replace(/\\/g, "/");

  const candidateDinouRoots = [
    dinouDir,
    path.resolve(projectRoot, "dinou"),
    path.resolve(projectRoot, "node_modules/dinou/dinou"),
    path.resolve(projectRoot, "node_modules/dinou"),
    path.resolve(__dirname, ".."),
  ];

  const candidateLinkPaths = new Set();
  const candidateRedirectPaths = new Set();
  const candidateSlotPaths = new Set();
  for (const r of candidateDinouRoots) {
    candidateLinkPaths.add(path.resolve(r, "core/link.jsx"));
    candidateRedirectPaths.add(path.resolve(r, "core/client-redirect.jsx"));
    candidateSlotPaths.add(path.resolve(r, "core/slot.js"));
  }

  // 1. Generate route modules
  const routeModulesCode = generateRouteModulesCode(projectRoot, "../..");
  const routeModulesPath = path.join(nodeDir, "route-modules.mjs");
  fs.writeFileSync(routeModulesPath, routeModulesCode, "utf8");

  // 2. Discover manifests
  const isWebpackBuild = process.env.DINOU_BUILD_TOOL === "webpack";

  function findManifest(filename, fallbackFolder) {
    const candidates = isWebpackBuild
      ? [
          path.resolve(projectRoot, ".dinou/dist3", filename),
          path.resolve(projectRoot, ".dinou/public", filename),
          path.resolve(projectRoot, ".dinou", fallbackFolder, filename),
        ]
      : [
          path.resolve(projectRoot, ".dinou", fallbackFolder, filename),
          path.resolve(projectRoot, ".dinou/dist3", filename),
          path.resolve(projectRoot, ".dinou/public", filename),
        ];
    for (const c of candidates) {
      if (fs.existsSync(c)) return c;
    }
    return null;
  }

  const clientManifestPath = findManifest("react-client-manifest.json", "react_client_manifest");
  const sfManifestPath = findManifest("server-functions-manifest.json", "server_functions_manifest");

  let parsedClientManifest = {};
  if (clientManifestPath && fs.existsSync(clientManifestPath)) {
    try {
      parsedClientManifest = JSON.parse(fs.readFileSync(clientManifestPath, "utf8"));
    } catch (e) {}
  }

  let parsedServerFunctionsManifest = {};
  if (sfManifestPath && fs.existsSync(sfManifestPath)) {
    try {
      parsedServerFunctionsManifest = JSON.parse(fs.readFileSync(sfManifestPath, "utf8"));
    } catch (e) {}
  }

  // 3. Client components discovery
  const srcDir = path.resolve(projectRoot, "src");


  function findClientComponents() {
    const clientFiles = new Set();
    function walk(dir) {
      if (!fs.existsSync(dir)) return;
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          walk(full);
        } else if (/\.[jt]sx?$/.test(entry.name)) {
          try {
            const content = fs.readFileSync(full, "utf8");
            if (useClientRegex.test(content.trim()) && isSupportedClientModule(full, content)) {
              clientFiles.add(path.resolve(full));
            }
          } catch (e) {}
        }
      }
    }
    walk(srcDir);

    const coreCandidates = [
      ...Array.from(candidateLinkPaths),
      ...Array.from(candidateRedirectPaths),
      ...Array.from(candidateSlotPaths),
    ];
    for (const f of coreCandidates) {
      if (fs.existsSync(f)) {
        clientFiles.add(path.resolve(f));
      }
    }

    scanProjectDependenciesForClientComponents(projectRoot, clientFiles, useClientRegex);

    for (const k of Object.keys(parsedClientManifest)) {
      const fileUrl = k.split("#")[0];
      if (fileUrl.startsWith("file:///")) {
        try {
          const filePath = fileURLToPath(fileUrl);
          const baseName = path.basename(filePath);
          if (
            baseName === "client.jsx" ||
            baseName === "client-webpack.jsx"
          ) {
            continue;
          }
          if (fs.existsSync(filePath) && isSupportedClientModule(filePath)) {
            clientFiles.add(path.resolve(filePath));
          }
        } catch (e) {}
      }
    }

    return Array.from(clientFiles);
  }

  const clientComponents = findClientComponents();

  let manifestInlines = "";
  const normalizedManifest = { ...parsedClientManifest };
  for (const [k, v] of Object.entries(parsedClientManifest)) {
    if (k.startsWith("file:///c:/")) {
      normalizedManifest["file:///C:/" + k.slice(11)] = v;
    } else if (k.startsWith("file:///C:/")) {
      normalizedManifest["file:///c:/" + k.slice(11)] = v;
    }
  }

  function generateAllUrlVariants(absPath) {
    const norm = absPath.replace(/\\/g, "/");
    const fileUrl = pathToFileURL(absPath).href;
    const urls = new Set([fileUrl]);
    urls.add(fileUrl.replace(/file:\/\/\/([a-zA-Z]):/, (m, d) => "file:///" + d.toLowerCase() + ":"));
    urls.add(fileUrl.replace(/file:\/\/\/([a-zA-Z]):/, (m, d) => "file:///" + d.toUpperCase() + ":"));
    urls.add("file:///" + norm);
    urls.add("file://" + norm);
    return Array.from(urls);
  }

  let linkChunkId = null;
  let redirectChunkId = null;
  let linkEntry = null;
  let redirectEntry = null;
  let slotChunkId = null;
  let slotEntry = null;

  for (const [k, v] of Object.entries(parsedClientManifest)) {
    if (k.includes("/core/link.jsx") || k.includes("dinouLink")) {
      if (v && v.id) {
        linkChunkId = v.id;
        linkEntry = v;
      }
    }
    if (k.includes("/core/client-redirect.jsx") || k.includes("dinouClientRedirect")) {
      if (v && v.id) {
        redirectChunkId = v.id;
        redirectEntry = v;
      }
    }
    if (k.includes("/core/slot.") || k.includes("dinouSlot")) {
      if (v && v.id) {
        slotChunkId = v.id;
        slotEntry = v;
      }
    }
  }

  if (linkChunkId) {
    const linkChunks = isWebpackBuild ? linkEntry?.chunks || [linkChunkId] : "Link";
    const linkDefaultChunks = isWebpackBuild ? linkEntry?.chunks || [linkChunkId] : "default";

    for (const lp of candidateLinkPaths) {
      for (const url of generateAllUrlVariants(lp)) {
        normalizedManifest[`${url}#Link`] = { id: linkChunkId, chunks: linkChunks, name: "Link" };
        normalizedManifest[`${url}#default`] = { id: linkChunkId, chunks: linkDefaultChunks, name: "default" };
        normalizedManifest[url] = { id: linkChunkId, chunks: linkDefaultChunks, name: "default" };
      }
    }
  }

  if (redirectChunkId) {
    const redirectChunks = isWebpackBuild ? redirectEntry?.chunks || [redirectChunkId] : "ClientRedirect";
    const redirectDefaultChunks = isWebpackBuild ? redirectEntry?.chunks || [redirectChunkId] : "default";

    for (const rp of candidateRedirectPaths) {
      for (const url of generateAllUrlVariants(rp)) {
        normalizedManifest[`${url}#ClientRedirect`] = { id: redirectChunkId, chunks: redirectChunks, name: "ClientRedirect" };
        normalizedManifest[`${url}#default`] = { id: redirectChunkId, chunks: redirectDefaultChunks, name: "default" };
        normalizedManifest[url] = { id: redirectChunkId, chunks: redirectDefaultChunks, name: "default" };
      }
    }
  }

  if (slotChunkId) {
    const slotChunks = isWebpackBuild ? slotEntry?.chunks || [slotChunkId] : "DinouPageSlot";
    const slotBoundaryChunks = isWebpackBuild ? slotEntry?.chunks || [slotChunkId] : "DinouCacheSlotBoundary";
    const slotDefaultChunks = isWebpackBuild ? slotEntry?.chunks || [slotChunkId] : "default";

    for (const sp of candidateSlotPaths) {
      for (const url of generateAllUrlVariants(sp)) {
        normalizedManifest[`${url}#DinouPageSlot`] = { id: slotChunkId, chunks: slotChunks, name: "DinouPageSlot" };
        normalizedManifest[`${url}#DinouCacheSlotBoundary`] = { id: slotChunkId, chunks: slotBoundaryChunks, name: "DinouCacheSlotBoundary" };
        normalizedManifest[`${url}#default`] = { id: slotChunkId, chunks: slotDefaultChunks, name: "default" };
        normalizedManifest[url] = { id: slotChunkId, chunks: slotDefaultChunks, name: "default" };
      }
    }
  }

  for (const comp of clientComponents) {
    const fileUrl = pathToFileURL(comp).href;
    const fileUrlLower = fileUrl.replace(/file:\/\/\/([a-zA-Z]):/, (m, d) => "file:///" + d.toLowerCase() + ":");
    const fileUrlUpper = fileUrl.replace(/file:\/\/\/([a-zA-Z]):/, (m, d) => "file:///" + d.toUpperCase() + ":");
    const compResolved = path.resolve(comp);
    const isCoreLink = candidateLinkPaths.has(compResolved);
    const isCoreRedirect = candidateRedirectPaths.has(compResolved);
    const isCoreSlot = candidateSlotPaths.has(compResolved);

    if (!normalizedManifest[fileUrlLower]) {
      if (isCoreLink && linkChunkId) {
        normalizedManifest[fileUrlLower] = {
          id: linkChunkId,
          chunks: isWebpackBuild ? linkEntry?.chunks || [linkChunkId] : "default",
          name: "default",
        };
      } else if (isCoreRedirect && redirectChunkId) {
        normalizedManifest[fileUrlLower] = {
          id: redirectChunkId,
          chunks: isWebpackBuild ? redirectEntry?.chunks || [redirectChunkId] : "default",
          name: "default",
        };
      } else if (isCoreSlot && slotChunkId) {
        normalizedManifest[fileUrlLower] = {
          id: slotChunkId,
          chunks: isWebpackBuild ? slotEntry?.chunks || [slotChunkId] : "default",
          name: "default",
        };
      } else {
        normalizedManifest[fileUrlLower] = { id: fileUrlLower, chunks: [], name: "*" };
      }
    }
    if (!normalizedManifest[fileUrlUpper]) {
      if (isCoreLink && linkChunkId) {
        normalizedManifest[fileUrlUpper] = {
          id: linkChunkId,
          chunks: isWebpackBuild ? linkEntry?.chunks || [linkChunkId] : "default",
          name: "default",
        };
      } else if (isCoreRedirect && redirectChunkId) {
        normalizedManifest[fileUrlUpper] = {
          id: redirectChunkId,
          chunks: isWebpackBuild ? redirectEntry?.chunks || [redirectChunkId] : "default",
          name: "default",
        };
      } else if (isCoreSlot && slotChunkId) {
        normalizedManifest[fileUrlUpper] = {
          id: slotChunkId,
          chunks: isWebpackBuild ? slotEntry?.chunks || [slotChunkId] : "default",
          name: "default",
        };
      } else {
        normalizedManifest[fileUrlUpper] = { id: fileUrlLower, chunks: [], name: "*" };
      }
    }
  }

  manifestInlines += `\nglobalThis.__DINOU_CLIENT_MANIFEST__ = ${JSON.stringify(normalizedManifest)};\n`;

  if (sfManifestPath && fs.existsSync(sfManifestPath)) {
    const content = fs.readFileSync(sfManifestPath, "utf8");
    manifestInlines += `\nglobalThis.__DINOU_SERVER_FUNCTIONS_MANIFEST__ = ${content};\n`;
  } else {
    manifestInlines += `\nglobalThis.__DINOU_SERVER_FUNCTIONS_MANIFEST__ = {};\n`;
  }

  const assetManifestPath = findManifest("manifest.json", "dist3");
  if (assetManifestPath && fs.existsSync(assetManifestPath)) {
    const content = fs.readFileSync(assetManifestPath, "utf8");
    manifestInlines += `\nglobalThis.__DINOU_ASSET_MANIFEST__ = ${content};\n`;
  } else {
    manifestInlines += `\nglobalThis.__DINOU_ASSET_MANIFEST__ = {};\n`;
  }

  let importMapHtml = "";
  if (!isWebpackBuild && Object.keys(parsedClientManifest).length > 0) {
    const imports = {};
    const moduleBasePath = pathToFileURL(projectRoot).href + "/";

    for (const [key, val] of Object.entries(parsedClientManifest)) {
      let specifier = key;
      if (specifier.startsWith(moduleBasePath)) {
        specifier = specifier.slice(moduleBasePath.length);
      }
      const hashIdx = specifier.indexOf("#");
      if (hashIdx !== -1) {
        specifier = specifier.slice(0, hashIdx);
      }
      imports[specifier] = val.id;

      const srcIdx = key.indexOf("/src/");
      if (srcIdx !== -1) {
        const srcRel = "src/" + key.slice(srcIdx + 5).split("#")[0];
        imports[srcRel] = val.id;
        imports["/" + srcRel] = val.id;
        imports["./" + srcRel] = val.id;
      }
      const dinouIdx = key.lastIndexOf("/dinou/");
      if (dinouIdx !== -1) {
        const dinouRel = "dinou/" + key.slice(dinouIdx + 7).split("#")[0];
        imports[dinouRel] = val.id;
        imports["/" + dinouRel] = val.id;
        imports["./" + dinouRel] = val.id;
      }
    }

    if (linkChunkId) {
      imports["dinou/core/link.jsx"] = linkChunkId;
      imports["dinou/core/link"] = linkChunkId;
      imports["/dinou/core/link.jsx"] = linkChunkId;
      imports["./dinou/core/link.jsx"] = linkChunkId;
      for (const lp of candidateLinkPaths) {
        for (const u of generateAllUrlVariants(lp)) {
          imports[u] = linkChunkId;
        }
      }
    }
    if (redirectChunkId) {
      imports["dinou/core/client-redirect.jsx"] = redirectChunkId;
      imports["dinou/core/client-redirect"] = redirectChunkId;
      imports["/dinou/core/client-redirect.jsx"] = redirectChunkId;
      imports["./dinou/core/client-redirect.jsx"] = redirectChunkId;
      for (const rp of candidateRedirectPaths) {
        for (const u of generateAllUrlVariants(rp)) {
          imports[u] = redirectChunkId;
        }
      }
    }
    if (slotChunkId) {
      imports["dinou/core/slot.js"] = slotChunkId;
      imports["dinou/core/slot"] = slotChunkId;
      imports["/dinou/core/slot.js"] = slotChunkId;
      imports["./dinou/core/slot.js"] = slotChunkId;
      for (const sp of candidateSlotPaths) {
        for (const u of generateAllUrlVariants(sp)) {
          imports[u] = slotChunkId;
        }
      }
    }

    importMapHtml = `<script type="importmap">{"imports":${JSON.stringify(imports)}}</script>`;
  }

  manifestInlines += `\nglobalThis.__DINOU_IMPORT_MAP_HTML__ = ${JSON.stringify(importMapHtml)};\n`;

  const discoveredLayouts = [];
  function findLayoutRoutes(dir, rel = "") {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.isDirectory()) {
        findLayoutRoutes(path.join(dir, entry.name), rel ? `${rel}/${entry.name}` : entry.name);
      } else if (/^layout\.[jt]sx?$/.test(entry.name)) {
        discoveredLayouts.push(rel);
      } else if (entry.name === "no_layout") {
        discoveredLayouts.push("!" + rel);
      }
    }
  }
  findLayoutRoutes(srcDir);
  manifestInlines += `\nglobalThis.__DINOU_LAYOUTS__ = ${JSON.stringify(discoveredLayouts)};\n`;

  // 4. In-memory VFS snapshot for routing
  const vfsSnapshot = {};
  function walkVfs(dir) {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    const children = [];
    for (const entry of entries) {
      const isDir = entry.isDirectory();
      children.push({ name: entry.name, isDirectory: isDir });
      const fullPath = path.join(dir, entry.name);
      const relFromSrc = path.relative(srcDir, fullPath).replace(/\\/g, "/");
      const edgePath = "/src/" + relFromSrc;
      const slashPath = fullPath.replace(/\\/g, "/");
      if (isDir) {
        walkVfs(fullPath);
      } else {
        vfsSnapshot[edgePath] = { type: "file" };
        vfsSnapshot[slashPath] = { type: "file" };
        if (slashPath.length > 2 && slashPath[1] === ":") {
          vfsSnapshot[slashPath.slice(2)] = { type: "file" };
        }
        vfsSnapshot["src/" + relFromSrc] = { type: "file" };
      }
    }
    const dirRel = path.relative(srcDir, dir).replace(/\\/g, "/");
    const edgeDir = dirRel ? "/src/" + dirRel : "/src";
    const dirSlash = dir.replace(/\\/g, "/");
    vfsSnapshot[edgeDir] = { type: "directory", children };
    vfsSnapshot[dirSlash] = { type: "directory", children };
    if (dirSlash.length > 2 && dirSlash[1] === ":") {
      vfsSnapshot[dirSlash.slice(2)] = { type: "directory", children };
    }
    vfsSnapshot[dirRel ? "src/" + dirRel : "src"] = { type: "directory", children };
  }
  walkVfs(srcDir);

  const envSetupContent = `// Auto-generated environment setup
if (typeof globalThis.__webpack_require__ === 'undefined') {
  globalThis.__webpack_require__ = function(id) {
    if (globalThis.__webpack_modules__ && globalThis.__webpack_modules__[id]) {
      return globalThis.__webpack_modules__[id];
    }
    return {};
  };
}
if (typeof globalThis.__webpack_require__.u === 'undefined') {
  globalThis.__webpack_require__.u = function(chunkId) { return '' + chunkId + '.js'; };
}
if (typeof globalThis.__webpack_chunk_load__ === 'undefined') {
  globalThis.__webpack_chunk_load__ = () => Promise.resolve();
}
${manifestInlines}
globalThis.__DINOU_VFS__ = ${JSON.stringify(vfsSnapshot)};
`;
  const envSetupPath = path.join(nodeDir, "env-setup.mjs");
  fs.writeFileSync(envSetupPath, envSetupContent, "utf8");

  // 5. Generate ssr-client-manifest.mjs
  let ssrManifestCode = `// Auto-generated client modules registry for Native Node SSR\n`;
  clientComponents.forEach((compPath, index) => {
    const normPath = compPath.replace(/\\/g, "/");
    ssrManifestCode += `import * as mod_${index} from ${JSON.stringify(normPath)};\n`;
  });

  const serverFunctionFiles = Object.keys(parsedServerFunctionsManifest);
  serverFunctionFiles.forEach((relPath, index) => {
    const absPath = path.resolve(projectRoot, relPath).replace(/\\/g, "/");
    ssrManifestCode += `import * as sf_${index} from ${JSON.stringify(absPath)};\n`;
  });

  ssrManifestCode += `\nexport const clientModules = {\n`;
  const emittedClientModules = new Set();
  function addClientModule(key, valueExpr) {
    if (!emittedClientModules.has(key)) {
      emittedClientModules.add(key);
      ssrManifestCode += `  ${JSON.stringify(key)}: ${valueExpr},\n`;
    }
  }

  clientComponents.forEach((compPath, index) => {
    const fileUrl = pathToFileURL(compPath).href;
    const altFileUrl = fileUrl.replace(
      /file:\/\/\/([a-zA-Z]):/,
      (m, d) => "file:///" + (d === d.toLowerCase() ? d.toUpperCase() : d.toLowerCase()) + ":"
    );
    addClientModule(fileUrl, `mod_${index}`);
    if (altFileUrl !== fileUrl) {
      addClientModule(altFileUrl, `mod_${index}`);
    }
  });

  for (const [k, v] of Object.entries(parsedClientManifest)) {
    const fileUrl = k.split("#")[0];
    if (fileUrl.startsWith("file:///")) {
      try {
        const filePath = fileURLToPath(fileUrl);
        if (fs.existsSync(filePath) && !isSupportedClientModule(filePath)) continue;
      } catch (e) {}
    }
    const compIndex = clientComponents.findIndex(
      (c) => pathToFileURL(c).href === fileUrl || pathToFileURL(c).href.toLowerCase() === fileUrl.toLowerCase()
    );
    if (compIndex !== -1) {
      if (v && v.id) addClientModule(v.id, `mod_${compIndex}`);
      addClientModule(fileUrl, `mod_${compIndex}`);
    }
  }

  if (linkChunkId) {
    const linkCompIndex = clientComponents.findIndex((c) => candidateLinkPaths.has(path.resolve(c)));
    if (linkCompIndex !== -1) {
      addClientModule(linkChunkId, `mod_${linkCompIndex}`);
      for (const lp of candidateLinkPaths) {
        for (const u of generateAllUrlVariants(lp)) {
          addClientModule(u, `mod_${linkCompIndex}`);
        }
      }
    }
  }

  if (redirectChunkId) {
    const redirectCompIndex = clientComponents.findIndex((c) => candidateRedirectPaths.has(path.resolve(c)));
    if (redirectCompIndex !== -1) {
      addClientModule(redirectChunkId, `mod_${redirectCompIndex}`);
      for (const rp of candidateRedirectPaths) {
        for (const u of generateAllUrlVariants(rp)) {
          addClientModule(u, `mod_${redirectCompIndex}`);
        }
      }
    }
  }

  if (slotChunkId) {
    const slotCompIndex = clientComponents.findIndex((c) => candidateSlotPaths.has(path.resolve(c)));
    if (slotCompIndex !== -1) {
      addClientModule(slotChunkId, `mod_${slotCompIndex}`);
      for (const sp of candidateSlotPaths) {
        for (const u of generateAllUrlVariants(sp)) {
          addClientModule(u, `mod_${slotCompIndex}`);
        }
      }
    }
  }

  serverFunctionFiles.forEach((relPath, index) => {
    const normRel = relPath.replace(/\\/g, "/");
    const relFileUrl = "file:///" + normRel;
    const absPath = path.resolve(projectRoot, relPath);
    const fullFileUrl = pathToFileURL(absPath).href;
    const altFullFileUrl = fullFileUrl.replace(
      /file:\/\/\/([a-zA-Z]):/,
      (m, d) => "file:///" + (d === d.toLowerCase() ? d.toUpperCase() : d.toLowerCase()) + ":"
    );

    addClientModule(relFileUrl, `sf_${index}`);
    addClientModule(fullFileUrl, `sf_${index}`);
    if (altFullFileUrl !== fullFileUrl) {
      addClientModule(altFullFileUrl, `sf_${index}`);
    }
  });
  ssrManifestCode += `};\n\n`;

  ssrManifestCode += `export const ssrConsumerManifest = {\n  moduleMap: {\n`;
  const emittedModuleMap = new Set();
  function addModuleMap(key, valueObjStr) {
    if (!emittedModuleMap.has(key)) {
      emittedModuleMap.add(key);
      ssrManifestCode += `    ${JSON.stringify(key)}: ${valueObjStr},\n`;
    }
  }

  clientComponents.forEach((compPath) => {
    const fileUrl = pathToFileURL(compPath).href;
    const altFileUrl = fileUrl.replace(
      /file:\/\/\/([a-zA-Z]):/,
      (m, d) => "file:///" + (d === d.toLowerCase() ? d.toUpperCase() : d.toLowerCase()) + ":"
    );
    addModuleMap(fileUrl, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
    if (altFileUrl !== fileUrl) {
      addModuleMap(altFileUrl, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
    }
  });

  for (const [k, v] of Object.entries(parsedClientManifest)) {
    const fileUrl = k.split("#")[0];
    if (fileUrl.startsWith("file:///")) {
      try {
        const filePath = fileURLToPath(fileUrl);
        if (fs.existsSync(filePath) && !isSupportedClientModule(filePath)) continue;
      } catch (e) {}
    }
    if (v && v.id) {
      addModuleMap(v.id, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
    }
  }

  if (linkChunkId) {
    const linkCompIndex = clientComponents.findIndex((c) => candidateLinkPaths.has(path.resolve(c)));
    if (linkCompIndex !== -1) {
      const fileUrl = pathToFileURL(clientComponents[linkCompIndex]).href;
      addModuleMap(linkChunkId, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
      for (const lp of candidateLinkPaths) {
        for (const u of generateAllUrlVariants(lp)) {
          addModuleMap(u, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
        }
      }
    }
  }

  if (redirectChunkId) {
    const redirectCompIndex = clientComponents.findIndex((c) => candidateRedirectPaths.has(path.resolve(c)));
    if (redirectCompIndex !== -1) {
      const fileUrl = pathToFileURL(clientComponents[redirectCompIndex]).href;
      addModuleMap(redirectChunkId, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
      for (const rp of candidateRedirectPaths) {
        for (const u of generateAllUrlVariants(rp)) {
          addModuleMap(u, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
        }
      }
    }
  }

  if (slotChunkId) {
    const slotCompIndex = clientComponents.findIndex((c) => candidateSlotPaths.has(path.resolve(c)));
    if (slotCompIndex !== -1) {
      const fileUrl = pathToFileURL(clientComponents[slotCompIndex]).href;
      addModuleMap(slotChunkId, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
      for (const sp of candidateSlotPaths) {
        for (const u of generateAllUrlVariants(sp)) {
          addModuleMap(u, `{ "*": { id: ${JSON.stringify(fileUrl)}, chunks: [], name: "*" } }`);
        }
      }
    }
  }

  ssrManifestCode += `  },\n  serverModuleMap: {\n`;
  const emittedServerModuleMap = new Set();
  function addServerModuleMap(key, valueObjStr) {
    if (!emittedServerModuleMap.has(key)) {
      emittedServerModuleMap.add(key);
      ssrManifestCode += `    ${JSON.stringify(key)}: ${valueObjStr},\n`;
    }
  }

  serverFunctionFiles.forEach((relPath) => {
    const normRel = relPath.replace(/\\/g, "/");
    const relFileUrl = "file:///" + normRel;
    const absPath = path.resolve(projectRoot, relPath);
    const fullFileUrl = pathToFileURL(absPath).href;
    const altFullFileUrl = fullFileUrl.replace(
      /file:\/\/\/([a-zA-Z]):/,
      (m, d) => "file:///" + (d === d.toLowerCase() ? d.toUpperCase() : d.toLowerCase()) + ":"
    );

    addServerModuleMap(relFileUrl, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: "*" }`);
    addServerModuleMap(fullFileUrl, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: "*" }`);
    if (altFullFileUrl !== fullFileUrl) {
      addServerModuleMap(altFullFileUrl, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: "*" }`);
    }

    const fns = parsedServerFunctionsManifest[relPath] || [];
    for (const fn of fns) {
      addServerModuleMap(relFileUrl + "#" + fn, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: ${JSON.stringify(fn)} }`);
      addServerModuleMap(fullFileUrl + "#" + fn, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: ${JSON.stringify(fn)} }`);
      if (altFullFileUrl !== fullFileUrl) {
        addServerModuleMap(altFullFileUrl + "#" + fn, `{ id: ${JSON.stringify(relFileUrl)}, chunks: [], name: ${JSON.stringify(fn)} }`);
      }
    }
  });

  ssrManifestCode += `  },\n  moduleLoading: null,\n};\n`;
  const ssrClientManifestPath = path.join(nodeDir, "ssr-client-manifest.mjs");
  fs.writeFileSync(ssrClientManifestPath, ssrManifestCode, "utf8");

  // 6. Entry Files Generation
  const rscEntryContent = `// Auto-generated RSC Engine entry for Node.js (Dual-Bundle)
import "./env-setup.mjs";
import "./route-modules.mjs";
import * as edgeRenderer from "react-server-dom-webpack/server.edge";
globalThis.__DINOU_EDGE_RENDERER__ = edgeRenderer;
export { handleRequest } from "${dinouDirSlash}/core/handler.js";
export { buildStaticPages, getStaticPaths, getStaticLayouts, getStaticMetadata } from "${dinouDirSlash}/core/build-static-pages.js";
`;
  const rscEntryPath = path.join(nodeDir, "rsc-entry.mjs");
  fs.writeFileSync(rscEntryPath, rscEntryContent, "utf8");

  const ssrEntryContent = `// Auto-generated SSR Engine entry for Node.js (Dual-Bundle)
import { renderRscStreamToHtmlStream } from "${dinouDirSlash}/core/edge-ssr.js";
import { clientModules, ssrConsumerManifest } from "./ssr-client-manifest.mjs";

const lowerMap = new Map();
globalThis.__webpack_require__ = (id) => {
  if (clientModules[id]) return clientModules[id];
  if (typeof id === "string") {
    if (lowerMap.size === 0) {
      for (const k of Object.keys(clientModules)) lowerMap.set(k.toLowerCase(), clientModules[k]);
    }
    const lowerVal = lowerMap.get(id.toLowerCase());
    if (lowerVal) return lowerVal;
  }
  console.error("[SSR Engine] Module not found in __webpack_require__:", id);
  return {};
};
globalThis.__webpack_require__.u = (chunkId) => "" + chunkId + ".js";
globalThis.__webpack_chunk_load__ = () => Promise.resolve();

export async function renderHtml(rscStream, options = {}) {
  return renderRscStreamToHtmlStream(rscStream, ssrConsumerManifest, options);
}
`;
  const ssrEntryPath = path.join(nodeDir, "ssr-entry.mjs");
  fs.writeFileSync(ssrEntryPath, ssrEntryContent, "utf8");

  // 7. Esbuild Configuration & Compilation
  const nodeBuiltins = [
    "assert", "async_hooks", "buffer", "child_process", "cluster", "console",
    "constants", "crypto", "dgram", "diagnostics_channel", "dns", "domain",
    "events", "fs", "fs/promises", "http", "http2", "https", "inspector",
    "module", "net", "os", "path", "path/posix", "path/win32", "perf_hooks",
    "process", "punycode", "querystring", "readline", "repl", "stream",
    "stream/consumers", "stream/promises", "stream/web", "string_decoder",
    "timers", "timers/promises", "tls", "trace_events", "tty", "url",
    "util", "util/types", "v8", "vm", "wasi", "worker_threads", "zlib"
  ];
  const externalList = [...nodeBuiltins, ...nodeBuiltins.map((b) => "node:" + b)];

  const commonAlias = {
    "@": path.resolve(projectRoot, "src"),
    "dinou/config": path.resolve(dinouDir, "core/config.js"),
    dinou: dinouDir,
  };
  const commonLoader = {
    ".js": "jsx", ".jsx": "jsx", ".ts": "ts", ".tsx": "tsx",
    ".json": "json", ".css": "empty",
  };

  const serverAssetPlugin = {
    name: "dinou-server-asset-plugin",
    setup(build) {
      build.onResolve({ filter: assetRegex }, (args) => {
        let resolvedPath;
        if (args.path.startsWith("@/")) {
          resolvedPath = path.resolve(projectRoot, "src", args.path.slice(2));
        } else if (path.isAbsolute(args.path)) {
          resolvedPath = args.path;
        } else {
          resolvedPath = path.resolve(args.resolveDir, args.path);
        }
        return { path: resolvedPath, namespace: "dinou-server-asset" };
      });

      build.onLoad({ filter: /.*/, namespace: "dinou-server-asset" }, (args) => {
        const ext = path.extname(args.path);
        const base = path.basename(args.path, ext);
        const scoped = createScopedName(base, args.path);
        const assetUrl = `/assets/${scoped}${ext}`;

        return {
          contents: `export default ${JSON.stringify(assetUrl)};`,
          loader: "js",
        };
      });
    },
  };

  const banner = {
    js: `import { createRequire as ___createRequire } from 'node:module';
import { AsyncLocalStorage as ___AsyncLocalStorage } from 'node:async_hooks';
const require = ___createRequire(import.meta.url || 'file:///server.js');
const __dirname = '';
const __filename = '';
globalThis.__dinou_require__ = require;
if (typeof globalThis.AsyncLocalStorage === 'undefined' && typeof ___AsyncLocalStorage !== 'undefined') {
  globalThis.AsyncLocalStorage = ___AsyncLocalStorage;
}
if (typeof globalThis.__webpack_require__ === 'undefined') {
  globalThis.__webpack_require__ = function(id) {
    if (globalThis.__webpack_modules__ && globalThis.__webpack_modules__[id]) {
      return globalThis.__webpack_modules__[id];
    }
    return {};
  };
}
if (typeof globalThis.__webpack_require__.u === 'undefined') {
  globalThis.__webpack_require__.u = function(chunkId) { return '' + chunkId + '.js'; };
}
if (typeof globalThis.__webpack_chunk_load__ === 'undefined') {
  globalThis.__webpack_chunk_load__ = () => Promise.resolve();
}
var __webpack_require__ = function(id) {
  return globalThis.__webpack_require__ ? globalThis.__webpack_require__(id) : {};
};
__webpack_require__.u = function(chunkId) {
  return (globalThis.__webpack_require__ && globalThis.__webpack_require__.u)
    ? globalThis.__webpack_require__.u(chunkId)
    : '' + chunkId + '.js';
};
var __webpack_chunk_load__ = function(chunkId) {
  return globalThis.__webpack_chunk_load__ ? globalThis.__webpack_chunk_load__(chunkId) : Promise.resolve();
};
`,
  };

  const clientReferencesPlugin = {
    name: "dinou-client-references",
    setup(build) {
      build.onLoad({ filter: /\.[jt]sx?$/ }, async (args) => {
        if (args.path.includes("node_modules")) {
          if (
            args.path.includes("react-server-dom") ||
            args.path.includes("@roggc/react-server-dom-esm") ||
            args.path.includes("node_modules/react/") ||
            args.path.includes("node_modules\\react\\") ||
            args.path.includes("node_modules/react-dom/") ||
            args.path.includes("node_modules\\react-dom\\")
          ) {
            return null;
          }
        }
        const normalizedPath = args.path.replace(/\\/g, "/");
        if (normalizedPath.includes("dinou/core/navigation")) return null;

        let code;
        try { code = fs.readFileSync(args.path, "utf8"); } catch (e) { return null; }
        if (!isSupportedClientModule(args.path, code)) return null;
        if (!useClientRegex.test(code.trim())) return null;

        const exports = parseExports(code);
        const absPath = path.resolve(args.path);
        const fileUrl = pathToFileURL(absPath).href;

        let proxyCode = `import { createClientModuleProxy } from "react-server-dom-webpack/server.edge";\n`;
        proxyCode += `const proxy = createClientModuleProxy(${JSON.stringify(fileUrl)});\n`;

        for (const name of exports) {
          if (name === "default") {
            proxyCode += `export default proxy.default;\n`;
          } else {
            proxyCode += `export const ${name} = proxy[${JSON.stringify(name)}];\n`;
          }
        }

        if (!exports.includes("default")) {
          proxyCode += `export default proxy.default;\n`;
        }

        return { contents: proxyCode, loader: "js" };
      });
    },
  };

  const serverReferencesPlugin = {
    name: "dinou-server-references",
    setup(build) {
      build.onLoad({ filter: /\.[jt]sx?$/ }, async (args) => {
        if (args.path.includes("node_modules")) {
          if (
            args.path.includes("react-server-dom") ||
            args.path.includes("@roggc/react-server-dom-esm") ||
            args.path.includes("node_modules/react/") ||
            args.path.includes("node_modules\\react\\") ||
            args.path.includes("node_modules/react-dom/") ||
            args.path.includes("node_modules\\react-dom\\")
          ) {
            return null;
          }
        }
        let code;
        try { code = fs.readFileSync(args.path, "utf8"); } catch (e) { return null; }
        if (!hasServerFunctions(code)) return null;

        const sfResult = transformServerFunctions(code, args.path);
        if (!sfResult.actions || sfResult.actions.length === 0) return null;

        const transformedCode = sfResult.code;
        const exports = sfResult.actions;
        const absPath = path.resolve(args.path);
        const relPath = path.relative(projectRoot, absPath).replace(/\\/g, "/");
        const relativeFileUrl = "file:///" + relPath;

        let transformed = transformedCode + "\n\n";
        transformed += `import { registerServerReference } from "react-server-dom-webpack/server.edge";\n`;
        for (const name of exports) {
          if (name !== "default") {
            transformed += `registerServerReference(${name}, ${JSON.stringify(relativeFileUrl)}, ${JSON.stringify(name)});\n`;
          }
        }

        const ext = path.extname(args.path);
        const loader = ext === ".ts" ? "ts" : ext === ".tsx" ? "tsx" : ext === ".jsx" ? "jsx" : "js";
        return { contents: transformed, loader };
      });
    },
  };

  const serverReferencesPluginSsr = {
    name: "dinou-server-references-ssr",
    setup(build) {
      build.onLoad({ filter: /\.[jt]sx?$/ }, async (args) => {
        if (args.path.includes("node_modules")) {
          if (
            args.path.includes("react-server-dom") ||
            args.path.includes("@roggc/react-server-dom-esm") ||
            args.path.includes("node_modules/react/") ||
            args.path.includes("node_modules\\react\\") ||
            args.path.includes("node_modules/react-dom/") ||
            args.path.includes("node_modules\\react-dom\\")
          ) {
            return null;
          }
        }
        let code;
        try { code = fs.readFileSync(args.path, "utf8"); } catch (e) { return null; }
        if (!hasServerFunctions(code)) return null;

        const sfResult = transformServerFunctions(code, args.path);
        if (!sfResult.actions || sfResult.actions.length === 0) return null;

        const transformedCode = sfResult.code;
        const exports = sfResult.actions;
        const absPath = path.resolve(args.path);
        const relPath = path.relative(projectRoot, absPath).replace(/\\/g, "/");
        const relativeFileUrl = "file:///" + relPath;

        let transformed = transformedCode + "\n\n";
        transformed += `import { registerServerReference } from "react-server-dom-webpack/client.edge";\n`;
        for (const name of exports) {
          if (name !== "default") {
            transformed += `registerServerReference(${name}, ${JSON.stringify(relativeFileUrl + "#" + name)});\n`;
            transformed += `registerServerReference(${name}, ${JSON.stringify(pathToFileURL(absPath).href + "#" + name)});\n`;
          }
        }

        const ext = path.extname(args.path);
        const loader = ext === ".ts" ? "ts" : ext === ".tsx" ? "tsx" : ext === ".jsx" ? "jsx" : "js";
        return { contents: transformed, loader };
      });
    },
  };

  const rscOutfile = path.join(nodeDir, "rsc-engine.mjs");
  const ssrOutfile = path.join(nodeDir, "ssr-engine.mjs");

  const buildEnv = isDev ? "development" : "production";

  // Pass A: RSC Engine
  await esbuild.build({
    entryPoints: [rscEntryPath],
    outfile: rscOutfile,
    bundle: true,
    format: "esm",
    target: "node20",
    platform: "node",
    mainFields: ["module", "main"],
    conditions: ["node", "worker", "react-server"],
    external: externalList,
    banner,
    inject: setupFiles,
    plugins: [clientReferencesPlugin, serverReferencesPlugin, serverAssetPlugin],
    alias: commonAlias,
    loader: commonLoader,
    jsx: "automatic",
    define: {
      "process.env.NODE_ENV": JSON.stringify(buildEnv),
      "process.env.DINOU_RUNTIME": '"node-bundle"',
      "process.env.DINOU_BUILD_TOOL": JSON.stringify(isWebpackBuild ? "webpack" : (process.env.DINOU_BUILD_TOOL || "esbuild")),
    },
    logLevel: "warning",
  });

  // Pass B: SSR Engine
  await esbuild.build({
    entryPoints: [ssrEntryPath],
    outfile: ssrOutfile,
    bundle: true,
    format: "esm",
    target: "node20",
    platform: "node",
    mainFields: ["module", "main"],
    conditions: ["node", "worker", "browser"],
    external: externalList,
    banner,
    inject: setupFiles,
    plugins: [serverReferencesPluginSsr, serverAssetPlugin],
    alias: commonAlias,
    loader: commonLoader,
    jsx: "automatic",
    define: {
      "process.env.NODE_ENV": JSON.stringify(buildEnv),
      "process.env.DINOU_RUNTIME": '"node-bundle"',
      "process.env.DINOU_BUILD_TOOL": JSON.stringify(isWebpackBuild ? "webpack" : (process.env.DINOU_BUILD_TOOL || "esbuild")),
    },
    logLevel: "warning",
  });

  return {
    nodeDir,
    rscEnginePath: rscOutfile,
    ssrEnginePath: ssrOutfile,
    rscEntryPath,
    ssrEntryPath,
    parsedClientManifest,
    clientComponents,
    dinouDirSlash,
    externalList,
    banner,
    commonAlias,
    commonLoader,
    isWebpackBuild,
    setupFiles,
  };
}

export default { bundleDualEngine };
