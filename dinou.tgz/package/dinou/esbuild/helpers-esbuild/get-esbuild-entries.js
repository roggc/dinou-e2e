import { readFileSync } from "fs";
import path from "node:path";
import glob from "fast-glob";
import { pathToFileURL } from "node:url";
import parser from "@babel/parser";
import traverse from "@babel/traverse";
import crypto from "node:crypto";
import {
  regex as assetRegex,
  globPattern as assetGlobPattern,
} from "../../core/asset-extensions.js";
import { getAbsPathWithExt } from "../../core/get-abs-path-with-ext.js";
import normalizePath from "./normalize-path.js";
import { useClientRegex, useServerRegex } from "../../constants.js";
import { updateManifestForModule } from "./update-manifest-for-module.js";

function hashFilePath(absPath) {
  return crypto.createHash("sha1").update(normalizePath(absPath)).digest("hex").slice(0, 8);
}

export default async function getEsbuildEntries({
  srcDir = path.resolve("src"),
  assetInclude = assetRegex,
  manifest = {},
} = {}) {
  const detectedClientEntries = new Set();
  const detectedCSSEntries = new Set();
  const detectedAssetEntries = new Set();
  const serverModules = new Set();
  const serverFunctions = new Set();

  // ---------- Helpers (ported mostly verbatim) ----------
  async function getImportsAndAssetsAndCsss(
    code,
    baseFilePath,
    visited = new Set(),
    isTopLevelClientComponent = false,
  ) {
    if (visited.has(baseFilePath)) {
      return { imports: [], assets: [], csss: [] };
    }
    visited.add(baseFilePath);

    const ast = parser.parse(code, {
      sourceType: "module",
      plugins: ["jsx", "typescript"],
    });
    const imports = new Set();
    const assets = new Set();
    const csss = new Set();

    const importNodes = [];
    const traverseFn = typeof traverse === "function" ? traverse : (traverse.default || traverse);
    traverseFn(ast, {
      ImportDeclaration(nodePath) {
        importNodes.push(nodePath);
      },
    });

    for (const nodePath of importNodes) {
      const source = nodePath.node.source.value;

      // Resolve the import to absolute path (with extension) using your helper
      const absImportPathWithExt = getAbsPathWithExt(source, {
        parentURL: pathToFileURL(baseFilePath).href,
      });

      if (!absImportPathWithExt) {
        // unresolved - skip
        continue;
      }

      // Read the file ONLY once
      let importedCode;
      try {
        importedCode = readFileSync(absImportPathWithExt, "utf8");
      } catch (err) {
        console.warn(
          `[get-esbuild-entries] Could not read import: ${absImportPathWithExt}`,
          err.message,
        );
        continue;
      }

      if (!isTopLevelClientComponent) {
        // Verify if it is a client component
        const isImportedFileClient = useClientRegex.test(importedCode.trim());

        // If it is a client component, DO NOT process recursively
        if (isImportedFileClient) {
          continue; // Do not recursively process client components
        }

        const isImportedFileServer = useServerRegex.test(importedCode.trim());
        if (isImportedFileServer) {
          serverFunctions.add(normalizePath(absImportPathWithExt));
          continue;
        }
      } else {
        const isImportedFileServer = useServerRegex.test(importedCode.trim());

        if (isImportedFileServer) {
          serverFunctions.add(normalizePath(absImportPathWithExt));
          continue;
        }
      }

      // For non-client modules, process normally
      if (
        absImportPathWithExt.endsWith(".css") ||
        absImportPathWithExt.endsWith(".scss") ||
        absImportPathWithExt.endsWith(".less")
      ) {
        csss.add(absImportPathWithExt);
        continue;
      }

      if (assetInclude.test(absImportPathWithExt)) {
        assets.add(absImportPathWithExt);
        continue;
      }

      // 🚨 THE SOLUTION: If it is a JSON file, add it but DO NOT parse it with Babel
      if (absImportPathWithExt.endsWith(".json")) {
        imports.add(absImportPathWithExt);
        continue; // This prevents it from entering Babel recursion
      }

      imports.add(absImportPathWithExt);

      // Process imports recursively for non-client modules
      try {
        const nested = await getImportsAndAssetsAndCsss(
          importedCode,
          absImportPathWithExt,
          visited,
          isTopLevelClientComponent,
        );
        nested.imports.forEach((p) => imports.add(p));
        nested.assets.forEach((p) => assets.add(p));
        nested.csss.forEach((p) => csss.add(p));
      } catch (err) {
        console.warn(
          `[get-esbuild-entries] Could not process imports of: ${absImportPathWithExt}`,
          err.message,
        );
      }
    }

    return {
      imports: Array.from(imports),
      assets: Array.from(assets),
      csss: Array.from(csss),
    };
  }

  function isPageOrLayout(absPath) {
    const fileName = path.basename(absPath);
    return fileName.startsWith("page.") || fileName.startsWith("layout.");
  }


  const files = await glob(["**/*.{js,jsx,ts,tsx}"], {
    cwd: srcDir,
    absolute: true,
  });

  // Gather client modules and update manifest entries
  let fileScanCount = 0;
  for (const absPath of files) {
    if (++fileScanCount % 5 === 0) {
      await new Promise((resolve) => setImmediate(resolve));
    }
    const code = readFileSync(absPath, "utf8");
    const isClientModule = useClientRegex.test(code.trim());
    const isServerFunction = useServerRegex.test(code.trim());
    const normalizedPath = normalizePath(absPath);

    if (isServerFunction) {
      serverFunctions.add(normalizedPath);
    }

    if (isClientModule) {
      const name = path.basename(absPath, path.extname(absPath));

      updateManifestForModule(absPath, code, true, manifest);
      detectedClientEntries.add({
        absPath: normalizedPath,
        name,
      });
    } else if (isPageOrLayout(absPath)) {
      serverModules.add(normalizedPath);
      try {
        const { imports, assets, csss } = await getImportsAndAssetsAndCsss(
          code,
          absPath,
        );

        if (csss.length > 0) {
          detectedCSSEntries.add(
            ...csss.map((cssPath) => ({
              absPath: normalizePath(cssPath),
              name: path.basename(cssPath, path.extname(cssPath)),
            })),
          );
        }

        assets.forEach((assetPath) => {
          detectedAssetEntries.add({
            absPath: normalizePath(assetPath),
            name: path.basename(assetPath, path.extname(assetPath)),
          });
        });

        const serverComponentRegex = /\.(js|jsx|ts|tsx)$/i;
        imports.forEach((imp) => {
          if (serverComponentRegex.test(imp) && !imp.includes("node_modules")) {
            serverModules.add(normalizePath(imp));
          }
        });
      } catch (err) {
        /* ignore */
      }
    }
  } // end for files

  const csss = await glob(["**/*.css"], {
    cwd: srcDir,
    absolute: true,
  });
  // console.log("detected css entries from glob:", csss);

  for (const absPath of csss) {
    detectedCSSEntries.add({
      absPath: normalizePath(absPath),
      name: path.basename(absPath, path.extname(absPath)),
    });
  }
  // console.log("final detectedCSSEntries:", detectedCSSEntries);

  const assets = await glob([assetGlobPattern], {
    cwd: srcDir,
    absolute: true,
  });

  for (const absPath of assets) {
    detectedAssetEntries.add({
      absPath: normalizePath(absPath),
      name: path.basename(absPath, path.extname(absPath)),
    });
  }

  for (const dCE of detectedClientEntries) {
    const hash = hashFilePath(dCE.absPath);
    const outfileName = `${dCE.name}-${hash}`;
    dCE.outfile = `${outfileName}.js`;
    dCE.outfileName = outfileName;
    if (manifest) {
      const fileUrl = pathToFileURL(dCE.absPath).href;
      const lowerFileUrl = fileUrl.toLowerCase();
      for (const key in manifest) {
        const kBase = key.split("#")[0].toLowerCase();
        if (kBase === lowerFileUrl) {
          manifest[key].id = "/" + dCE.outfile;
        }
      }
    }
  }

  for (const dCSSE of detectedCSSEntries) {
    const hash = hashFilePath(dCSSE.absPath);
    const outfileName = `${dCSSE.name}-${hash}`;
    dCSSE.outfile = `${outfileName}.js`;
    dCSSE.outfileName = outfileName;
  }

  for (const dAE of detectedAssetEntries) {
    const hash = hashFilePath(dAE.absPath);
    const outfileName = `${dAE.name}-${hash}`;
    dAE.outfile = `${outfileName}.js`;
    dAE.outfileName = outfileName;
  }

  return [
    detectedClientEntries,
    detectedCSSEntries,
    detectedAssetEntries,
    Array.from(serverFunctions),
  ];
}
