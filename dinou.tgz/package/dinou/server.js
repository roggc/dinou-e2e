const {
  StorageAdapter,
  FileSystemStorage,
  CloudflareKVStorage,
  DenoKVStorage,
  MemoryStorage,
  RedisStorage,
  getStorageAdapter,
  setStorageAdapter,
} = require("./core/storage-adapter.js");
const { DinouCacheSlot } = require("./core/cache-slot.js");

module.exports = {
  DinouCacheSlot,
  revalidatePath: async function (path, options) {
    const { revalidatePath: fn } = require("./core/cache-revalidate.js");
    return fn(path, options);
  },
  revalidatePage: async function (path) {
    const { revalidatePage: fn } = require("./core/cache-revalidate.js");
    return fn(path);
  },
  revalidateTag: async function (tag, options) {
    const { revalidateTag: fn } = require("./core/cache-revalidate.js");
    return fn(tag, options);
  },
  StorageAdapter,
  FileSystemStorage,
  CloudflareKVStorage,
  DenoKVStorage,
  MemoryStorage,
  RedisStorage,
  getStorageAdapter,
  setStorageAdapter,
};
