// dinou/adapters/node.js
// Native Node.js Pre-Bundled Adapter for Dinou v7.
// Serves the standalone pre-bundled server from .dinou/node/server.mjs.

import * as path from "node:path";
import * as fs from "node:fs";
import { pathToFileURL } from "node:url";
import { AsyncLocalStorage } from "node:async_hooks";

if (typeof globalThis.AsyncLocalStorage === "undefined" && typeof AsyncLocalStorage !== "undefined") {
  globalThis.AsyncLocalStorage = AsyncLocalStorage;
}

const cwd = typeof process !== "undefined" && typeof process.cwd === "function" ? process.cwd() : ".";
let bundlePath = path.resolve(cwd, ".dinou/node/server.js");
if (!fs.existsSync(bundlePath)) {
  const mjsFallback = path.resolve(cwd, ".dinou/node/server.mjs");
  if (fs.existsSync(mjsFallback)) {
    bundlePath = mjsFallback;
  }
}

if (!fs.existsSync(bundlePath)) {
  console.error("❌ [Dinou Node Adapter] .dinou/node/server.js not found. Please run 'npm run build:node' first.");
  process.exit(1);
}

const serverModule = await import(pathToFileURL(bundlePath).href);
const PORT = Number(process.env.PORT || 3000);

if (typeof serverModule.startServer === "function") {
  await serverModule.startServer(PORT);
} else if (serverModule.default && typeof serverModule.default.startServer === "function") {
  await serverModule.default.startServer(PORT);
}

export default serverModule.default || serverModule;
