import { defineConfig } from "./core/config.js";
import { getContext } from "./core/request-context.js";
import { noDynamic } from "./core/no-dynamic.js";
import {
  usePathname,
  useSearchParams,
  useRouter,
  refreshSlot,
  useNavigationLoading,
} from "./core/navigation.js";
import { redirect } from "./core/redirect.jsx";
import { ClientRedirect } from "./core/client-redirect.jsx";
import { Link } from "./core/link.jsx";

const dinou = {
  defineConfig,
  getContext,
  noDynamic,
  usePathname,
  useSearchParams,
  useRouter,
  refreshSlot,
  useNavigationLoading,
  redirect,
  ClientRedirect,
  Link,
};

export {
  defineConfig,
  getContext,
  noDynamic,
  usePathname,
  useSearchParams,
  useRouter,
  refreshSlot,
  useNavigationLoading,
  redirect,
  ClientRedirect,
  Link,
};

export default dinou;
