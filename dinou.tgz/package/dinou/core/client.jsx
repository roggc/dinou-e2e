// dinou/core/client.jsx
if (typeof window !== "undefined") {
  if (!window.$RefreshReg$) window.$RefreshReg$ = () => { };
  if (!window.$RefreshSig$) window.$RefreshSig$ = () => (type) => type;
}
import {
  use,
  useRef,
  useState,
  useEffect,
  useTransition,
  useLayoutEffect,
  useMemo,
  useCallback,
  Component,
  createElement,
  StrictMode,
} from "react";
import { createFromFetch } from "@roggc/react-server-dom-esm/client";
import { hydrateRoot } from "react-dom/client";
import { RouterContext } from "./navigation.js";
import { resolveUrl, isExternalUrl } from "./navigation-utils.js";
import { createServerFunctionProxy } from "./server-function-proxy.js";
import {
  DinouPageContext,
  DinouPageSlot,
  cleanErrorStack,
  flushPendingSsrStreams,
  pruneOrphanedSsrStreams,
} from "./slot.js";

// ====================================================================
// 1. GLOBAL STATE (Outside the component)
// ====================================================================
const MAX_CLIENT_PAGE_CACHE_ENTRIES = 50;
const MAX_CLIENT_LAYOUT_CACHE_ENTRIES = 50;
const MAX_CLIENT_SCROLL_CACHE_ENTRIES = 100;

const pageCache = new Map();
const layoutCache = new Map();
const scrollCache = new Map();
if (typeof window !== "undefined") {
  window.__DINOU_PAGE_CACHE__ = pageCache;
  window.__DINOU_LAYOUT_CACHE__ = layoutCache;
  window.__DINOU_SCROLL_CACHE__ = scrollCache;
}

const getMaxClientCacheEntries = (defaultMax) => {
  if (typeof window !== "undefined") {
    const custom = Number(window.__DINOU_MAX_CLIENT_CACHE_ENTRIES__);
    if (Number.isFinite(custom) && custom > 0) {
      return Math.floor(custom);
    }
  }
  return defaultMax;
};

const getCurrentRoute = () => window.location.pathname + window.location.search;

const getBoundedCacheEntry = (cache, key) => {
  if (!cache.has(key)) return undefined;
  const value = cache.get(key);
  cache.delete(key);
  cache.set(key, value);
  return value;
};

const setBoundedPageCache = (key, value) => {
  if (pageCache.has(key)) {
    pageCache.delete(key);
  }
  pageCache.set(key, value);
  const maxEntries = getMaxClientCacheEntries(MAX_CLIENT_PAGE_CACHE_ENTRIES);
  if (pageCache.size <= maxEntries) return;
  const activeRoute = typeof window !== "undefined" ? getCurrentRoute() : "";
  for (const existingKey of pageCache.keys()) {
    if (pageCache.size <= maxEntries) break;
    if (existingKey === key || existingKey === activeRoute) continue;
    pageCache.delete(existingKey);
    erroredPageCacheKeys.delete(existingKey);
    volatilePageCacheKeys.delete(existingKey);
  }
};

const setBoundedLayoutCache = (key, value) => {
  if (layoutCache.has(key)) {
    layoutCache.delete(key);
  }
  layoutCache.set(key, value);
  const maxEntries = getMaxClientCacheEntries(MAX_CLIENT_LAYOUT_CACHE_ENTRIES);
  if (layoutCache.size <= maxEntries) return;
  let activeLayoutCacheKey = null;
  if (typeof window !== "undefined") {
    const activeLKey = getLayoutKey(window.location.pathname);
    activeLayoutCacheKey = activeLKey
      ? isStaticExportMode()
        ? activeLKey
        : `${activeLKey}${window.location.search || ""}`
      : null;
  }
  for (const existingKey of layoutCache.keys()) {
    if (layoutCache.size <= maxEntries) break;
    if (existingKey === key || existingKey === activeLayoutCacheKey) continue;
    layoutCache.delete(existingKey);
    erroredLayoutCacheKeys.delete(existingKey);
    volatileLayoutCacheKeys.delete(existingKey);
  }
};

const setBoundedScrollCache = (key, value) => {
  if (scrollCache.has(key)) {
    scrollCache.delete(key);
  }
  scrollCache.set(key, value);
  const maxEntries = MAX_CLIENT_SCROLL_CACHE_ENTRIES;
  while (scrollCache.size > maxEntries) {
    const oldestKey = scrollCache.keys().next().value;
    if (oldestKey === undefined || oldestKey === key) break;
    scrollCache.delete(oldestKey);
  }
};

const scrollToCurrentHash = (rawHash = typeof window !== "undefined" ? window.location.hash : "") => {
  if (!rawHash) return false;
  try {
    const id = decodeURIComponent(rawHash.replace("#", ""));
    const element = document.getElementById(id) || document.getElementsByName(id)[0];
    if (element) {
      element.scrollIntoView({ behavior: "auto" });
      return true;
    }
  } catch (e) {
    const id = rawHash.replace("#", "");
    const element = document.getElementById(id) || document.getElementsByName(id)[0];
    if (element) {
      element.scrollIntoView({ behavior: "auto" });
      return true;
    }
  }
  return false;
};

// ====================================================================
// 2. PURE HELPERS
// ====================================================================

const safeDecodeSeg = (val) => {
  try {
    return val ? decodeURIComponent(val) : val;
  } catch (e) {
    return val;
  }
};

const isRouterSyntaxSeg = (rawSeg) => {
  const seg = safeDecodeSeg(rawSeg);
  return Boolean(
    seg &&
      ((seg.startsWith("(") && seg.endsWith(")")) ||
        (seg.startsWith("[") && seg.endsWith("]")) ||
        seg.startsWith("@") ||
        seg.startsWith("_"))
  );
};

const matchRoutePattern = (pSegs, uSegs, pIdx = 0, uIdx = 0, captures = null) => {
  if (pIdx === pSegs.length) return uIdx === uSegs.length;
  const p = pSegs[pIdx];
  if (p.startsWith("[[...") && p.endsWith("]]")) {
    if (pIdx === pSegs.length - 1) {
      if (uIdx <= uSegs.length) {
        if (captures) captures[pIdx] = uSegs.slice(uIdx);
        return true;
      }
      return false;
    }
    for (let k = uIdx; k <= uSegs.length; k++) {
      if (captures) captures[pIdx] = uSegs.slice(uIdx, k);
      if (matchRoutePattern(pSegs, uSegs, pIdx + 1, k, captures)) return true;
    }
    return false;
  }
  if (p.startsWith("[...") && p.endsWith("]")) {
    if (uIdx >= uSegs.length) return false;
    if (pIdx === pSegs.length - 1) {
      if (captures) captures[pIdx] = uSegs.slice(uIdx);
      return true;
    }
    for (let k = uIdx + 1; k <= uSegs.length; k++) {
      if (captures) captures[pIdx] = uSegs.slice(uIdx, k);
      if (matchRoutePattern(pSegs, uSegs, pIdx + 1, k, captures)) return true;
    }
    return false;
  }
  if (p.startsWith("[[") && p.endsWith("]]")) {
    if (uIdx < uSegs.length) {
      if (captures) captures[pIdx] = [uSegs[uIdx]];
      if (matchRoutePattern(pSegs, uSegs, pIdx + 1, uIdx + 1, captures)) {
        return true;
      }
    }
    if (captures) captures[pIdx] = [];
    return matchRoutePattern(pSegs, uSegs, pIdx + 1, uIdx, captures);
  }
  if (p.startsWith("[") && p.endsWith("]")) {
    if (uIdx >= uSegs.length) return false;
    if (captures) captures[pIdx] = [uSegs[uIdx]];
    return matchRoutePattern(pSegs, uSegs, pIdx + 1, uIdx + 1, captures);
  }
  if (uIdx >= uSegs.length || isRouterSyntaxSeg(uSegs[uIdx])) {
    return false;
  }
  if (uSegs[uIdx] !== p && safeDecodeSeg(uSegs[uIdx]) !== p) {
    return false;
  }
  if (captures) captures[pIdx] = [uSegs[uIdx]];
  return matchRoutePattern(pSegs, uSegs, pIdx + 1, uIdx + 1, captures);
};

// Helper to determine active layout folder for a pathname
const getLayoutKey = (pathname) => {
  const rawLayouts = (typeof window !== "undefined" && window.__DINOU_LAYOUTS__) || ["", "docs"];
  const pageRules = rawLayouts.filter((l) => typeof l === "string" && l.startsWith("="));
  const layouts = rawLayouts.filter(
    (l) => typeof l === "string" && !l.startsWith("!") && !l.startsWith("=")
  );
  const noLayouts = rawLayouts
    .filter((l) => typeof l === "string" && l.startsWith("!"))
    .map((l) => l.slice(1));
  const cleanPath0 = pathname.split("?")[0].split("#")[0];
  const segments0 = cleanPath0.split("/").filter(Boolean);

  for (const rule of pageRules) {
    const colonIdx = rule.lastIndexOf(":");
    if (colonIdx === -1) continue;
    const pattern = rule.slice(1, colonIdx);
    const spec = rule.slice(colonIdx + 1);
    const pSegs = pattern ? pattern.split("/").filter(Boolean) : [];
    const captures = [];
    if (matchRoutePattern(pSegs, segments0, 0, 0, captures)) {
      if (spec === "-1") return null;
      if (spec.startsWith("~")) {
        const tplSegs = spec.slice(1).split("/").filter(Boolean);
        const outSegs = [];
        let pCursor = 0;
        for (const seg of tplSegs) {
          if (seg.startsWith("(") && seg.endsWith(")")) {
            outSegs.push(seg);
          } else {
            const matched = captures[pCursor++] || [];
            if (matched.length > 0) {
              for (const m of matched) outSegs.push(m);
            } else {
              outSegs.push(seg);
            }
          }
        }
        return outSegs.length === 0 ? "/" : "/" + outSegs.join("/");
      }
      if (spec.startsWith("*-")) {
        const trailing = Number(spec.slice(2)) || 0;
        const take = Math.max(0, segments0.length - trailing);
        return take === 0 ? "/" : "/" + segments0.slice(0, take).join("/");
      }
      const depth = Number(spec);
      if (depth <= 0) return "/";
      return "/" + segments0.slice(0, depth).join("/");
    }
  }

  const fullCandidate = segments0.join("/");
  if (
    noLayouts.includes(fullCandidate) ||
    noLayouts.some((nl) => {
      const lSegs = nl
        .split("/")
        .filter(Boolean)
        .filter((seg) => !(seg.startsWith("(") && seg.endsWith(")")));
      if (lSegs.length !== segments0.length) return false;
      return lSegs.every((seg, idx) => {
        if (seg.startsWith("[") && seg.endsWith("]")) return true;
        return seg === segments0[idx];
      });
    })
  ) {
    return null;
  }
  const cleanPath = pathname.split("?")[0].split("#")[0];
  const segments = cleanPath.split("/").filter(Boolean);

  for (let i = segments.length; i >= 1; i--) {
    const candidateSegments = segments.slice(0, i);
    const candidate = candidateSegments.join("/");
    if (layouts.includes(candidate)) {
      return "/" + candidate;
    }
    const dynamicMatch = layouts.find((l) => {
      const lSegs = l
        .split("/")
        .filter(Boolean)
        .filter((seg) => !(seg.startsWith("(") && seg.endsWith(")")));
      if (lSegs.length !== candidateSegments.length) return false;
      return lSegs.every((seg, idx) => {
        if (seg.startsWith("[") && seg.endsWith("]")) return true;
        return seg === candidateSegments[idx];
      });
    });
    if (dynamicMatch) {
      return "/" + candidate;
    }
  }
  if (
    layouts.includes("") ||
    layouts.includes("/") ||
    layouts.some(
      (l) =>
        l
          .split("/")
          .filter(Boolean)
          .filter((s) => !(s.startsWith("(") && s.endsWith(")"))).length === 0
    )
  ) {
    return "/";
  }
  return null;
};

// Helper to detect if we only change the hash on the same page
const isHashChangeOnly = (finalPath) => {
  const targetUrl = new URL(finalPath, window.location.origin);
  const normalize = (p) =>
    p.length > 1 && p.endsWith("/") ? p.slice(0, -1) : p;

  const targetPath = normalize(targetUrl.pathname);
  const currentPath = normalize(window.location.pathname);

  return (
    targetPath + targetUrl.search === currentPath + window.location.search &&
    targetUrl.hash !== ""
  );
};

const consumeInlineRscResponse = (kind) => {
  if (typeof window === "undefined" || !window.__DINOU_INLINE_RSC__) {
    return null;
  }
  const consumedFlag = `__DINOU_RSC_${kind}_CONSUMED__`;
  if (window[consumedFlag]) {
    return null;
  }
  window[consumedFlag] = true;

  const arrName = `__DINOU_RSC_${kind}__`;
  const doneName = `__DINOU_RSC_${kind}_DONE__`;
  const pushFnName = `__DINOU_RSC_${kind}_PUSH__`;
  const closeFnName = `__DINOU_RSC_${kind}_CLOSE__`;

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    start(controller) {
      let closed = false;
      const existing = window[arrName];
      if (Array.isArray(existing)) {
        for (const chunk of existing) {
          if (chunk) controller.enqueue(encoder.encode(chunk));
        }
        existing.length = 0;
      }
      if (window[doneName]) {
        closed = true;
        controller.close();
        return;
      }
      window[pushFnName] = (chunk) => {
        if (closed || !chunk) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch (e) {}
      };
      window[closeFnName] = () => {
        if (closed) return;
        closed = true;
        try {
          controller.close();
        } catch (e) {}
      };
      if (document.readyState === "complete" && !window[doneName]) {
        setTimeout(() => {
          if (!closed) {
            closed = true;
            try {
              controller.close();
            } catch (e) {}
          }
        }, 0);
      }
    },
  });

  return new Response(stream, {
    status: 200,
    headers: { "Content-Type": "text/x-component" },
  });
};

const isStaticExportMode = () =>
  typeof window !== "undefined" && Boolean(window.__DINOU_STATIC_EXPORT__);

const isNavigationAbortError = (err) => {
  if (!err) return false;
  const name = typeof err === "object" ? String(err.name || "") : "";
  const msg = typeof err === "object" ? String(err.message || "") : String(err);
  return (
    name === "AbortError" ||
    /^(?:Load failed|Failed to fetch|NetworkError|The operation was aborted|Error in input stream|Connection closed)/i.test(
      msg.trim()
    ) ||
    /____(?:rsc_[a-z_]+|server_function)____.*due to access control checks/i.test(msg)
  );
};

const activeClientFetchControllers = new Set();

const abortAwareFetch = (url, init = {}) => {
  if (isStaticExportUnloading()) {
    return new Promise(() => {});
  }
  const controller =
    typeof AbortController !== "undefined" ? new AbortController() : null;
  if (controller) {
    activeClientFetchControllers.add(controller);
  }
  return fetch(url, {
    ...init,
    signal: controller ? controller.signal : init.signal,
  }).finally(() => {
    if (controller) {
      activeClientFetchControllers.delete(controller);
    }
  });
};

if (typeof window !== "undefined") {
  const markDocumentUnloading = () => {
    window.__DINOU_STATIC_EXPORT_UNLOADING__ = true;
    for (const controller of activeClientFetchControllers) {
      try {
        controller.abort();
      } catch {}
    }
    activeClientFetchControllers.clear();
  };
  window.addEventListener("beforeunload", markDocumentUnloading);
  window.addEventListener("pagehide", markDocumentUnloading);
  window.addEventListener("pageshow", (event) => {
    if (event && event.persisted) {
      window.__DINOU_STATIC_EXPORT_UNLOADING__ = false;
    }
  });
  window.addEventListener("unhandledrejection", (event) => {
    if (isStaticExportUnloading() || isNavigationAbortError(event?.reason)) {
      event.preventDefault();
    }
  });
  window.addEventListener("error", (event) => {
    if (
      isStaticExportUnloading() ||
      isNavigationAbortError(event?.error || event?.message)
    ) {
      event.preventDefault();
    }
  });
  // Detect pre-hydration native <a href> hard navigations (before Router's useEffect
  // attaches soft-navigation click handling) so WebKit does not abort in-flight PPR
  // streams into spurious /____rsc_payload_error____ fetches before beforeunload fires.
  window.addEventListener("click", (e) => {
    if (e.defaultPrevented || window.__DINOU_ROUTER_NAVIGATE__) return;
    if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    const target = e.target;
    const anchor = target && typeof target.closest === "function" ? target.closest("a") : null;
    if (!anchor || (anchor.target && anchor.target !== "_self") || anchor.hasAttribute("download")) {
      return;
    }
    const href = anchor.getAttribute("href");
    if (!href || /^(?:mailto:|tel:|javascript:|#)/i.test(href.trim())) return;
    const finalPath = resolveUrl(href, window.location.pathname);
    if (!isExternalUrl(finalPath) && isHashChangeOnly(finalPath)) return;
    window.__DINOU_STATIC_EXPORT_UNLOADING__ = true;
  });
}

const isStaticExportUnloading = () =>
  typeof window !== "undefined" && Boolean(window.__DINOU_STATIC_EXPORT_UNLOADING__);

// Static-export .rsc payloads are pre-rendered static files (not streaming SSR).
// Buffer the body into an in-memory ArrayBuffer before handing a Response to
// createFromFetch so that triggering window.location.replace() on a non-RSC
// fallback cannot abort an in-flight network ReadableStream (e.g. Firefox's
// "Error in input stream") inside React Flight's stream reader.
const bufferStaticExportResponse = (res) => {
  if (isStaticExportUnloading()) {
    return new Promise(() => {});
  }
  return res.arrayBuffer().then(
    (buf) => {
      if (isStaticExportUnloading()) {
        return new Promise(() => {});
      }
      return new Response(buf, {
        status: res.status,
        statusText: res.statusText,
        headers: {
          "Content-Type": res.headers.get("content-type") || "text/x-component",
        },
      });
    },
    (err) => {
      if (isStaticExportUnloading()) {
        return new Promise(() => {});
      }
      throw err;
    }
  );
};

const buildStaticExportRscUrl = (rawRouteOrKey, fileName) => {
  const withoutHash = String(rawRouteOrKey || "/").split("#")[0];
  const qIdx = withoutHash.indexOf("?");
  const rawPathname = qIdx === -1 ? withoutHash : withoutHash.slice(0, qIdx);
  const existingQuery = qIdx === -1 ? "" : withoutHash.slice(qIdx + 1);
  const encodedSegments = rawPathname
    .split("/")
    .filter(Boolean)
    .map((seg) => encodeURIComponent(safeDecodeSeg(seg)));
  const baseRscPath =
    encodedSegments.length > 0
      ? `/${encodedSegments.join("/")}/${fileName}`
      : `/${fileName}`;
  return existingQuery ? `${baseRscPath}?${existingQuery}` : baseRscPath;
};

const wrapAbortSafeResponse = (res) => {
  if (
    !res ||
    !res.body ||
    typeof res.body.getReader !== "function" ||
    typeof ReadableStream === "undefined"
  ) {
    return res;
  }
  const reader = res.body.getReader();
  const safeBody = new ReadableStream({
    async pull(controller) {
      try {
        const { done, value } = await reader.read();
        if (done) {
          controller.close();
        } else {
          controller.enqueue(value);
        }
      } catch (err) {
        if (isStaticExportUnloading() || isNavigationAbortError(err)) {
          return new Promise(() => {});
        }
        controller.error(err);
      }
    },
    cancel(reason) {
      return reader.cancel(reason).catch(() => {});
    },
  });
  return new Response(safeBody, {
    status: res.status,
    statusText: res.statusText,
    headers: res.headers,
  });
};

const sanitizeRedirectUrl = (candidate) => {
  if (typeof candidate !== "string" || candidate.length === 0) return null;
  if (/[\u0000-\u001F\u007F]/.test(candidate)) return null;
  if (candidate !== candidate.trim()) return null;
  if (candidate.startsWith("/")) {
    if (/^\/[\/\\]/.test(candidate)) return null;
    const pathOnly = candidate.split("?")[0].split("#")[0];
    if (pathOnly.includes("\\")) return null;
    try {
      const parsed = new URL(candidate, "http://dinou.invalid");
      return parsed.origin === "http://dinou.invalid" ? candidate : null;
    } catch {
      return null;
    }
  }
  if (/^https?:\/\//i.test(candidate)) {
    try {
      const parsed = new URL(candidate);
      if ((parsed.protocol === "http:" || parsed.protocol === "https:") && parsed.hostname) {
        return candidate;
      }
    } catch {}
  }
  return null;
};

const executeRscRedirect = (redirectUrl) => {
  if (!redirectUrl || typeof window === "undefined") return;
  const safeTarget = sanitizeRedirectUrl(redirectUrl) || "/";
  if (/^https?:\/\//i.test(safeTarget) || !window.__DINOU_ROUTER_NAVIGATE__) {
    window.__DINOU_STATIC_EXPORT_UNLOADING__ = true;
    window.location.href = safeTarget;
    return;
  }
  if (getCurrentRoute() !== safeTarget) {
    window.__DINOU_ROUTER_NAVIGATE__(safeTarget, { replace: true });
  }
};

const erroredPageCacheKeys = new Set();
const erroredLayoutCacheKeys = new Set();
const volatilePageCacheKeys = new Set();
const volatileLayoutCacheKeys = new Set();

const normalizeCachePathname = (p) => {
  const clean = String(p || "/").split("?")[0].split("#")[0] || "/";
  const segs = clean.split("/").filter(Boolean).map(safeDecodeSeg);
  return segs.length > 0 ? "/" + segs.join("/") : "/";
};

const invalidateClientRouterCache = (hint) => {
  if (!hint || typeof hint !== "object") return;
  if (hint.allPages) {
    pageCache.clear();
    volatilePageCacheKeys.clear();
  } else if (Array.isArray(hint.pages) && hint.pages.length > 0) {
    const pageTargets = new Set(hint.pages.map(normalizeCachePathname));
    for (const k of Array.from(pageCache.keys())) {
      const kPath = normalizeCachePathname(k);
      if (pageTargets.has(kPath)) {
        pageCache.delete(k);
        volatilePageCacheKeys.delete(k);
      }
    }
  }
  if (hint.allLayouts) {
    layoutCache.clear();
    volatileLayoutCacheKeys.clear();
  } else if (Array.isArray(hint.layouts) && hint.layouts.length > 0) {
    const layoutTargets = hint.layouts.map(normalizeCachePathname);
    for (const k of Array.from(layoutCache.keys())) {
      const kPath = normalizeCachePathname(k);
      const matchesLayout = layoutTargets.some(
        (t) => t === "/" || kPath === t || kPath.startsWith(t + "/")
      );
      if (matchesLayout) {
        layoutCache.delete(k);
        volatileLayoutCacheKeys.delete(k);
      }
    }
  }
};

if (typeof window !== "undefined") {
  window.__DINOU_INVALIDATE_CLIENT_CACHE__ = invalidateClientRouterCache;
}

const clearErroredCaches = () => {
  if (
    typeof document !== "undefined" &&
    document.querySelector('[data-dinou-ppr-error="true"]')
  ) {
    const curRoute = getCurrentRoute();
    pageCache.delete(curRoute);
    const curLayoutKey = getLayoutKey(window.location.pathname);
    if (curLayoutKey) {
      const curSearch = window.location.search || "";
      layoutCache.delete(curLayoutKey);
      layoutCache.delete(`${curLayoutKey}${curSearch}`);
    }
  }
  for (const k of erroredPageCacheKeys) {
    pageCache.delete(k);
  }
  erroredPageCacheKeys.clear();
  for (const k of Array.from(pageCache.keys())) {
    if (String(k).startsWith("error::")) {
      pageCache.delete(k);
    }
  }
  for (const k of erroredLayoutCacheKeys) {
    layoutCache.delete(k);
  }
  erroredLayoutCacheKeys.clear();
};

const INITIAL_HYDRATION_RETRY_DELAYS = [60, 180, 450];

const fetchWithInitialHydrationRetry = (fetchOnce, isInitialHydration) => {
  const attempt = (retryIdx) =>
    fetchOnce().catch((err) => {
      if (
        isInitialHydration &&
        !isStaticExportUnloading() &&
        isNavigationAbortError(err) &&
        retryIdx < INITIAL_HYDRATION_RETRY_DELAYS.length
      ) {
        const delayMs = INITIAL_HYDRATION_RETRY_DELAYS[retryIdx];
        return new Promise((resolve) => setTimeout(resolve, delayMs)).then(() =>
          isStaticExportUnloading() ? new Promise(() => {}) : attempt(retryIdx + 1)
        );
      }
      throw err;
    });
  return attempt(0);
};

const getPagePayload = (route, isPrefetch = false, version = 0) => {
  const url = route.split("::")[0].split("#")[0] || "/";
  if (pageCache.has(url)) {
    return getBoundedCacheEntry(pageCache, url);
  }

  const staticExport = isStaticExportMode();
  if (isStaticExportUnloading()) {
    const pendingPromise = createFromFetch(new Promise(() => {}), {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      },
    });
    pendingPromise.catch(() => {});
    setBoundedPageCache(url, pendingPromise);
    return pendingPromise;
  }
  let payloadUrl;
  if (staticExport) {
    payloadUrl = buildStaticExportRscUrl(url, "page.rsc");
  } else if (window.__DINOU_USE_OLD_RSC__ || window.__DINOU_USE_STATIC__) {
    payloadUrl = window.__DINOU_USE_OLD_RSC__
      ? window.__DINOU_USE_STATIC__
        ? "/____rsc_page_old_static____" + url
        : "/____rsc_page_old____" + url
      : window.__DINOU_USE_STATIC__
        ? "/____rsc_page_static____" + url
        : "/____rsc_page____" + url;
  } else {
    payloadUrl = "/____rsc_page____" + url;
  }

  const isInitialHydration =
    !isPrefetch &&
    typeof document !== "undefined" &&
    (!document.body || document.body.getAttribute("data-hydrated") !== "true");
  const buildId =
    staticExport || isInitialHydration ? window.__DINOU_BUILD_ID__ : undefined;
  if (buildId && !version) {
    payloadUrl += (payloadUrl.includes("?") ? "&" : "?") + "____build_id____=" + buildId;
  }
  if (version) {
    payloadUrl += (payloadUrl.includes("?") ? "&" : "?") + "____v____=" + version;
  }

  const inlineRes = isInitialHydration && !version ? consumeInlineRscResponse("P") : null;
  if (inlineRes && typeof window !== "undefined") {
    const initPageMode = String(window.__DINOU_PAGE_CACHE_MODE__ || "").toLowerCase();
    window.__DINOU_PAGE_CACHE_MODE__ = null;
    if (initPageMode === "ppr") {
      volatilePageCacheKeys.add(url);
    }
  }
  const fetchPageOnce = () =>
    abortAwareFetch(payloadUrl, {
      cache: staticExport && !version ? "default" : "no-store",
    });
  const fetchPromise = inlineRes
    ? Promise.resolve(inlineRes)
    : fetchWithInitialHydrationRetry(fetchPageOnce, isInitialHydration)
        .then((res) => {
        if (res.headers.has("x-rsc-redirect")) {
          const redirectUrl = res.headers.get("x-rsc-redirect");
          const isCurrentTarget =
            typeof window !== "undefined" &&
            getCurrentRoute() === url.split("#")[0];
          pageCache.delete(url);
          if (isCurrentTarget && redirectUrl) {
            executeRscRedirect(redirectUrl);
          }
          return new Promise(() => {});
        }
        if (isStaticExportUnloading()) {
          return new Promise(() => {});
        }
        if (
          staticExport &&
          (!res.ok ||
            (res.headers.get("content-type") || "").toLowerCase().includes("text/html"))
        ) {
          if (!isPrefetch && !isInitialHydration) {
            window.__DINOU_STATIC_EXPORT_UNLOADING__ = true;
            window.location.replace(url);
          } else {
            pageCache.delete(url);
          }
          return new Promise(() => {});
        }
        if (staticExport) {
          return bufferStaticExportResponse(res);
        }
        if (res.status >= 500 || res.headers.get("x-dinou-has-error") === "true") {
          erroredPageCacheKeys.add(url);
        }
        const cacheMode = (res.headers.get("x-dinou-cache-mode") || "").toLowerCase();
        if (cacheMode === "ppr") {
          volatilePageCacheKeys.add(url);
        } else if (cacheMode === "static" || cacheMode === "dynamic") {
          volatilePageCacheKeys.delete(url);
        }
        return wrapAbortSafeResponse(res);
      }, (err) => {
        if (isStaticExportUnloading() || isNavigationAbortError(err)) {
          return new Promise(() => {});
        }
        throw err;
      });

  const promise = createFromFetch(
    fetchPromise,
    {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      },
    }
  );

  promise.catch(() => {});
  setBoundedPageCache(url, promise);
  return promise;
};

const getLayoutPayload = (layoutKey, searchPart = "", version = 0) => {
  if (!layoutKey) return null;
  const staticExport = isStaticExportMode();
  const cacheKey = staticExport ? layoutKey : `${layoutKey}${searchPart}`;
  if (layoutCache.has(cacheKey)) {
    return getBoundedCacheEntry(layoutCache, cacheKey);
  }
  if (isStaticExportUnloading()) {
    const pendingPromise = createFromFetch(new Promise(() => {}), {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      },
    });
    pendingPromise.catch(() => {});
    setBoundedLayoutCache(cacheKey, pendingPromise);
    return pendingPromise;
  }

  const isInitialHydration =
    typeof document !== "undefined" &&
    (!document.body || document.body.getAttribute("data-hydrated") !== "true");
  const buildId =
    staticExport || isInitialHydration ? window.__DINOU_BUILD_ID__ : undefined;
  const cleanKey = layoutKey === "/" ? "" : layoutKey;
  let layoutUrl = staticExport
    ? buildStaticExportRscUrl((cleanKey || "/") + searchPart, "layout.rsc")
    : (window.__DINOU_USE_STATIC__
        ? "/____rsc_layout_static____"
        : "/____rsc_layout____") + cleanKey + searchPart;

  if (buildId && !version) {
    layoutUrl += (layoutUrl.includes("?") ? "&" : "?") + "____build_id____=" + buildId;
  }

  if (version) {
    layoutUrl += (layoutUrl.includes("?") ? "&" : "?") + "____v____=" + version;
  }

  const inlineRes = isInitialHydration && !version ? consumeInlineRscResponse("L") : null;
  const fetchLayoutOnce = () =>
    abortAwareFetch(layoutUrl, {
      cache: staticExport && !version ? "default" : "no-store",
    });
  const fetchPromise = inlineRes
    ? Promise.resolve(inlineRes)
    : fetchWithInitialHydrationRetry(fetchLayoutOnce, isInitialHydration)
        .then(
        (res) => {
          if (res.headers.has("x-rsc-redirect")) {
            const redirectUrl = res.headers.get("x-rsc-redirect");
            const isCurrentLayout =
              typeof window !== "undefined" &&
              getLayoutKey(window.location.pathname) === layoutKey;
            layoutCache.delete(cacheKey);
            if (isCurrentLayout && redirectUrl) {
              executeRscRedirect(redirectUrl);
            }
            return new Promise(() => {});
          }
          if (isStaticExportUnloading()) {
            return new Promise(() => {});
          }
          if (
            staticExport &&
            (!res.ok ||
              (res.headers.get("content-type") || "").toLowerCase().includes("text/html"))
          ) {
            layoutCache.delete(cacheKey);
            return new Promise(() => {});
          }
          if (staticExport) {
            return bufferStaticExportResponse(res);
          }
          if (!res.ok) {
            console.warn(
              `[Dinou Router] Layout ${layoutKey} fetch returned status ${res.status}`
            );
          }
          if (res.status >= 500 || res.headers.get("x-dinou-has-error") === "true") {
            erroredLayoutCacheKeys.add(cacheKey);
          }
          const layoutCacheMode = (res.headers.get("x-dinou-cache-mode") || "").toLowerCase();
          if (layoutCacheMode === "ppr") {
            volatileLayoutCacheKeys.add(cacheKey);
          } else if (layoutCacheMode === "static" || layoutCacheMode === "dynamic") {
            volatileLayoutCacheKeys.delete(cacheKey);
          }
          return wrapAbortSafeResponse(res);
        },
        (err) => {
          if (isStaticExportUnloading() || isNavigationAbortError(err)) {
            return new Promise(() => {});
          }
          throw err;
        }
      );

  const promise = createFromFetch(
    fetchPromise,
    {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      },
    }
  );

  promise.catch(() => {});
  setBoundedLayoutCache(cacheKey, promise);
  return promise;
};

const getErrorRSCPayload = (route, error) => {
  if (isStaticExportMode()) {
    return null;
  }
  if (isStaticExportUnloading() || isNavigationAbortError(error)) {
    return new Promise(() => {});
  }
  const url = route.split("::")[0];
  const cacheKey = `error::${url}::${error.message || String(error)}`;
  if (pageCache.has(cacheKey)) {
    return getBoundedCacheEntry(pageCache, cacheKey);
  }

  const payloadUrl = "/____rsc_payload_error____" + url;
  const promise = createFromFetch(
    abortAwareFetch(payloadUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        error: {
          message: error.message || "Unknown Error",
          name: error.name,
          ...(typeof error.digest === "string" ? { digest: error.digest } : {}),
          stack: error.stack,
        },
      }),
    }).then(
      (res) => {
        if (isStaticExportUnloading()) {
          return new Promise(() => {});
        }
        if (res.headers.has("x-rsc-redirect")) {
          const redirectUrl = res.headers.get("x-rsc-redirect");
          pageCache.delete(cacheKey);
          executeRscRedirect(redirectUrl);
          return new Promise(() => {});
        }
        return res;
      },
      (err) => {
        if (isStaticExportUnloading() || isNavigationAbortError(err)) {
          return new Promise(() => {});
        }
        throw err;
      }
    ),
    {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      }
    }
  );
  promise.catch(() => {});
  setBoundedPageCache(cacheKey, promise);
  return promise;
};

const fetchSlotRSC = (slotId, options = {}) => {
  if (isStaticExportMode() || isStaticExportUnloading()) {
    return new Promise(() => {});
  }
  const currentPath =
    (options && options.currentPath) ||
    (typeof window !== "undefined" ? window.location.pathname : "/");
  const freshQuery = options && options.fresh ? "&fresh=1" : "";
  const slotSeq = (window.__DINOU_SLOT_SEQ__ = (window.__DINOU_SLOT_SEQ__ || 0) + 1);
  const slotUrl = `/____rsc_slot____/${encodeURIComponent(slotId)}?t=${Date.now()}-${slotSeq}${freshQuery}`;
  return createFromFetch(
    abortAwareFetch(slotUrl, {
      headers: {
        "x-dinou-current-path": currentPath,
      },
    }).then(
      (res) => (isStaticExportUnloading() ? new Promise(() => {}) : res),
      (err) => {
        if (isStaticExportUnloading() || isNavigationAbortError(err)) {
          return new Promise(() => {});
        }
        throw err;
      }
    ),
    {
      callServer: async (id, args) => {
        const proxy = createServerFunctionProxy(id);
        return proxy(...args);
      },
    }
  );
};

export const refreshSlot = (slotId, options) => {
  if (typeof window !== "undefined") {
    if (isStaticExportMode() || isStaticExportUnloading()) {
      return Promise.resolve();
    }
    flushPendingSsrStreams();
    const promises = [];
    window.dispatchEvent(
      new CustomEvent("dinou:refresh-slot", {
        detail: { id: slotId, options, promises },
      })
    );
    return Promise.all(promises).then(() => undefined);
  }
  return Promise.resolve();
};

if (typeof globalThis !== "undefined") {
  globalThis.__DINOU_GET_ERROR_RSC_PAYLOAD__ = getErrorRSCPayload;
  globalThis.__DINOU_FETCH_SLOT__ = fetchSlotRSC;
  globalThis.__DINOU_REFRESH_SLOT__ = refreshSlot;
  globalThis.__DINOU_CLEAR_ERROR_CACHES__ = clearErroredCaches;
}

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    if (isStaticExportUnloading() || isNavigationAbortError(error)) return;
    console.error("[Dinou] ErrorBoundary caught error:", error, errorInfo);
    if (this.props.onError) {
      this.props.onError(error);
    }
  }

  componentDidUpdate(prevProps) {
    if (this.state.hasError && prevProps.resetKey !== this.props.resetKey) {
      this.setState({ hasError: false, error: null });
    }
  }

  render() {
    if (this.state.hasError) {
      if (isStaticExportUnloading() || isNavigationAbortError(this.state.error)) {
        return null;
      }
      if (this.props.fallback) {
        return this.props.fallback(this.state.error);
      }
      const isDev = process.env.NODE_ENV !== "production";
      return (
        <html lang="en">
          <head>
            <meta charSet="UTF-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <title>{isDev ? "Dinou Dev Error" : "Application Error"}</title>
          </head>
          <body
            style={{
              margin: 0,
              backgroundColor: "#fff1f2",
              padding: "20px",
              boxSizing: "border-box",
            }}
          >
            <div
              style={{
                fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
                padding: "32px",
                maxWidth: "960px",
                margin: "40px auto",
                backgroundColor: "#fff1f2",
                border: "1px solid #fecdd3",
                borderRadius: "12px",
                color: "#9f1239",
                boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
                <span
                  style={{
                    background: "#e11d48",
                    color: "white",
                    padding: "2px 8px",
                    borderRadius: "9999px",
                    fontSize: "12px",
                    fontWeight: "bold",
                  }}
                >
                  {isDev ? "Dinou Dev Error" : "Application Error"}
                </span>
                <h2 style={{ margin: 0, fontSize: "1.25rem", fontWeight: 700, color: "#881337" }}>
                  {this.state.error?.message || "Unhandled Application Error"}
                </h2>
              </div>
              {isDev && (
                <p style={{ margin: "0 0 16px 0", fontSize: "0.875rem", color: "#9f1239", lineHeight: 1.5 }}>
                  An unhandled error occurred during rendering. You can provide a custom error UI by creating an{" "}
                  <code style={{ background: "#ffe4e6", padding: "2px 6px", borderRadius: "4px", fontWeight: 600 }}>
                    error.tsx
                  </code>{" "}
                  file in your route folder.
                </p>
              )}
              {isDev && this.state.error?.stack && (
                <pre
                  style={{
                    background: "#0f172a",
                    color: "#f8fafc",
                    padding: "16px",
                    borderRadius: "8px",
                    overflowX: "auto",
                    fontSize: "0.8125rem",
                    lineHeight: 1.6,
                    fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
                  }}
                >
                  {cleanErrorStack(this.state.error.stack)}
                </pre>
              )}
            </div>
          </body>
        </html>
      );
    }
    return this.props.children;
  }
}


// ====================================================================
// 3. ROUTER COMPONENT
// ====================================================================

function Router() {
  const [route, setRoute] = useState(getCurrentRoute());
  const [isPopState, setIsPopState] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [version, setVersion] = useState(0);
  const [layoutVersion, setLayoutVersion] = useState(0);
  const [navError, setNavError] = useState(null);
  const [navCount, setNavCount] = useState(0);

  // If the initial SSR render had a page-level error wrapped inside a working layout,
  // we hydrate the layout normally so the navbar/sidebar are fully interactive,
  // while supplying the server error directly to DinouPageSlot to avoid refetching.
  const initialPageErrorRef = useRef(
    typeof window !== "undefined" &&
    window.__DINOU_ERROR_MESSAGE__ &&
    window.__DINOU_ERROR_SEGMENT__ === "page"
      ? (() => {
          const err = new Error(window.__DINOU_ERROR_MESSAGE__);
          err.name = window.__DINOU_ERROR_NAME__ || "Error";
          if (window.__DINOU_ERROR_DIGEST__) err.digest = window.__DINOU_ERROR_DIGEST__;
          if (window.__DINOU_ERROR_STACK__) err.stack = window.__DINOU_ERROR_STACK__;
          return getErrorRSCPayload(getCurrentRoute(), err);
        })()
      : null
  );

  // 🧭 NAVIGATE FUNCTION (Core Logic)
  const navigate = (href, options = {}) => {
    initialPageErrorRef.current = null;
    if (typeof window !== "undefined" && window.__DINOU_ACTIVE_LAYOUT__) {
      window.__DINOU_ACTIVE_LAYOUT__ = null;
    }
    const finalPath = resolveUrl(href, window.location.pathname);

    if (isExternalUrl(finalPath)) {
      if (!sanitizeRedirectUrl(finalPath)) {
        return;
      }
      window.__DINOU_STATIC_EXPORT_UNLOADING__ = true;
      if (options.replace) {
        window.location.replace(finalPath);
      } else {
        window.location.assign(finalPath);
      }
      return;
    }
    if (
      typeof finalPath === "string" &&
      (/[\u0000-\u001F\u007F]/.test(finalPath) ||
        /^\/[\/\\]/.test(finalPath) ||
        finalPath.split("?")[0].split("#")[0].includes("\\"))
    ) {
      return;
    }

    // 🛡️ NAVIGATE PROTECTION: Hash Detection
    if (isHashChangeOnly(finalPath)) {
      if (options.replace) {
        window.history.replaceState(null, "", finalPath);
      } else {
        window.history.pushState(null, "", finalPath);
      }

      // Manual scroll
      const hash = new URL(finalPath, window.location.origin).hash;
      const id = hash.replace("#", "");
      const element = document.getElementById(id);
      if (element) {
        element.scrollIntoView({ behavior: "auto" });
      }
      return; // CRITICAL STOP
    }

    const routeWithoutHash = finalPath.split("#")[0] || "/";

    clearErroredCaches();
    const isVolatilePage = volatilePageCacheKeys.has(routeWithoutHash);
    if (options.fresh || isVolatilePage) {
      pageCache.delete(routeWithoutHash);
      volatilePageCacheKeys.delete(routeWithoutHash);
    }
    const prevLayoutKey = getLayoutKey(window.location.pathname);
    const nextPathOnly = routeWithoutHash.split("?")[0] || "/";
    const nextSearchOnly = routeWithoutHash.includes("?")
      ? "?" + routeWithoutHash.split("?")[1]
      : "";
    const nextLayoutKey = getLayoutKey(nextPathOnly);
    const nextLayoutCacheKey = nextLayoutKey
      ? isStaticExportMode()
        ? nextLayoutKey
        : `${nextLayoutKey}${nextSearchOnly}`
      : null;
    let shouldBumpLayoutVersion = false;
    if (nextLayoutCacheKey) {
      if (
        nextLayoutKey !== prevLayoutKey &&
        volatileLayoutCacheKeys.has(nextLayoutCacheKey)
      ) {
        layoutCache.delete(nextLayoutCacheKey);
        volatileLayoutCacheKeys.delete(nextLayoutCacheKey);
      } else if (
        options.fresh &&
        nextLayoutKey === prevLayoutKey &&
        !layoutCache.has(nextLayoutCacheKey)
      ) {
        shouldBumpLayoutVersion = true;
      }
    }

    // Normal RSC Navigation
    setBoundedScrollCache(
      window.location.pathname + window.location.search,
      window.scrollY,
    );
    if (options.replace) {
      window.history.replaceState(null, "", finalPath);
    } else {
      window.history.pushState(null, "", finalPath);
    }

    flushPendingSsrStreams();
    startTransition(() => {
      setIsPopState(false);
      setRoute(routeWithoutHash);
      if (options.fresh || (isVolatilePage && routeWithoutHash === route)) {
        setVersion((v) => v + 1);
      }
      if (shouldBumpLayoutVersion) {
        setLayoutVersion((v) => v + 1);
      }
      setNavError(null);
      setNavCount((c) => c + 1);
    });
  };

  const back = () => window.history.back();
  const forward = () => window.history.forward();
  const refresh = useCallback((options = {}) => {
    initialPageErrorRef.current = null;
    clearErroredCaches();
    if (typeof window !== "undefined" && window.__DINOU_ACTIVE_LAYOUT__) {
      window.__DINOU_ACTIVE_LAYOUT__ = null;
    }
    const currentPathname = window.location.pathname;
    const currentPath = currentPathname + window.location.search;
    pageCache.delete(currentPath);
    for (const k of pageCache.keys()) {
      if (k === currentPathname || k.startsWith(currentPathname + "?")) {
        pageCache.delete(k);
      }
    }

    const shouldRefreshLayout = Boolean(options && options.layout);
    if (shouldRefreshLayout) {
      const currentLayoutKey = getLayoutKey(currentPathname);
      if (currentLayoutKey) {
        for (const k of layoutCache.keys()) {
          if (k === currentLayoutKey || k.startsWith(currentLayoutKey + "?")) {
            layoutCache.delete(k);
          }
        }
      }
    }

    flushPendingSsrStreams();
    startTransition(() => {
      setVersion((v) => v + 1);
      if (shouldRefreshLayout) {
        setLayoutVersion((v) => v + 1);
      }
      setNavError(null);
      setNavCount((c) => c + 1);
    });
  }, [startTransition]);

  // 🔌 EFFECT 1: Expose Global Prefetch & Navigation
  useEffect(() => {
    window.__DINOU_PREFETCH__ = (url) => {
      // 🛡️ PREFETCH PROTECTION: If it's a local hash, do nothing
      if (isHashChangeOnly(url)) return;
      const cleanUrl = String(url || "/").split("#")[0] || "/";
      const prefetchSearchPart = cleanUrl.includes("?")
        ? "?" + cleanUrl.split("?")[1]
        : "";
      const lKey = getLayoutKey(cleanUrl);
      const prefetchLayoutCacheKey = isStaticExportMode()
        ? lKey
        : `${lKey}${prefetchSearchPart}`;
      if (lKey && !layoutCache.has(prefetchLayoutCacheKey)) {
        getLayoutPayload(lKey, prefetchSearchPart);
      }
      getPagePayload(cleanUrl, true);
    };

    window.__DINOU_ROUTER_NAVIGATE__ = navigate;
    window.__DINOU_ROUTER_REFRESH__ = refresh;

    // Hydration
    flushPendingSsrStreams();
    document.body.setAttribute("data-hydrated", "true");

    return () => {
      if (window.__DINOU_ROUTER_NAVIGATE__ === navigate) {
        window.__DINOU_ROUTER_NAVIGATE__ = undefined;
      }
      if (window.__DINOU_ROUTER_REFRESH__ === refresh) {
        window.__DINOU_ROUTER_REFRESH__ = undefined;
      }
    };
  }, [navigate, refresh]);

  // 🔌 EFFECT 2: Global Listeners (Click and PopState)
  useEffect(() => {
    if ("scrollRestoration" in window.history) {
      window.history.scrollRestoration = "manual";
    }

    const onNavigate = (e) => {
      // 🛡️ FIX: If the event was already processed (preventDefault called by Link), we ignore it.
      if (e.defaultPrevented) return;
      const anchor = e.target.closest("a");
      if (
        !anchor ||
        (anchor.target && anchor.target !== "_self") ||
        anchor.hasAttribute("download") ||
        e.button !== 0 ||
        e.metaKey ||
        e.ctrlKey ||
        e.shiftKey ||
        e.altKey
      ) {
        return;
      }

      const href = anchor.getAttribute("href");
      if (!href || href.startsWith("mailto:") || href.startsWith("tel:") || isExternalUrl(href))
        return;

      // We use the unified helper
      const finalPath = resolveUrl(href, window.location.pathname);

      // We use the same hash detection helper for consistency
      if (isHashChangeOnly(finalPath)) {
        return; // The browser handles it natively or navigate would handle it
      }

      e.preventDefault();
      navigate(href);
    };

    const onPopState = () => {
      initialPageErrorRef.current = null;
      clearErroredCaches();
      if (typeof window !== "undefined" && window.__DINOU_ACTIVE_LAYOUT__) {
        window.__DINOU_ACTIVE_LAYOUT__ = null;
      }
      const target = getCurrentRoute();
      flushPendingSsrStreams();
      startTransition(() => {
        setIsPopState(true);
        setRoute(target);
        setNavError(null);
        setNavCount((c) => c + 1);
      });

      if (window.location.hash) {
        requestAnimationFrame(() => {
          if (!scrollToCurrentHash()) {
            let frames = 0;
            const interval = setInterval(() => {
              frames++;
              if (scrollToCurrentHash() || frames > 20) {
                clearInterval(interval);
              }
            }, 50);
          }
        });
      } else if (target === route) {
        requestAnimationFrame(() => {
          const savedY = scrollCache.get(target);
          if (savedY !== undefined) {
            window.scrollTo(0, savedY);
          } else {
            window.scrollTo(0, 0);
          }
        });
      }
    };

    const onHashChange = () => {
      if (window.location.hash) {
        requestAnimationFrame(() => {
          if (!scrollToCurrentHash()) {
            let frames = 0;
            const interval = setInterval(() => {
              frames++;
              if (scrollToCurrentHash() || frames > 20) {
                clearInterval(interval);
              }
            }, 50);
          }
        });
      }
    };

    window.addEventListener("click", onNavigate);
    window.addEventListener("popstate", onPopState);
    window.addEventListener("hashchange", onHashChange);

    return () => {
      window.removeEventListener("click", onNavigate);
      window.removeEventListener("popstate", onPopState);
      window.removeEventListener("hashchange", onHashChange);
    };
  }, [route]);

  // 🔌 EFFECT 3: Scroll Management (Restoration)
  useLayoutEffect(() => {
    requestAnimationFrame(() => {
      if (window.location.hash) return;

      if (isPopState) {
        const key = route;
        const savedY = scrollCache.get(key);
        if (savedY !== undefined) {
          window.scrollTo(0, savedY);
        }
      } else {
        window.scrollTo(0, 0);
      }
    });
  }, [route, isPopState]);

  // 🔌 EFFECT 4: Scroll Management (Hash on new page)
  useEffect(() => {
    if (!window.location.hash) return;
    if (scrollToCurrentHash()) return;

    let frames = 0;
    const interval = setInterval(() => {
      frames++;
      if (scrollToCurrentHash() || frames > 20) {
        clearInterval(interval);
      }
    }, 50);

    return () => clearInterval(interval);
  }, [route]);

  // RSC Segmented Navigation Logic
  const cleanRoutePath = route.split("?")[0].split("#")[0];
  const searchPart = route.includes("?") ? "?" + route.split("?")[1].split("#")[0] : "";
  const layoutKey = useMemo(() => {
    if (
      typeof window !== "undefined" &&
      window.__DINOU_ACTIVE_LAYOUT__ &&
      route === getCurrentRoute()
    ) {
      return window.__DINOU_ACTIVE_LAYOUT__;
    }
    return getLayoutKey(cleanRoutePath);
  }, [cleanRoutePath, route, layoutVersion]);

  const pagePromise = useMemo(() => {
    if (initialPageErrorRef.current && route === getCurrentRoute()) {
      return initialPageErrorRef.current;
    }
    if (navError) return getErrorRSCPayload(route, navError);
    return getPagePayload(route, false, version);
  }, [route, version, navError]);

  useLayoutEffect(() => {
    pruneOrphanedSsrStreams();
    if (
      typeof document !== "undefined" &&
      document.body &&
      document.body.getAttribute("data-hydrated") !== "true"
    ) {
      document.body.setAttribute("data-hydrated", "true");
    }
  });

  const layoutPromise = useMemo(() => {
    return layoutKey !== null
      ? getLayoutPayload(layoutKey, searchPart, layoutVersion)
      : null;
  }, [layoutKey, searchPart, layoutVersion]);

  const contextValue = useMemo(
    () => ({
      url: route,
      navigate,
      back,
      forward,
      refresh,
      isPending,
    }),
    [route, isPending, refresh],
  );

  const slotContextValue = useMemo(
    () => ({
      pagePromise,
      resetKey: `${route}::${navCount}`,
    }),
    [pagePromise, route, navCount]
  );

  return (
    <RouterContext.Provider value={contextValue}>
      <ErrorBoundary
        resetKey={`${route}::${navCount}`}
        onError={isStaticExportMode() ? undefined : setNavError}
      >
        <DinouPageContext.Provider value={slotContextValue}>
          {navError
            ? use(pagePromise)
            : layoutPromise
              ? use(layoutPromise)
              : use(pagePromise)}
        </DinouPageContext.Provider>
      </ErrorBoundary>
    </RouterContext.Provider>
  );
}

const routerElement = createElement(Router);
const isDev = process.env.NODE_ENV !== "production";
const useStrictMode = isDev && (typeof window === "undefined" || window.__DINOU_STRICT_MODE__ !== false);

const app = useStrictMode
  ? createElement(StrictMode, null, routerElement)
  : routerElement;

const onRecoverableError = (error) => {
  if (isStaticExportUnloading()) {
    return;
  }
  if (isNavigationAbortError(error)) {
    return;
  }
  // 🛡️ Filter benign ViewTransition aborts when document is hidden (e.g. background tab or HMR while in IDE)
  if (
    error?.name === "InvalidStateError" &&
    (error?.message?.includes("Document hidden") || (typeof document !== "undefined" && document.hidden))
  ) {
    return;
  }
  if (error?.name === "AbortError" && error?.message?.includes("transition")) {
    return;
  }

  if (typeof reportError === "function") {
    reportError(error);
  } else {
    console.error(error);
  }
};

const onUncaughtError = (error) => {
  if (isStaticExportUnloading()) {
    return;
  }
  if (isNavigationAbortError(error)) {
    return;
  }
  if (typeof reportError === "function") {
    reportError(error);
  } else {
    console.error(error);
  }
};

const onCaughtError = (error) => {
  if (isStaticExportUnloading()) {
    return;
  }
  if (isNavigationAbortError(error)) {
    return;
  }
  console.error(error);
};

// If the server rendered a fatal layout error during SSR (meaning there is no layout DOM to hydrate),
// do NOT attempt to hydrate the application over it.
const hasInitialServerError =
  typeof window !== "undefined" && Boolean(window.__DINOU_ERROR_MESSAGE__);
const isLayoutError =
  hasInitialServerError && window.__DINOU_ERROR_SEGMENT__ !== "page";

if (isStaticExportUnloading()) {
  // Document is already redirecting / unloading (e.g. PPR hole or streaming SSR redirect);
  // skip hydration so no spurious /____rsc_page____ or /____rsc_layout____ fetches are started.
} else if (!isLayoutError) {
  hydrateRoot(document, app, {
    onRecoverableError,
    onUncaughtError,
    onCaughtError,
  });
} else {
  console.warn(
    "[Dinou] Initial layout server error detected:",
    window.__DINOU_ERROR_MESSAGE__,
    "- skipping client hydration to preserve the server-rendered error screen."
  );
  if (typeof document !== "undefined" && document.body) {
    document.body.setAttribute("data-hydrated", "true");
  }
}

if (import.meta.hot) {
  import.meta.hot.accept();
}
