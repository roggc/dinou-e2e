// dinou/core/generate-static-page.js
// Generates static HTML for a given path using the in-memory Dual-Bundle streaming engine.
// Completely eliminates child_process.fork() and render-app-to-html.js.

import path from "node:path";
import fs from "node:fs/promises";
import { existsSync, mkdirSync } from "node:fs";
import { pathToFileURL } from "node:url";

const OUT_DIR = path.resolve(".dinou/dist2");

async function generateStaticPage(reqPath) {
  const finalReqPath = reqPath.endsWith("/") ? reqPath : reqPath + "/";
  const htmlPath = path.join(OUT_DIR, finalReqPath, "index.html");
  const tempHtmlPath = path.join(OUT_DIR, finalReqPath, `index.html.${Date.now()}-${Math.random()}.tmp`);

  try {
    mkdirSync(path.dirname(htmlPath), { recursive: true });

    const rscEnginePath = path.resolve(process.cwd(), ".dinou/node/rsc-engine.mjs");
    const ssrEnginePath = path.resolve(process.cwd(), ".dinou/node/ssr-engine.mjs");

    let rscModule = null;
    let ssrModule = null;
    if (existsSync(rscEnginePath) && existsSync(ssrEnginePath)) {
      rscModule = await import(pathToFileURL(rscEnginePath).href);
      ssrModule = await import(pathToFileURL(ssrEnginePath).href);
    }

    if (rscModule && ssrModule) {
      const webReq = new Request(`http://localhost${finalReqPath}`);
      const res = await rscModule.handleRequest(webReq, {
        runtime: "node-bundle",
        renderHtmlStream: ssrModule.renderHtml,
        isSSG: true,
      });

      const text = await res.text();
      await fs.writeFile(tempHtmlPath, text, "utf8");

      const routeMeta = typeof rscModule.getStaticMetadata === "function" ? rscModule.getStaticMetadata(finalReqPath) : null;
      let isRoutePpr = Boolean(routeMeta?.ppr);
      if (!isRoutePpr) {
        try {
          const metaDisk = JSON.parse(await fs.readFile(path.join(OUT_DIR, finalReqPath, "metadata.json"), "utf8"));
          if (metaDisk?.ppr) isRoutePpr = true;
        } catch (e) {}
      }
      if (isRoutePpr) {
        const shellHtmlPath = path.join(OUT_DIR, finalReqPath, "shell.html");
        await fs.writeFile(shellHtmlPath, text, "utf8").catch(() => {});
        try {
          const pageReq = new Request(`http://localhost/____rsc_page____${finalReqPath}`);
          const pageRes = await rscModule.handleRequest(pageReq, { runtime: "node-bundle" });
          if (pageRes.status === 200) {
            const pageRscText = await pageRes.text();
            const shellRscPath = path.join(OUT_DIR, finalReqPath, "shell.rsc");
            await fs.writeFile(shellRscPath, pageRscText, "utf8").catch(() => {});
          }
        } catch (e) {}
      }

      return {
        success: res.status !== 500 && text.length > 0,
        type: "html",
        reqPath: finalReqPath,
        tempPath: tempHtmlPath,
        finalPath: htmlPath,
        status: res.status || 200,
        ppr: isRoutePpr,
      };
    }

    return { success: false, tempPath: tempHtmlPath };
  } catch (error) {
    await fs.unlink(tempHtmlPath).catch(() => {});
    return { success: false, tempPath: tempHtmlPath };
  }
}

export { generateStaticPage };
export default generateStaticPage;
