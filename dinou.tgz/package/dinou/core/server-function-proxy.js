import { createFromFetch } from "@roggc/react-server-dom-esm/client";

function isSafeRedirect(url) {
  return typeof url === "string" && url.startsWith("/") && !url.startsWith("//");
}

function executeRedirect(url) {
  const safeUrl = isSafeRedirect(url) ? url : "/";
  const isInternal = safeUrl.startsWith("/") && !safeUrl.startsWith("//");
  if (isInternal && typeof window !== "undefined" && window.__DINOU_ROUTER_NAVIGATE__) {
    window.__DINOU_ROUTER_NAVIGATE__(safeUrl);
  } else if (typeof window !== "undefined") {
    window.location.href = safeUrl;
  }
}

export function createServerFunctionProxy(id) {
  return new Proxy(() => { }, {
    apply: async (_target, _thisArg, args) => {
      let customHeaders = {};
      if (typeof window !== "undefined") {
        if (typeof window.__DINOU_SERVER_FUNCTION_HEADERS__ === "function") {
          try {
            customHeaders = window.__DINOU_SERVER_FUNCTION_HEADERS__() || {};
          } catch (e) {
            console.error("[Dinou] Error getting custom headers for server function:", e);
          }
        } else if (typeof window.__DINOU_GET_AUTH_TOKEN__ === "function") {
          try {
            const token = window.__DINOU_GET_AUTH_TOKEN__();
            if (token) customHeaders = { Authorization: `Bearer ${token}` };
          } catch (e) {
            console.error("[Dinou] Error getting auth token for server function:", e);
          }
        }
      }

      const headers = {
        "x-server-function-call": "1",
        ...customHeaders,
      };
      if (typeof window !== "undefined" && window.location) {
        headers["x-dinou-current-path"] = window.location.pathname;
      }

      let body;
      const formDataIndex = args.findIndex((arg) => arg instanceof FormData);

      if (formDataIndex !== -1) {
        const formData = args[formDataIndex];

        formData.append("__dinou_func_id", id);
        formData.append("__dinou_formData_index", String(formDataIndex));

        if (args.length > 1) {
          const serializedArgs = args.map((arg, i) => (i === formDataIndex ? null : arg));
          formData.append("__dinou_args", JSON.stringify(serializedArgs));
        }

        body = formData;
      } else {
        headers["Content-Type"] = "application/json";
        body = JSON.stringify({ id, args });
      }
      const res = await fetch("/____server_function____", {
        method: "POST",
        headers,
        body,
      });

      if (!res.ok) throw new Error("Server function failed");

      // Check header first
      const redirectUrl = res.headers.get("X-Dinou-Redirect");
      if (redirectUrl) {
        executeRedirect(redirectUrl);
        return Promise.resolve();
      }

      const contentType = res.headers.get("content-type") || "";

      // Reject unexpected HTML responses entirely to prevent security bugs
      if (contentType.includes("text/html")) {
        const html = await res.text();
        console.warn("[Dinou] Received unexpected HTML response from server function:", html);
        throw new Error("Unexpected HTML response from server function");
      }

      // Check if it's application/json (Scenario A clean redirect or json response)
      if (contentType.includes("application/json")) {
        const data = await res.json();
        if (data && data.redirect) {
          executeRedirect(data.redirect);
          return Promise.resolve();
        }
        return data;
      }

      // Case 2: RSC or Hybrid Stream (Buffered)
      if (contentType.includes("text/x-component")) {
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        const encoder = new TextEncoder();

        const readableStream = new ReadableStream({
          async start(controller) {
            let buffer = ""; // 📦 PERSISTENT STATE
            let isRedirecting = false;

            try {
              while (true) {
                const { done, value } = await reader.read();

                if (done) {
                  if (buffer.length > 0) {
                    if (buffer.startsWith("D:")) {
                      try {
                        const payload = JSON.parse(buffer.slice(2));
                        if (payload.type === "redirect") {
                          isRedirecting = true;
                          executeRedirect(payload.url);
                        } else if (payload.type === "cookie") {
                          document.cookie = payload.cookie;
                        }
                      } catch (e) {
                        console.error("[Dinou] Failed to parse stream command line at end:", e);
                      }
                    } else {
                      controller.enqueue(encoder.encode(buffer));
                    }
                  }
                  break;
                }

                // 1. ACCUMULATE
                buffer += decoder.decode(value, { stream: true });

                // 2. PROCESS COMPLETE LINES
                const lastNewlineIndex = buffer.lastIndexOf("\n");
                if (lastNewlineIndex !== -1) {
                  const completeChunk = buffer.slice(0, lastNewlineIndex + 1);
                  buffer = buffer.slice(lastNewlineIndex + 1);

                  const lines = completeChunk.split("\n");
                  let cleanChunk = "";

                  for (let i = 0; i < lines.length; i++) {
                    const line = lines[i];
                    if (!line && i === lines.length - 1) {
                      continue;
                    }

                    if (line.startsWith("D:")) {
                      try {
                        const payload = JSON.parse(line.slice(2));
                        if (payload.type === "redirect") {
                          isRedirecting = true;
                          executeRedirect(payload.url);
                        } else if (payload.type === "cookie") {
                          document.cookie = payload.cookie;
                        }
                      } catch (e) {
                        console.error("[Dinou] Failed to parse stream command line:", e);
                      }
                    } else {
                      cleanChunk += line + "\n";
                    }
                  }

                  if (cleanChunk) {
                    controller.enqueue(encoder.encode(cleanChunk));
                  }
                }
              }
              controller.close();
            } catch (err) {
              controller.error(err);
            }
          },
        });

        return createFromFetch(Promise.resolve(new Response(readableStream)), {
          callServer: async (nextId, nextArgs) => {
            const proxy = createServerFunctionProxy(nextId);
            return proxy(...nextArgs);
          },
        });
      }
      return res.json();
    },
  });
}
