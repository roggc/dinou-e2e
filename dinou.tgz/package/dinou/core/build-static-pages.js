import path from "node:path";
import { existsSync, readdirSync } from "node:fs";
import React from "react";
import { asyncRenderJSXToClientJSX } from "./render-jsx-to-client-jsx.js";
import { getFilePathAndDynamicParams } from "./get-file-path-and-dynamic-params.js";
import importModule from "./import-module.js";
import { requestStorage } from "./request-context.js";
import { createUnifiedEnv } from "./runtime-env.js";
import {
  getLayoutProps,
  resolveLayoutFunctionsConfig,
  getLayoutFunctionsPath,
  resolveLayoutChainPpr,
  computeLayoutKeyFromFolder,
  getActiveLayoutChain,
} from "./layout-functions.js";
import {
  runWithPprContext,
  getRegisteredHoles,
  getPprHoleCounter,
  resetPprHoles,
  markPageRootElement,
  markLayoutRootElement,
  createLayoutChildrenPlaceholder,
} from "./ppr-context.js";
import { resolveModulePpr } from "./resolve-module-ppr.js";
import { createBailoutProxy } from "./bailout-proxy.js";
import { sortEntriesByName } from "./discover-layouts.js";

async function resolveBuildPprForRoute(segments, pagePath, pageFunctionsPath, srcFolder) {
  const { layoutPprMap, defaultPpr, anyLayoutPpr } = await resolveLayoutChainPpr(
    segments || [],
    {},
    srcFolder,
  );

  let explicitPagePpr = null;
  if (pageFunctionsPath) {
    try {
      const module = await importModule(pageFunctionsPath);
      explicitPagePpr = await resolveModulePpr(module);
    } catch (e) { }
  }
  if (explicitPagePpr === null && typeof globalThis !== "undefined" && globalThis.__DINOU_ROUTE_METADATA__) {
    const normKey = pageFunctionsPath ? pageFunctionsPath.replace(/\\/g, "/") : "";
    for (const [k, meta] of Object.entries(globalThis.__DINOU_ROUTE_METADATA__)) {
      if (meta.ppr !== undefined && (normKey === k || normKey.endsWith("/" + k) || normKey.endsWith(k))) {
        explicitPagePpr = Boolean(meta.ppr);
        break;
      }
    }
  }

  const pageEffectivePpr =
    explicitPagePpr !== null ? explicitPagePpr : Boolean(defaultPpr);
  const isRoutePpr = Boolean(pageEffectivePpr || anyLayoutPpr);

  return { isRoutePpr, pageEffectivePpr, layoutPprMap };
}

const staticRoutes = new Set();
const staticMetadata = new Map();
const staticLayouts = new Map();

function safeDecode(val) {
  try {
    return !!val ? decodeURIComponent(val) : val;
  } catch (e) {
    return val; // If decoding fails, return the original
  }
}

function hasZeroParameters(fn) {
  if (typeof fn !== "function") return false;
  if (fn.length > 0) return false;
  try {
    const src = Function.prototype.toString.call(fn).trim();
    return /^(?:async\s+)?(?:function(?:\s+[\w$]+)?\s*)?\(\s*\)/.test(src);
  } catch (e) {
    return fn.length === 0;
  }
}

async function isDynamicRoute(revalidate, params) {
  if (revalidate === undefined || revalidate === false) return false;
  if (typeof revalidate === "function") {
    // When called without concrete params before getStaticPaths expansion,
    // defer parameterized revalidate(params) functions until concrete pathItems are expanded,
    // while still evaluating 0-arg functions (e.g. `() => 0`, `async () => 0`) immediately.
    if (params === undefined && !hasZeroParameters(revalidate)) return false;
    const val = await revalidate(params || {});
    return typeof val === "number" && val < 1;
  }
  return typeof revalidate === "number" && revalidate < 1;
}


/**
 * Compiles all static pages in the application.
 * Crawls the "src/" folder to collect all routes, resolves dynamic path segments,
 * mock-renders them inside a server context, and serializes successful static renders
 * into RSC JSON payloads.
 */
async function buildStaticPages(onProgress = null) {
  const srcFolder = path.resolve(process.cwd(), "src");

  /**
   * Recursively traverses the page directory tree to collect all eligible static routes.
   * Handles static folder names, route groups (e.g. "(group)"), and dynamic parameters
   * like catch-all segments or optional segments by resolving their static paths.
   */
  async function collectPages(
    currentPath,
    segments = [],
    params = {},
    dynamicStructure = [],
    doNotPushAtEnd = false,
  ) {
    const entries = sortEntriesByName(readdirSync(currentPath, { withFileTypes: true }));
    const pages = [];

    // 🛡️ Descubrir layout en esta carpeta si existe
    if (dynamicStructure.length === 0) {
      const layoutExtensions = [".tsx", ".jsx", ".ts", ".js"];
      for (const ext of layoutExtensions) {
        const candidateLayout = path.join(currentPath, `layout${ext}`);
        if (existsSync(candidateLayout)) {
          const relFromSrc = path.relative(srcFolder, currentPath).replace(/\\/g, "/");
          const rawFolderSegs = relFromSrc ? relFromSrc.split("/").filter(Boolean) : [];
          const { layoutRoutePath: routePath } = computeLayoutKeyFromFolder(
            rawFolderSegs,
            segments,
            params,
          );
          const layoutConfig = await resolveLayoutFunctionsConfig(candidateLayout, params);
          if (!layoutConfig.isDynamic) {
            staticLayouts.set(routePath, {
              folderPath: currentPath,
              layoutPath: candidateLayout,
              routePath,
              segments,
              params,
            });
          }
          break;
        }
      }
    }

    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (entry.name.startsWith("_")) {
          continue;
        }
        if (entry.name.startsWith("(") && entry.name.endsWith(")")) {
          pages.push(
            ...(await collectPages(
              path.join(currentPath, entry.name),
              segments,
              params,
              dynamicStructure,
              doNotPushAtEnd,
            )),
          );
        } else if (
          entry.name.startsWith("[[...") &&
          entry.name.endsWith("]]")
        ) {
          const paramName = entry.name.slice(5, -2);
          const dynamicPath = path.join(currentPath, entry.name);
          const [pagePath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page",
            true,
            true,
            undefined,
            segments.length,
          );
          const [pageFunctionsPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page_functions",
            true,
            true,
            undefined,
            segments.length,
          );

          let revalidate, getStaticPaths;
          if (pageFunctionsPath) {
            const module = await importModule(pageFunctionsPath);
            const defMod = module.default?.default ? module.default.default : module.default;
            getStaticPaths = module.getStaticPaths || defMod?.getStaticPaths;
            revalidate = module.revalidate ?? defMod?.revalidate;
          }
          const lfPath = getLayoutFunctionsPath(dynamicPath);
          if (lfPath) {
            const lmod = await importModule(lfPath);
            const ldefMod = lmod.default?.default ? lmod.default.default : lmod.default;
            const lmodGetStaticPaths = lmod.getStaticPaths || ldefMod?.getStaticPaths;
            const lmodRevalidate = lmod.revalidate ?? ldefMod?.revalidate;
            if (!getStaticPaths && lmodGetStaticPaths) {
              getStaticPaths = lmodGetStaticPaths;
            }
            if (revalidate === undefined && lmodRevalidate !== undefined) {
              revalidate = lmodRevalidate;
            }
          }
          const isLocalPage =
            pagePath && path.dirname(pagePath) === dynamicPath;
          const [layoutPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "layout",
            true,
            true,
            undefined,
            segments.length,
          );
          const hasLocalLayout =
            layoutPath && path.dirname(layoutPath) === dynamicPath;
          if ((isLocalPage || hasLocalLayout) && !(await isDynamicRoute(revalidate))) {
            if (process.env.DINOU_DEBUG) {
              console.log(
                `Found optional catch-all route: ${segments.join("/") ?? ""
                }/[[...${paramName}]]`,
              );
            }
            try {
              if (getStaticPaths) {
                const paths = await (typeof getStaticPaths === "function"
                  ? getStaticPaths()
                  : getStaticPaths);
                for (const pathItem of paths) {
                  // 1. Preparation of Structure and Extraction
                  const currentStructure = [...dynamicStructure, paramName];
                  const isObject =
                    typeof pathItem === "object" &&
                    pathItem !== null &&
                    !Array.isArray(pathItem);

                  let rawSegments;

                  if (isObject) {
                    rawSegments = currentStructure.map((key) => {
                      // A. Handling of Static Bridges
                      const isKeyObject =
                        typeof key === "object" && key !== null;
                      if (isKeyObject) {
                        return key.STATIC_PARAM_NAME;
                      }

                      // B. Value Extraction
                      const val = pathItem[key];

                      // IMPORTANT: For the Gap Check we need to keep 'undefined' or 'null'
                      // explicitly in the array, do not convert it to [] yet.
                      // If it is [] empty, we leave it as is so that .flat() removes it (does not count as gap).
                      return val;
                    });
                  } else {
                    // If not object, it is the direct value of the current parameter
                    rawSegments = [pathItem];
                  }

                  // Flatten. Note: undefined is kept in the array. [] disappears.
                  const flatSegments = rawSegments.flat();

                  // 🛡️ 2. GAP CHECK (Detection of prohibited gaps)
                  // Prohibited: [undefined, "something"]
                  // Permitted: ["something", undefined] or [undefined, undefined]
                  const hasGap = flatSegments.some((seg, index) => {
                    const isUndefined =
                      seg === undefined || seg === null || seg === "";
                    if (!isUndefined) return false;

                    // If this is undefined, we check if there is something defined to the right
                    const remaining = flatSegments.slice(index + 1);
                    return remaining.some(
                      (s) => s !== undefined && s !== null && s !== "",
                    );
                  });

                  if (hasGap) {
                    continue; // Invalid route (intermediate gap)
                  }

                  // 🛡️ 3. URL CLEANING
                  // Remove undefineds for the physical URL and coerce numeric segments to strings
                  const validSegmentsToAdd = flatSegments
                    .filter((s) => s !== undefined && s !== null && s !== "")
                    .map((s) => String(s));

                  // 🛡️ 4. PARAMS PREPARATION & NORMALIZATION
                  const paramsToAdd = isObject
                    ? { ...pathItem } // Clone to avoid mutation
                    : { [paramName]: pathItem };

                  // Specific normalization for Catch-all: undefined -> []
                  const currentVal = paramsToAdd[paramName];
                  if (
                    currentVal === undefined ||
                    currentVal === null ||
                    currentVal === ""
                  ) {
                    paramsToAdd[paramName] = [];
                  } else if (!Array.isArray(currentVal)) {
                    paramsToAdd[paramName] = [currentVal];
                  }

                  pages.push(
                    ...(await collectPages(
                      dynamicPath,
                      [...segments, ...validSegmentsToAdd],
                      { ...params, ...paramsToAdd },
                    )),
                  );
                }
              }
            } catch (err) {
              console.error(`Error loading ${pagePath}:`, err);
            }
          } else {
            // ⚠️ IMPORTANT: Update the history in the recursion
            pages.push(
              ...(await collectPages(
                dynamicPath,
                segments,
                params,
                [...dynamicStructure, paramName],
                true,
              )),
            );
          }
        } else if (entry.name.startsWith("[...") && entry.name.endsWith("]")) {
          const paramName = entry.name.slice(4, -1);
          const dynamicPath = path.join(currentPath, entry.name);
          const [pagePath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page",
            true,
            true,
            undefined,
            segments.length,
          );
          const [pageFunctionsPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page_functions",
            true,
            true,
            undefined,
            segments.length,
          );

          let revalidate, getStaticPaths;
          if (pageFunctionsPath) {
            const module = await importModule(pageFunctionsPath);
            const defMod = module.default?.default ? module.default.default : module.default;
            getStaticPaths = module.getStaticPaths || defMod?.getStaticPaths;
            revalidate = module.revalidate ?? defMod?.revalidate;
          }
          const lfPath = getLayoutFunctionsPath(dynamicPath);
          if (lfPath) {
            const lmod = await importModule(lfPath);
            const ldefMod = lmod.default?.default ? lmod.default.default : lmod.default;
            const lmodGetStaticPaths = lmod.getStaticPaths || ldefMod?.getStaticPaths;
            const lmodRevalidate = lmod.revalidate ?? ldefMod?.revalidate;
            if (!getStaticPaths && lmodGetStaticPaths) {
              getStaticPaths = lmodGetStaticPaths;
            }
            if (revalidate === undefined && lmodRevalidate !== undefined) {
              revalidate = lmodRevalidate;
            }
          }
          const isLocalPage =
            pagePath && path.dirname(pagePath) === dynamicPath;
          const [layoutPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "layout",
            true,
            true,
            undefined,
            segments.length,
          );
          const hasLocalLayout =
            layoutPath && path.dirname(layoutPath) === dynamicPath;
          if ((isLocalPage || hasLocalLayout) && !(await isDynamicRoute(revalidate))) {
            if (process.env.DINOU_DEBUG) {
              console.log(
                `Found catch-all route: ${segments.join("/") ?? ""
                }/[...${paramName}]`,
              );
            }
            try {
              if (getStaticPaths) {
                const paths = await (typeof getStaticPaths === "function"
                  ? getStaticPaths()
                  : getStaticPaths);
                for (const pathItem of paths) {
                  const currentStructure = [...dynamicStructure, paramName];
                  const isObject =
                    typeof pathItem === "object" &&
                    pathItem !== null &&
                    !Array.isArray(pathItem);

                  let segmentsToAdd;
                  if (isObject) {
                    let notValidRoute = false;
                    segmentsToAdd = currentStructure.map((key, i, arr) => {
                      const isObject = typeof key === "object" && key !== null;
                      if (isObject) {
                        return key.STATIC_PARAM_NAME;
                      }
                      const val = pathItem[key];

                      // 🛡️ FIX 1: Relaxed validation.
                      // Mark the route as invalid (skipping its generation) if any parent parameter segment is missing.
                      if (
                        (val === undefined || val === null || val === "") &&
                        i < arr.length - 1
                      ) {
                        notValidRoute = true;
                      }
                      return val;
                    });
                    if (notValidRoute) continue;
                  } else {
                    segmentsToAdd = [pathItem];
                  }

                  // 🛡️ FIX 2: Segment filtering.
                  // Flatten (.flat) to handle the catch-all array, filter empties, and coerce numbers to strings.
                  const validSegmentsToAdd = segmentsToAdd
                    .flat()
                    .filter((s) => s !== undefined && s !== null && s !== "")
                    .map((s) => String(s));

                  const paramsToAdd = isObject
                    ? pathItem
                    : { [paramName]: pathItem };

                  pages.push(
                    ...(await collectPages(
                      dynamicPath,
                      [...segments, ...validSegmentsToAdd], // Use the filtered version
                      { ...params, ...paramsToAdd },
                    )),
                  );
                }
              }
            } catch (err) {
              console.error(`Error loading ${pagePath}:`, err);
            }
          } else {
            // ⚠️ IMPORTANT: Update the history
            pages.push(
              ...(await collectPages(
                dynamicPath,
                segments,
                params,
                [...dynamicStructure, paramName],
                true,
              )),
            );
          }
        } else if (entry.name.startsWith("[[") && entry.name.endsWith("]]")) {
          const paramName = entry.name.slice(2, -2);
          const dynamicPath = path.join(currentPath, entry.name);
          const [pagePath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page",
            true,
            true,
            undefined,
            segments.length,
          );
          const [pageFunctionsPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page_functions",
            true,
            true,
            undefined,
            segments.length,
          );

          let revalidate, getStaticPaths;
          if (pageFunctionsPath) {
            const module = await importModule(pageFunctionsPath);
            const defMod = module.default?.default ? module.default.default : module.default;
            getStaticPaths = module.getStaticPaths || defMod?.getStaticPaths;
            revalidate = module.revalidate ?? defMod?.revalidate;
          }
          const lfPath = getLayoutFunctionsPath(dynamicPath);
          if (lfPath) {
            const lmod = await importModule(lfPath);
            const ldefMod = lmod.default?.default ? lmod.default.default : lmod.default;
            const lmodGetStaticPaths = lmod.getStaticPaths || ldefMod?.getStaticPaths;
            const lmodRevalidate = lmod.revalidate ?? ldefMod?.revalidate;
            if (!getStaticPaths && lmodGetStaticPaths) {
              getStaticPaths = lmodGetStaticPaths;
            }
            if (revalidate === undefined && lmodRevalidate !== undefined) {
              revalidate = lmodRevalidate;
            }
          }
          const isLocalPage =
            pagePath && path.dirname(pagePath) === dynamicPath;
          const [layoutPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "layout",
            true,
            true,
            undefined,
            segments.length,
          );
          const hasLocalLayout =
            layoutPath && path.dirname(layoutPath) === dynamicPath;
          if ((isLocalPage || hasLocalLayout) && !(await isDynamicRoute(revalidate))) {
            if (process.env.DINOU_DEBUG) {
              console.log(
                `Found optional dynamic route: ${segments.join("/") ?? ""
                }/[[${paramName}]]`,
              );
            }
            try {
              if (getStaticPaths) {
                const paths = await (typeof getStaticPaths === "function"
                  ? getStaticPaths()
                  : getStaticPaths);
                for (const pathItem of paths) {
                  // 1. Preparation of Structure and Extraction
                  const currentStructure = [...dynamicStructure, paramName];
                  const isObject =
                    typeof pathItem === "object" && pathItem !== null; // Single param should not be array, but for safety.

                  let rawSegments;

                  if (isObject) {
                    rawSegments = currentStructure.map((key) => {
                      // A. Handling of Static Bridges
                      const isKeyObject =
                        typeof key === "object" && key !== null;
                      if (isKeyObject) {
                        return key.STATIC_PARAM_NAME;
                      }

                      // B. Value Extraction
                      // Return the value as is (undefined stays as undefined for the check)
                      return pathItem[key];
                    });
                  } else {
                    rawSegments = [pathItem];
                  }

                  // Flatten (in case there is some weird nested array, although in single it shouldn't)
                  const flatSegments = rawSegments.flat();

                  // 🛡️ 2. GAP CHECK (Detection of prohibited gaps)
                  // Allows /inventory/[[a]]/[[b]] to generate /inventory if a and b are undefined
                  const hasGap = flatSegments.some((seg, index) => {
                    const isUndefined =
                      seg === undefined || seg === null || seg === "";
                    if (!isUndefined) return false;

                    // Check to the right
                    const remaining = flatSegments.slice(index + 1);
                    return remaining.some(
                      (s) => s !== undefined && s !== null && s !== "",
                    );
                  });

                  if (hasGap) {
                    continue; // Invalid route
                  }

                  // 🛡️ 3. URL CLEANING
                  const validSegmentsToAdd = flatSegments
                    .filter((s) => s !== undefined && s !== null && s !== "")
                    .map((s) => String(s));

                  // 🛡️ 4. PARAMS PREPARATION
                  // Here we DO NOT normalize to [], because it is a single parameter.
                  // undefined stays as undefined.
                  const paramsToAdd = isObject
                    ? pathItem
                    : { [paramName]: pathItem };

                  pages.push(
                    ...(await collectPages(
                      dynamicPath,
                      [...segments, ...validSegmentsToAdd],
                      { ...params, ...paramsToAdd },
                    )),
                  );
                }
              }
            } catch (err) {
              console.error(`Error loading ${pagePath}:`, err);
            }
          } else {
            // ⚠️ IMPORTANT: Update the history
            pages.push(
              ...(await collectPages(
                dynamicPath,
                segments,
                params,
                [...dynamicStructure, paramName],
                true,
              )),
            );
          }
        } else if (entry.name.startsWith("[") && entry.name.endsWith("]")) {
          const paramName = entry.name.slice(1, -1);
          const dynamicPath = path.join(currentPath, entry.name);
          const [pagePath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page",
            true,
            true,
            undefined,
            segments.length,
          );
          const [pageFunctionsPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "page_functions",
            true,
            true,
            undefined,
            segments.length,
          );
          let dynamic;
          let getStaticPaths;
          let revalidate;
          if (pageFunctionsPath) {
            const module = await importModule(pageFunctionsPath);
            const defMod = module.default?.default ? module.default.default : module.default;
            getStaticPaths = module.getStaticPaths || defMod?.getStaticPaths;
            revalidate = module.revalidate ?? defMod?.revalidate;
          }
          const lfPath = getLayoutFunctionsPath(dynamicPath);
          if (lfPath) {
            const lmod = await importModule(lfPath);
            const ldefMod = lmod.default?.default ? lmod.default.default : lmod.default;
            const lmodGetStaticPaths = lmod.getStaticPaths || ldefMod?.getStaticPaths;
            const lmodRevalidate = lmod.revalidate ?? ldefMod?.revalidate;
            if (!getStaticPaths && lmodGetStaticPaths) {
              getStaticPaths = lmodGetStaticPaths;
            }
            if (revalidate === undefined && lmodRevalidate !== undefined) {
              revalidate = lmodRevalidate;
            }
          }
          const isLocalPage =
            pagePath && path.dirname(pagePath) === dynamicPath;
          const [layoutPath] = getFilePathAndDynamicParams(
            segments,
            {},
            dynamicPath,
            "layout",
            true,
            true,
            undefined,
            segments.length,
          );
          const hasLocalLayout =
            layoutPath && path.dirname(layoutPath) === dynamicPath;
          if ((isLocalPage || hasLocalLayout) && !(await isDynamicRoute(revalidate))) {
            if (process.env.DINOU_DEBUG) {
              console.log(
                `Found dynamic route: ${segments.join("/") ?? ""}/[${paramName}]`,
              );
            }
            try {
              if (getStaticPaths) {
                const paths = await (typeof getStaticPaths === "function"
                  ? getStaticPaths()
                  : getStaticPaths);
                for (const pathItem of paths) {
                  const currentStructure = [...dynamicStructure, paramName];
                  const isObject =
                    typeof pathItem === "object" && pathItem !== null;

                  let segmentsToAdd;

                  if (isObject) {
                    let parentParamMismatch = false;
                    for (const [boundKey, boundVal] of Object.entries(params)) {
                      if (
                        Object.prototype.hasOwnProperty.call(pathItem, boundKey) &&
                        !currentStructure.includes(boundKey)
                      ) {
                        const normItem = Array.isArray(pathItem[boundKey])
                          ? pathItem[boundKey].join(",")
                          : String(pathItem[boundKey] ?? "");
                        const normBound = Array.isArray(boundVal)
                          ? boundVal.join(",")
                          : String(boundVal ?? "");
                        if (normItem !== normBound) {
                          parentParamMismatch = true;
                          break;
                        }
                      }
                    }
                    if (parentParamMismatch) continue;

                    let notValidRoute = false;
                    segmentsToAdd = currentStructure.map((key, i, arr) => {
                      const isObject = typeof key === "object" && key !== null;
                      if (isObject) {
                        return key.STATIC_PARAM_NAME;
                      }
                      const val = pathItem[key];

                      // 🛡️ CHANGE: If a parent parameter is missing, we mark the route as invalid to skip it.
                      if (
                        (val === undefined || val === null || val === "") &&
                        i < arr.length - 1
                      ) {
                        notValidRoute = true;
                      }
                      return val;
                    });
                    if (notValidRoute) continue;
                  } else {
                    segmentsToAdd = [pathItem];
                  }

                  const validSegmentsToAdd = segmentsToAdd
                    .flat()
                    .filter((s) => s !== undefined && s !== null && s !== "")
                    .map((s) => String(s));

                  const paramsToAdd = isObject
                    ? pathItem
                    : { [paramName]: pathItem };

                  pages.push(
                    ...(await collectPages(
                      dynamicPath,
                      [...segments, ...validSegmentsToAdd],
                      { ...params, ...paramsToAdd },
                    )),
                  );
                }
              }
            } catch (err) {
              console.error(`Error loading ${pagePath}:`, err);
            }
          } else {
            pages.push(
              ...(await collectPages(
                dynamicPath,
                segments,
                params,
                [...dynamicStructure, paramName],
                true,
              )),
            );
          }
        } else if (!entry.name.startsWith("@")) {
          if (dynamicStructure.length > 0) {
            const dynamicPath = path.join(currentPath, entry.name);
            const [pagePath] = getFilePathAndDynamicParams(
              segments,
              {},
              dynamicPath,
              "page",
              true,
              true,
              undefined,
              segments.length,
            );
            const [pageFunctionsPath] = getFilePathAndDynamicParams(
              segments,
              {},
              dynamicPath,
              "page_functions",
              true,
              true,
              undefined,
              segments.length,
            );
            let revalidate;
            let getStaticPaths;
            if (pageFunctionsPath) {
              const module = await importModule(pageFunctionsPath);
              const defMod = module.default?.default ? module.default.default : module.default;
              getStaticPaths = module.getStaticPaths || defMod?.getStaticPaths;
              revalidate = module.revalidate ?? defMod?.revalidate;
            }
            const isLocalPage =
              pagePath && path.dirname(pagePath) === dynamicPath;
            if (isLocalPage && !(await isDynamicRoute(revalidate, getStaticPaths ? undefined : params))) {
              try {
                if (getStaticPaths) {
                  const paths = await (typeof getStaticPaths === "function"
                    ? getStaticPaths()
                    : getStaticPaths);
                  for (const pathItem of paths) {
                    const currentStructure = dynamicStructure;
                    const dynamicKeys = currentStructure.filter((k) => typeof k === "string");
                    const targetParamName = dynamicKeys[dynamicKeys.length - 1];
                    const isObject =
                      typeof pathItem === "object" &&
                      pathItem !== null &&
                      !Array.isArray(pathItem);

                    let segmentsToAdd;

                    if (isObject) {
                      let notValidRoute = false;
                      segmentsToAdd = currentStructure.map((key, i, arr) => {
                        const isObject =
                          typeof key === "object" && key !== null;
                        if (isObject) {
                          return key.STATIC_PARAM_NAME;
                        }
                        const val = pathItem[key];

                        // 🛡️ CHANGE: If a parent parameter is missing, we mark the route as invalid to skip it.
                        if (
                          (val === undefined || val === null || val === "") &&
                          i < arr.length - 1
                        ) {
                          notValidRoute = true;
                        }
                        return val;
                      });
                      if (notValidRoute) continue;
                    } else {
                      segmentsToAdd = currentStructure.map((key) =>
                        typeof key === "object" && key !== null
                          ? key.STATIC_PARAM_NAME
                          : pathItem,
                      );
                    }

                    const validSegmentsToAdd = segmentsToAdd
                      .flat()
                      .filter((s) => s !== undefined && s !== null && s !== "")
                      .map((s) => String(s));

                    const paramsToAdd = isObject
                      ? pathItem
                      : targetParamName
                        ? { [targetParamName]: pathItem }
                        : {};

                    pages.push(
                      ...(await collectPages(
                        dynamicPath,
                        [...segments, ...validSegmentsToAdd, entry.name],
                        { ...params, ...paramsToAdd },
                      )),
                    );
                  }
                }
              } catch (err) {
                console.error(`Error loading ${pagePath}:`, err);
              }
            } else {
              pages.push(
                ...(await collectPages(
                  path.join(currentPath, entry.name),
                  segments,
                  params,
                  [...dynamicStructure, { STATIC_PARAM_NAME: entry.name }],
                  true,
                )),
              );
            }
          } else {
            pages.push(
              ...(await collectPages(
                path.join(currentPath, entry.name),
                [...segments, entry.name],
                params,
                dynamicStructure,
                false,
              )),
            );
          }
        }
      }
    }

    const [pagePath, dParams] = getFilePathAndDynamicParams(
      segments,
      {},
      currentPath,
      "page",
      true,
      true,
      undefined,
      segments.length,
      params,
    );
    const [pageFunctionsPath] = getFilePathAndDynamicParams(
      segments,
      {},
      currentPath,
      "page_functions",
      true,
      true,
      undefined,
      segments.length,
    );
    let revalidate;
    if (pageFunctionsPath) {
      try {
        const module = await importModule(pageFunctionsPath);
        const defMod = module.default?.default ? module.default.default : module.default;
        revalidate = module.revalidate ?? defMod?.revalidate;
      } catch (e) { }
    }

    const { isRoutePpr: isPpr, pageEffectivePpr, layoutPprMap } =
      await resolveBuildPprForRoute(segments, pagePath, pageFunctionsPath, srcFolder);

    const isPageDynamicForParams = pagePath ? await isDynamicRoute(revalidate, dParams) : false;
    if (pagePath && !doNotPushAtEnd) {
      try {
        const activeLayoutsForPage = getActiveLayoutChain(segments, {}, srcFolder);
        for (const entry of activeLayoutsForPage) {
          if (!staticLayouts.has(entry.layoutRoutePath)) {
            const layoutConfig = await resolveLayoutFunctionsConfig(
              entry.layoutPath,
              entry.dParams || {},
            );
            if (!layoutConfig.isDynamic) {
              staticLayouts.set(entry.layoutRoutePath, {
                folderPath: path.dirname(entry.layoutPath),
                layoutPath: entry.layoutPath,
                routePath: entry.layoutRoutePath,
                segments,
                params: entry.dParams || {},
              });
            }
          }
        }
      } catch (e) {}
    }

    if (pagePath && !isPageDynamicForParams && !doNotPushAtEnd) {
      pages.push({
        path: currentPath,
        segments,
        params: dParams,
        ppr: isPpr,
        pagePpr: pageEffectivePpr,
        layoutPprMap,
      });
      const routeName = segments.join("/") ? "/" + segments.join("/") : "/";
      if (typeof onProgress === "function") {
        onProgress({ phase: "crawling", route: routeName, count: pages.length });
      }
      if (process.env.DINOU_DEBUG) {
        console.log(`Found static route: ${routeName}${isPpr ? " (PPR)" : ""}`);
      }
    }

    return pages;
  }

  // Crawl complete, start rendering and serialization loop for all discovered static pages
  const pages = await collectPages(srcFolder);

  let pageIdx = 0;
  for (const {
    path: folderPath,
    segments,
    params,
    ppr: pageIsPpr,
    pagePpr: pageEffectivePpr,
    layoutPprMap,
  } of pages) {
    pageIdx++;
    try {
      const reqPath = segments.length ? "/" + segments.join("/") + "/" : "/";
      if (typeof onProgress === "function") {
        onProgress({ phase: "discovering", route: reqPath, current: pageIdx, total: pages.length });
      }
      // ====================================================================
      // 1. MOCK RES: Fulfilling ResponseProxy interface
      // ====================================================================
      // Although contract says it returns void, internally we save
      // the state in case you want to log errors (ex: a redirect in build time).
      let mockContext;
      const mockRes = {
        _statusCode: 200,
        _headers: {},
        _redirectUrl: null,
        _cookies: [], // Optional: for debug

        // 👇 ADD THIS METHOD
        cookie(name, value, options) {
          // In SSG we do nothing real, but keep a record if you want to debug
          // console.log(`[SSG] Cookie set ignored: ${name}=${value}`);
          this._cookies.push({ name, value, options, isClear: false });
        },

        clearCookie(name, options) {
          this._cookies.push({ name, value: "", options, isClear: true });
        },

        // setHeader(name: string, value: string | ReadonlyArray<string>): void;
        setHeader(name, value) {
          this._headers[name.toLowerCase()] = value;
        },

        // status(code: number): void;
        status(code) {
          this._statusCode = code;
        },

        // redirect(status: number, url: string): void;
        // redirect(url: string): void;
        redirect(arg1, arg2) {
          let status = 302;
          let url = "";

          if (typeof arg1 === "number") {
            status = arg1;
            url = arg2;
          } else {
            url = arg1;
          }

          this._statusCode = status;
          this._redirectUrl = url;
          if (mockContext) mockContext._hasRedirected = true;

          // Log warning because a redirect in SSG is usually problematic
          if (process.env.DINOU_DEBUG) {
            console.warn(
              `⚠️ [SSG] Redirect detected in ${reqPath} -> ${url} (${status})`,
            );
          }
        },
      };

      let isStatic = true;
      const markAsDynamic = () => {
        isStatic = false;
      };

      // 1. Cookies Spy
      const cookiesProxy = createBailoutProxy({}, "Cookies", markAsDynamic);

      // 2. Headers Spy
      // Note: req.headers usually comes from arguments or mocks
      const headersProxy = createBailoutProxy({}, "Headers", markAsDynamic);

      // 3. (Optional) Query/SearchParams Spy
      // If user reads ?id=5, it shouldn't be static either (usually)
      const queryProxy = createBailoutProxy({}, "Query", markAsDynamic);
      // {
      //           "user-agent": "Dinou-SSG-Builder",
      //           host: "localhost",
      //           // Add any default header you need here
      //         }
      // ====================================================================
      // 2. MOCK REQ: Fulfilling RequestContextStore['req']
      // ====================================================================
      const unifiedEnv = createUnifiedEnv();
      const mockReq = {
        query: queryProxy,
        cookies: cookiesProxy,
        headers: headersProxy,
        path: reqPath,
        method: "GET",
        env: unifiedEnv,
        ctx: null,
      };

      // 3. FULL CONTEXT
      mockContext = {
        req: mockReq,
        res: mockRes,
        env: unifiedEnv,
        ctx: null,
        _markDynamic: markAsDynamic,
        _hasRedirected: false,
      };

      let revalidate;
      let cacheTags = [];
      let capturedHoles = [];
      let hasDynamicLayout = false;
      let pageOnlyStatic = false;
      let pageCapturedHoles = [];
      const jsx = await requestStorage.run(mockContext, async () => {
        const [pagePath] = getFilePathAndDynamicParams(
          segments,
          {},
          folderPath,
          "page",
          true,
          true,
          undefined,
          segments.length,
        );
        const pageModule = await importModule(pagePath);
        const Page = pageModule.default ?? pageModule;

        let props = { params };

        const [pageFunctionsPath] = getFilePathAndDynamicParams(
          segments,
          {},
          folderPath,
          "page_functions",
          true,
          true,
          undefined,
          segments.length,
        );

        let pageFunctionsProps;

        if (pageFunctionsPath) {
          const pageFunctionsModule = await importModule(pageFunctionsPath);
          const defMod = pageFunctionsModule.default?.default ? pageFunctionsModule.default.default : pageFunctionsModule.default;
          const getProps = pageFunctionsModule.getProps || defMod?.getProps;
          revalidate = pageFunctionsModule.revalidate ?? defMod?.revalidate;
          const rawTags = pageFunctionsModule.getCacheTags ?? defMod?.getCacheTags;
          if (typeof rawTags === "function") {
            try {
              cacheTags = await rawTags(params);
            } catch (e) {
              console.error("Error running getCacheTags in buildStaticPages:", e);
            }
          } else if (Array.isArray(rawTags)) {
            cacheTags = rawTags;
          }
          pageFunctionsProps = await getProps?.(params);
          if (mockRes._redirectUrl || mockContext._hasRedirected) {
            return null;
          }
          props = { ...props, ...(pageFunctionsProps ?? {}) };
        }

        // Phase A: Probe ONLY the Page segment first so a dynamic ancestor layout
        // (or a dynamic layout's @slot reading cookies/headers/query) never prevents
        // pre-rendering a static/PPR Page's isolated `page.rsc` / `shell.page.json`.
        const rawPageElement = markPageRootElement(
          { ...React.createElement(Page, props), __modulePath: pagePath },
          Boolean(pageEffectivePpr),
        );
        await runWithPprContext({ isPpr: Boolean(pageEffectivePpr) }, async () => {
          resetPprHoles();
          await asyncRenderJSXToClientJSX(rawPageElement);
          pageCapturedHoles = pageEffectivePpr ? getRegisteredHoles() : [];
        });
        if (!isStatic) {
          return null;
        }
        if (mockRes._redirectUrl || mockContext._hasRedirected) {
          return null;
        }
        pageOnlyStatic = true;

        return await runWithPprContext({ isPpr: Boolean(pageIsPpr) }, async () => {
          // Wrap layouts around a lightweight placeholder instead of re-rendering `Page`
          // a second time (Page was already probed once in Phase A above).
          const noLayoutPath = path.join(folderPath, "no_layout");
          if (existsSync(noLayoutPath)) {
            capturedHoles = pageIsPpr ? pageCapturedHoles : [];
            return null;
          }

          let jsx = createLayoutChildrenPlaceholder();
          const layouts = getFilePathAndDynamicParams(
            segments,
            {},
            srcFolder,
            "layout",
            true,
            false,
            undefined,
            0,
            {},
            true,
          );

          if (!layouts || !Array.isArray(layouts) || layouts.length === 0) {
            capturedHoles = pageIsPpr ? pageCapturedHoles : [];
            return null;
          }

          if (layouts && Array.isArray(layouts)) {
            let index = 0;
            for (const [layoutPath, dParams, slots] of layouts.reverse()) {
              const layoutConfig = await resolveLayoutFunctionsConfig(layoutPath, dParams);
              if (layoutConfig.isDynamic) {
                hasDynamicLayout = true;
              }
              const layoutModule = await importModule(layoutPath);
              const Layout = layoutModule.default ?? layoutModule;
              const layoutFolderPath = path.dirname(layoutPath);
              const resetLayoutPath = getFilePathAndDynamicParams(
                [],
                {},
                layoutFolderPath,
                "reset_layout",
                false,
              )[0];
              const normLayoutPath = layoutPath.replace(/\\/g, "/");
              const layoutEffectivePpr = layoutPprMap?.has(normLayoutPath)
                ? Boolean(layoutPprMap.get(normLayoutPath))
                : Boolean(pageIsPpr);
              const updatedSlots = {};
              for (const [slotName, slotValue] of Object.entries(slots)) {
                let updatedSlotElement;
                const slotFilePath = slotValue?.slotPath || slotValue?.props?.__modulePath;
                const slotParams = slotValue?.slotParams || slotValue?.props?.params || {};

                try {
                  let elementToRender;
                  if (slotValue && slotValue.slotPath) {
                    const slotModule = await importModule(slotValue.slotPath);
                    const Slot = slotModule.default ?? slotModule;
                    elementToRender = React.createElement(Slot, {
                      params: slotParams,
                      key: slotName,
                      __modulePath: slotValue.slotPath,
                    });
                  } else {
                    elementToRender = {
                      ...slotValue,
                      __modulePath: slotFilePath ?? null,
                    };
                  }
                  elementToRender = markLayoutRootElement(
                    elementToRender,
                    layoutEffectivePpr,
                  );
                  await asyncRenderJSXToClientJSX(elementToRender);
                  updatedSlotElement = elementToRender;
                } catch (e) {
                  if (slotFilePath) {
                    const realSlotFolder = path.dirname(slotFilePath);
                    const [slotErrorPath, slotErrorParams] =
                      getFilePathAndDynamicParams(
                        segments,
                        {},
                        realSlotFolder,
                        "error",
                        true,
                        true,
                        undefined,
                        segments.length,
                        slotParams,
                      );

                    if (slotErrorPath) {
                      const slotErrorModule = await importModule(slotErrorPath);
                      const SlotError = slotErrorModule.default ?? slotErrorModule;

                      const serializedError = {
                        message: e.message || "Unknown Error",
                        name: e.name,
                        stack: process.env.NODE_ENV !== "production" ? e.stack : undefined,
                      };

                      updatedSlotElement = React.createElement(SlotError, {
                        params: slotErrorParams,
                        key: slotName,
                        error: serializedError,
                      });
                    } else {
                      console.warn(
                        `[Dinou Build] Slot @${slotName} failed and does not have error.tsx`,
                      );
                      updatedSlotElement = null;
                    }
                  } else {
                    console.error(
                      `[Dinou Build] Slot @${slotName} failed and has no module path`,
                    );
                    updatedSlotElement = null;
                  }
                }
                updatedSlots[slotName] = updatedSlotElement;
                if (mockRes._redirectUrl || mockContext._hasRedirected) {
                  return null;
                }
              }
              const layoutProps = await getLayoutProps(layoutPath, dParams);
              if (mockRes._redirectUrl || mockContext._hasRedirected) {
                return null;
              }
              let props = {
                params: dParams,
                ...updatedSlots,
                ...(layoutProps ?? {}),
              };
              jsx = markLayoutRootElement(
                { ...React.createElement(Layout, props, jsx), __modulePath: layoutPath },
                layoutEffectivePpr,
              );
              if (resetLayoutPath) {
                break;
              }
              index++;
            }
          }

          // Render ONLY the layout chain (with placeholder for children) and combine shifted page holes
          resetPprHoles();
          const renderedLayoutOnlyJsx = await asyncRenderJSXToClientJSX(jsx);
          if (pageIsPpr) {
            const layoutHoles = getRegisteredHoles();
            const layoutOffset = Number(getPprHoleCounter() || 0);
            const shiftHole = (h) => {
              if (!layoutOffset) return h;
              if (typeof h === "string") {
                const m = h.match(/^ppr-hole-(\d+)$/);
                return m ? `ppr-hole-${Number(m[1]) + layoutOffset}` : h;
              }
              if (h && typeof h === "object" && typeof h.id === "string") {
                const m = h.id.match(/^ppr-hole-(\d+)$/);
                return m ? { ...h, id: `ppr-hole-${Number(m[1]) + layoutOffset}` } : h;
              }
              return h;
            };
            capturedHoles = [...layoutHoles, ...pageCapturedHoles.map(shiftHole)];
          } else {
            capturedHoles = [];
          }
          return renderedLayoutOnlyJsx;
        });
      });

      const layoutBailedOut = pageOnlyStatic && (!isStatic || hasDynamicLayout);
      if (!isStatic && !pageOnlyStatic) {
        // ❌ DO NOT save file.
        // Will behave as pure SSR at runtime.
        if (process.env.DINOU_DEBUG) {
          console.log(
            `Skipping static generation for ${segments.join(
              "/",
            )} due to dynamic usage.`,
          );
        }
        continue;
      }

      const sideEffects = layoutBailedOut
        ? { redirect: null, cookies: [] }
        : {
            redirect: mockRes._redirectUrl,
            cookies: mockRes._cookies,
          };

      const resolvedRevalidate =
        typeof revalidate === "function" ? await revalidate(params) : revalidate;
      const effectiveIsPpr = layoutBailedOut
        ? Boolean(pageEffectivePpr)
        : Boolean(pageIsPpr);
      const holes = layoutBailedOut
        ? pageEffectivePpr
          ? pageCapturedHoles
          : []
        : pageIsPpr
        ? capturedHoles
        : [];
      staticRoutes.add(reqPath);
      staticMetadata.set(reqPath, {
        revalidate: resolvedRevalidate,
        pageRevalidate: resolvedRevalidate,
        effects: sideEffects,
        tags: cacheTags,
        ppr: effectiveIsPpr,
        pagePpr: Boolean(pageEffectivePpr),
        hasDynamicLayout: Boolean(layoutBailedOut),
        holes,
      });
      if (process.env.DINOU_DEBUG) {
        console.log(
          `Registered static page at ${reqPath}${effectiveIsPpr ? " (PPR)" : ""}${layoutBailedOut ? " (page-only under dynamic layout)" : ""}`
        );
      }
    } catch (err) {
      console.error(`Error building page ${segments.join("/")}:`, err);
      continue;
    }
  }

  if (process.env.DINOU_DEBUG) {
    console.log(`Static site generated with ${pages.length} pages`);
  }
}

/**
 * Renders and compiles a single page dynamically on-demand at runtime.
 * Used for Incremental Static Regeneration (ISR) or on-demand page generation.
 * Follows the same bailout detection and RSC serialization logic as the build compiler.
 */
async function buildStaticPage(reqPath, isDynamic = null) {
  const srcFolder = path.resolve(process.cwd(), "src");

  try {
    const segments = reqPath.split("/").filter(Boolean);
    const [resolvedPagePath, resolvedParams] = getFilePathAndDynamicParams(
      segments,
      {},
      srcFolder,
      "page",
      true,
      true,
    );
    if (!resolvedPagePath) {
      throw new Error(`No matching route found for ${reqPath}`);
    }
    const folderPath = path.dirname(resolvedPagePath);
    const dynamicParams = resolvedParams || {};
    // ====================================================================
    // 1. MOCK RES: Fulfilling the ResponseProxy interface
    // ====================================================================
    // Although the contract says it returns void, internally we save
    // the state in case you want to log errors (e.g., a redirect at build time).
    let mockContext;
    const mockRes = {
      _statusCode: 200,
      _headers: {},
      _redirectUrl: null,
      _cookies: [], // Optional: for debug

      // 👇 ADD THIS METHOD
      cookie(name, value, options) {
        // In SSG we don't do anything real, but we save a record if you want to debug
        // console.log(`[SSG] Cookie set ignored: ${name}=${value}`);
        this._cookies.push({ name, value, options, isClear: false });
      },

      clearCookie(name, options) {
        this._cookies.push({ name, value: "", options, isClear: true });
      },

      // setHeader(name: string, value: string | ReadonlyArray<string>): void;
      setHeader(name, value) {
        this._headers[name.toLowerCase()] = value;
      },

      // status(code: number): void;
      status(code) {
        this._statusCode = code;
      },

      // redirect(status: number, url: string): void;
      // redirect(url: string): void;
      redirect(arg1, arg2) {
        let status = 302;
        let url = "";

        if (typeof arg1 === "number") {
          status = arg1;
          url = arg2;
        } else {
          url = arg1;
        }

        this._statusCode = status;
        this._redirectUrl = url;
        if (mockContext) mockContext._hasRedirected = true;

        // We log a warning because a redirect in SSG is usually problematic
        if (process.env.DINOU_DEBUG) {
          console.warn(
            `⚠️ [SSG] Redirect detected in ${reqPath} -> ${url} (${status})`,
          );
        }
      },
    };

    let isStatic = true;
    const markAsDynamic = () => {
      isStatic = false;
    };

    // 1. Spy on Cookies
    const cookiesProxy = createBailoutProxy({}, "Cookies", markAsDynamic);

    // 2. Spy on Headers
    // Note: req.headers usually come from the arguments or mocks
    const headersProxy = createBailoutProxy({}, "Headers", markAsDynamic);

    // 3. (Optional) Spy on Query/SearchParams
    // If the user reads ?id=5, it shouldn't be static either (normally)
    const queryProxy = createBailoutProxy({}, "Query", markAsDynamic);
    //  {
    //         "user-agent": "Dinou-SSG-Builder",
    //         host: "localhost",
    //         // Add here any default header you need
    //       }
    // ====================================================================
    // 2. MOCK REQ: Fulfilling RequestContextStore['req']
    // ====================================================================
    const mockReq = {
      query: queryProxy,
      cookies: cookiesProxy,
      headers: headersProxy,
      path: reqPath,
      method: "GET",
    };

    // 3. COMPLETE CONTEXT
    mockContext = {
      req: mockReq,
      res: mockRes,
      _markDynamic: markAsDynamic,
      _hasRedirected: false,
    };

    let revalidate;
    let cacheTags = [];
    let pageIsPpr = false;
    let pageEffectivePpr = false;
    let capturedHoles = [];
    const jsx = await requestStorage.run(mockContext, async () => {
      const [pagePath, dParams] = getFilePathAndDynamicParams(
        segments,
        {},
        folderPath,
        "page",
        true,
        true,
        undefined,
        segments.length,
        dynamicParams,
      );
      if (!pagePath) throw new Error(`No page found for ${reqPath}`);

      const pageModule = await importModule(pagePath);
      const Page = pageModule.default ?? pageModule;
      const [pageFunctionsPath] = getFilePathAndDynamicParams(
        segments,
        {},
        folderPath,
        "page_functions",
        true,
        true,
        undefined,
        segments.length,
      );

      const pprInfo = await resolveBuildPprForRoute(segments, pagePath, pageFunctionsPath, srcFolder);
      pageIsPpr = pprInfo.isRoutePpr;
      pageEffectivePpr = pprInfo.pageEffectivePpr;
      const layoutPprMap = pprInfo.layoutPprMap;

      return await runWithPprContext({ isPpr: pageIsPpr }, async () => {
        let props = { params: dParams };

        let pageFunctionsProps;
        if (pageFunctionsPath) {
          const pageFunctionsModule = await importModule(pageFunctionsPath);
          const defMod = pageFunctionsModule.default?.default ? pageFunctionsModule.default.default : pageFunctionsModule.default;
          const getProps = pageFunctionsModule.getProps || defMod?.getProps;
          revalidate = pageFunctionsModule.revalidate ?? defMod?.revalidate;
          if (await isDynamicRoute(revalidate, dParams)) {
            markAsDynamic();
            if (isDynamic) isDynamic.value = true;
            return null;
          }
          const rawTags = pageFunctionsModule.getCacheTags ?? defMod?.getCacheTags;
          if (typeof rawTags === "function") {
            try {
              cacheTags = await rawTags(dParams);
            } catch (e) {
              console.error("Error running getCacheTags:", e);
            }
          } else if (Array.isArray(rawTags)) {
            cacheTags = rawTags;
          }
          pageFunctionsProps = await getProps?.(dParams);
          if (mockRes._redirectUrl || mockContext._hasRedirected) {
            return null;
          }
          props = { ...props, ...(pageFunctionsProps ?? {}) };
        }

        let jsx = markPageRootElement(
          { ...React.createElement(Page, props), __modulePath: pagePath },
          Boolean(pageEffectivePpr),
        );

        const noLayoutPath = path.join(folderPath, "no_layout");
        if (!existsSync(noLayoutPath)) {
          const layouts = getFilePathAndDynamicParams(
            segments,
            {},
            srcFolder,
            "layout",
            true,
            false,
            undefined,
            0,
            {},
            true,
          );
          if (layouts && Array.isArray(layouts)) {
            let index = 0;
            for (const [layoutPath, dParams, slots] of layouts.reverse()) {
              const layoutModule = await importModule(layoutPath);
              const Layout = layoutModule.default ?? layoutModule;
              const layoutFolderPath = path.dirname(layoutPath);
              const resetLayoutPath = getFilePathAndDynamicParams(
                [],
                {},
                layoutFolderPath,
                "reset_layout",
                false,
              )[0];
              const normLayoutPath = layoutPath.replace(/\\/g, "/");
              const layoutEffectivePpr = layoutPprMap?.has(normLayoutPath)
                ? Boolean(layoutPprMap.get(normLayoutPath))
                : Boolean(pageIsPpr);
              const updatedSlots = {};
              for (const [slotName, slotValue] of Object.entries(slots)) {
                let updatedSlotElement;
                const slotFilePath = slotValue?.slotPath || slotValue?.props?.__modulePath;
                const slotParams = slotValue?.slotParams || slotValue?.props?.params || {};

                try {
                  let elementToRender;
                  if (slotValue && slotValue.slotPath) {
                    const slotModule = await importModule(slotValue.slotPath);
                    const Slot = slotModule.default ?? slotModule;
                    elementToRender = React.createElement(Slot, {
                      params: slotParams,
                      key: slotName,
                      __modulePath: slotValue.slotPath,
                    });
                  } else {
                    elementToRender = {
                      ...slotValue,
                      __modulePath: slotFilePath ?? null,
                    };
                  }
                  elementToRender = markLayoutRootElement(
                    elementToRender,
                    layoutEffectivePpr,
                  );
                  await asyncRenderJSXToClientJSX(elementToRender);
                  updatedSlotElement = elementToRender;
                } catch (e) {
                  if (slotFilePath) {
                    const realSlotFolder = path.dirname(slotFilePath);
                    const [slotErrorPath, slotErrorParams] =
                      getFilePathAndDynamicParams(
                        segments,
                        {},
                        realSlotFolder,
                        "error",
                        true, // withExtension
                        true, // finalDestination
                        undefined, // lastFound
                        segments.length,
                        slotParams,
                      );

                    if (slotErrorPath) {
                      const slotErrorModule = await importModule(slotErrorPath);
                      const SlotError = slotErrorModule.default ?? slotErrorModule;

                      const serializedError = {
                        message: e.message || "Unknown Error",
                        name: e.name,
                        stack: process.env.NODE_ENV !== "production" ? e.stack : undefined,
                      };

                      updatedSlotElement = React.createElement(SlotError, {
                        params: slotErrorParams,
                        key: slotName,
                        error: serializedError,
                      });
                    } else {
                      console.warn(
                        `[Dinou Build] Slot @${slotName} failed and does not have error.tsx`,
                      );
                      updatedSlotElement = null;
                    }
                  } else {
                    console.error(
                      `[Dinou Build] Slot @${slotName} failed and has no module path`,
                    );
                    updatedSlotElement = null;
                  }
                }
                updatedSlots[slotName] = updatedSlotElement;
                if (mockRes._redirectUrl || mockContext._hasRedirected) {
                  return null;
                }
              }
              let layoutProps = {
                params: dParams,
                ...updatedSlots,
              };
              const customLayoutProps = await getLayoutProps(layoutPath, dParams);
              if (mockRes._redirectUrl || mockContext._hasRedirected) {
                return null;
              }
              layoutProps = {
                ...layoutProps,
                ...(customLayoutProps ?? {}),
              };
              jsx = markLayoutRootElement(
                { ...React.createElement(Layout, layoutProps, jsx), __modulePath: layoutPath },
                layoutEffectivePpr,
              );
              if (resetLayoutPath) {
                break;
              }
              index++;
            }
          }
        }

        resetPprHoles();
        const renderedSingleJsx = await asyncRenderJSXToClientJSX(jsx);
        capturedHoles = pageIsPpr ? getRegisteredHoles() : [];
        return renderedSingleJsx;
      });
    });

    if (!isStatic) {
      // ❌ DO NOT save file.
      // It will behave as pure SSR at runtime.
      if (process.env.DINOU_DEBUG) {
        console.log(
          `Skipping static generation for ${segments.join(
            "/",
          )} due to dynamic usage.`,
        );
      }
      if (isDynamic) {
        isDynamic.value = true;
      }
      return;
    }

    const sideEffects = {
      redirect: mockRes._redirectUrl,
      cookies: mockRes._cookies,
    };

    const holes = pageIsPpr ? capturedHoles : [];
    staticRoutes.add(reqPath);
    staticMetadata.set(reqPath, {
      revalidate: typeof revalidate === "function" ? await revalidate(dynamicParams) : revalidate,
      effects: sideEffects,
      tags: cacheTags,
      ppr: pageIsPpr,
      pagePpr: Boolean(pageEffectivePpr),
      holes,
    });
    console.warn(`Registered rebuilt static page at ${reqPath}${pageIsPpr ? " (PPR)" : ""}`);
  } catch (error) {
    console.error(`Error building page ${reqPath}:`, error);
    throw error;
  }
}

function getStaticPaths() {
  return Array.from(staticRoutes);
}

function getStaticMetadata(reqPath) {
  if (!reqPath) return null;
  const noSlash = reqPath.endsWith("/") ? reqPath.slice(0, -1) : reqPath;
  const withSlash = noSlash + "/";
  return staticMetadata.get(reqPath) || staticMetadata.get(noSlash) || staticMetadata.get(withSlash) || null;
}

function getStaticLayouts() {
  return Array.from(staticLayouts.values());
}

export {
  buildStaticPages,
  buildStaticPage,
  getStaticPaths,
  getStaticMetadata,
  getStaticLayouts,
  isDynamicRoute,
};
export default {
  buildStaticPages,
  buildStaticPage,
  getStaticPaths,
  getStaticMetadata,
  getStaticLayouts,
  isDynamicRoute,
};

