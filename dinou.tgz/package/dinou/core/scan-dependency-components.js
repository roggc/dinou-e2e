// dinou/core/scan-dependency-components.js
// Scans dependencies for React "use client" directives without recursively walking massive trees.

import fs from "node:fs";
import path from "node:path";

function isSupportedClientModule(filePath, content) {
  const norm = filePath.replace(/\\/g, "/");
  if (!norm.includes("node_modules")) return true;
  if (content === undefined && fs.existsSync(filePath)) {
    try {
      content = fs.readFileSync(filePath, "utf8");
    } catch (e) {
      return false;
    }
  }
  if (typeof content !== "string") return false;
  if (content.includes("System.register(") || content.includes("System.registerDynamic(")) return false;
  if (content.includes("define.amd") && !content.includes("export ") && !content.includes("module.exports")) return false;
  return true;
}

function scanDependencyForClientComponents(depDir, clientFiles, useClientRegex) {
  const pkgJsonPath = path.join(depDir, "package.json");
  if (!fs.existsSync(pkgJsonPath)) return;
  let depPkg;
  try {
    depPkg = JSON.parse(fs.readFileSync(pkgJsonPath, "utf8"));
  } catch (e) {
    return;
  }

  const depName = depPkg.name || "";
  const hasReact =
    depPkg.dependencies?.react ||
    depPkg.peerDependencies?.react ||
    depPkg.devDependencies?.react ||
    (Array.isArray(depPkg.keywords) && depPkg.keywords.includes("react")) ||
    depName.toLowerCase().includes("react");
  if (!hasReact) return;

  const candidateFiles = new Set();
  if (typeof depPkg.main === "string") candidateFiles.add(path.resolve(depDir, depPkg.main));
  if (typeof depPkg.module === "string") candidateFiles.add(path.resolve(depDir, depPkg.module));
  if (depPkg.exports) {
    function addExport(exp) {
      if (typeof exp === "string") {
        if (/\.[jt]sx?$/.test(exp)) candidateFiles.add(path.resolve(depDir, exp));
      } else if (typeof exp === "object" && exp !== null) {
        for (const v of Object.values(exp)) addExport(v);
      }
    }
    addExport(depPkg.exports);
  }

  try {
    const rootEntries = fs.readdirSync(depDir, { withFileTypes: true });
    for (const entry of rootEntries) {
      if (!entry.isDirectory() && /\.[jt]sx?$/.test(entry.name)) {
        candidateFiles.add(path.join(depDir, entry.name));
      }
    }
  } catch (e) {}

  for (const filePath of candidateFiles) {
    if (!fs.existsSync(filePath)) continue;
    try {
      const content = fs.readFileSync(filePath, "utf8");
      if (useClientRegex.test(content.trim()) && isSupportedClientModule(filePath, content)) {
        clientFiles.add(path.resolve(filePath));
      }
    } catch (e) {}
  }
}

function scanProjectDependenciesForClientComponents(projectRoot, clientFiles, useClientRegex) {
  try {
    const pkgPath = path.resolve(projectRoot, "package.json");
    if (!fs.existsSync(pkgPath)) return;

    // Cache check based on package-lock.json or package.json
    const cacheDir = path.resolve(projectRoot, ".dinou");
    const cacheFile = path.join(cacheDir, "deps-client-cache.json");

    const lockPath = path.resolve(projectRoot, "package-lock.json");
    const targetLock = fs.existsSync(lockPath) ? lockPath : pkgPath;
    let lockStat;
    try {
      lockStat = fs.statSync(targetLock);
    } catch (e) {}

    const signature = lockStat ? `${lockStat.size}-${Math.round(lockStat.mtimeMs)}` : null;

    if (signature && fs.existsSync(cacheFile)) {
      try {
        const cache = JSON.parse(fs.readFileSync(cacheFile, "utf8"));
        if (cache.signature === signature && Array.isArray(cache.clientFiles)) {
          let allExist = true;
          for (const f of cache.clientFiles) {
            if (!fs.existsSync(f)) {
              allExist = false;
              break;
            }
          }
          if (allExist) {
            for (const f of cache.clientFiles) {
              clientFiles.add(path.resolve(f));
            }
            return;
          }
        }
      } catch (e) {}
    }

    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
    const deps = Object.keys(pkg.dependencies || {});
    for (const dep of deps) {
      if (dep === "react" || dep === "react-dom" || dep === "dinou") continue;
      const depDir = path.resolve(projectRoot, "node_modules", dep);
      if (fs.existsSync(depDir)) {
        scanDependencyForClientComponents(depDir, clientFiles, useClientRegex);
      }
    }

    // Save discovered files to cache
    if (signature) {
      try {
        if (!fs.existsSync(cacheDir)) {
          fs.mkdirSync(cacheDir, { recursive: true });
        }
        const discovered = [];
        for (const f of clientFiles) {
          const norm = f.replace(/\\/g, "/");
          if (norm.includes("/node_modules/")) {
            discovered.push(f);
          }
        }
        fs.writeFileSync(cacheFile, JSON.stringify({ signature, clientFiles: discovered }), "utf8");
      } catch (e) {}
    }
  } catch (e) {}
}

async function scanProjectDependenciesForClientComponentsAsync(projectRoot, clientFiles, useClientRegex) {
  try {
    const pkgPath = path.resolve(projectRoot, "package.json");
    if (!fs.existsSync(pkgPath)) return;

    // Cache check based on package-lock.json or package.json
    const cacheDir = path.resolve(projectRoot, ".dinou");
    const cacheFile = path.join(cacheDir, "deps-client-cache.json");

    const lockPath = path.resolve(projectRoot, "package-lock.json");
    const targetLock = fs.existsSync(lockPath) ? lockPath : pkgPath;
    let lockStat;
    try {
      lockStat = fs.statSync(targetLock);
    } catch (e) {}

    const signature = lockStat ? `${lockStat.size}-${Math.round(lockStat.mtimeMs)}` : null;

    if (signature && fs.existsSync(cacheFile)) {
      try {
        const cache = JSON.parse(fs.readFileSync(cacheFile, "utf8"));
        if (cache.signature === signature && Array.isArray(cache.clientFiles)) {
          let allExist = true;
          for (const f of cache.clientFiles) {
            if (!fs.existsSync(f)) {
              allExist = false;
              break;
            }
          }
          if (allExist) {
            for (const f of cache.clientFiles) {
              clientFiles.add(path.resolve(f));
            }
            return;
          }
        }
      } catch (e) {}
    }

    const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
    const deps = Object.keys(pkg.dependencies || {});
    for (const dep of deps) {
      if (dep === "react" || dep === "react-dom" || dep === "dinou") continue;
      const depDir = path.resolve(projectRoot, "node_modules", dep);
      if (fs.existsSync(depDir)) {
        scanDependencyForClientComponents(depDir, clientFiles, useClientRegex);
        await new Promise((resolve) => setImmediate(resolve));
      }
    }

    // Save discovered files to cache
    if (signature) {
      try {
        if (!fs.existsSync(cacheDir)) {
          fs.mkdirSync(cacheDir, { recursive: true });
        }
        const discovered = [];
        for (const f of clientFiles) {
          const norm = f.replace(/\\/g, "/");
          if (norm.includes("/node_modules/")) {
            discovered.push(f);
          }
        }
        fs.writeFileSync(cacheFile, JSON.stringify({ signature, clientFiles: discovered }), "utf8");
      } catch (e) {}
    }
  } catch (e) {}
}

export {
  isSupportedClientModule,
  scanDependencyForClientComponents,
  scanProjectDependenciesForClientComponents,
  scanProjectDependenciesForClientComponentsAsync,
};
export default {
  isSupportedClientModule,
  scanDependencyForClientComponents,
  scanProjectDependenciesForClientComponents,
  scanProjectDependenciesForClientComponentsAsync,
};
