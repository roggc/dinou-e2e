import path from "node:path";
import fs from "node:fs";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { isUnvendorizedRequested } from "../core/ensure-vendor-mode.js";
import esbuild from "esbuild";
import postcss from "#rollup-plugin-postcss";
import {
  createBasePostCssPlugins,
  getRegisteredCssUrlAssets,
} from "../core/postcss-pipeline.js";
import babelModule from "#rollup/plugin-babel";
import resolveModule from "#rollup/plugin-node-resolve";
import commonjs from "#rollup/plugin-commonjs";
import {
  copyStaticDirectoriesToOutdir,
  hasPublicStylesCss,
  warnPublicStylesCssCollision,
} from "../core/copy-static-dirs.js";
import reactClientManifest from "./rollup-plugins/rollup-plugin-react-client-manifest.js";
import createScopedName from "../core/createScopedName.js";
import replace from "#rollup/plugin-replace";
import json from "#rollup/plugin-json";
import reactRefreshWrapModules from "./react-refresh/react-refresh-wrap-modules.js";
import { esmHmrPlugin } from "./react-refresh/rollup-plugin-esm-hmr.js";
import dinouAssetPlugin from "./rollup-plugins/dinou-asset-plugin.js";
import { rollupTsconfigAliasesPlugin } from "../core/tsconfig-aliases.js";
import serverFunctionsPlugin from "./rollup-plugins/rollup-plugin-server-functions.js";
import { getAssetExtensionsInfo } from "../core/asset-extensions.js";
import manifestGeneratorPlugin from "./rollup-plugins/manifest-generator-plugin.js";
import rollupMemoryPlugin from "./rollup-plugins/rollup-plugin-memory.js";
import rollupSwcPlugin from "./rollup-plugins/rollup-plugin-swc.js";
import { generateRouteTypes } from "../core/generate-route-types.js";
import { rollupContextualDinouPlugin } from "../core/resolve-contextual-dinou.js";
import { getDinouConfig } from "../core/load-dinou-config.js";
import {
  loadEnvFiles,
  getRollupPublicEnvReplacements,
} from "../core/env.js";
import presetReactModule from "#babel/preset-react";
import presetTypescriptModule from "#babel/preset-typescript";
import pluginSyntaxImportMetaModule from "#babel/plugin-syntax-import-meta";
import pluginReactCompilerModule from "#babel-plugin-react-compiler";

const unwrapBabel = (mod) => mod?.default ?? mod;
const presetReact = unwrapBabel(presetReactModule);
const presetTypescript = unwrapBabel(presetTypescriptModule);
const pluginSyntaxImportMeta = unwrapBabel(pluginSyntaxImportMetaModule);
const pluginReactCompiler = unwrapBabel(pluginReactCompilerModule);
const babel = babelModule?.default || babelModule;
const resolve = resolveModule?.default || resolveModule;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

const localDinouPath = path.resolve(process.cwd(), "dinou");
const isEjected = fs.existsSync(localDinouPath);

console.log(
  isEjected
    ? "🚀 [Dinou] Ejected Mode detected (Using local code)"
    : "📦 [Dinou] Library Mode detected (Using node_modules)",
);

export default async function () {
  const isDevelopment = process.env.NODE_ENV !== "production";
  const envMode = isDevelopment ? "development" : "production";
  loadEnvFiles(process.cwd(), { mode: envMode });
  const { exactValues: rollupExactEnv, objectValues: rollupObjectEnv } =
    getRollupPublicEnvReplacements({ mode: envMode });
  const outputDirectory = isDevelopment ? ".dinou/public" : ".dinou/dist3";
  const shouldWriteToDisk = process.env.DINOU_WRITE_TO_DISK === "true" || !isDevelopment;
  if (!isDevelopment && shouldWriteToDisk) {
    try {
      fs.rmSync(path.resolve(process.cwd(), ".dinou/dist1"), {
        recursive: true,
        force: true,
      });
      fs.rmSync(path.resolve(process.cwd(), ".dinou/netlify"), {
        recursive: true,
        force: true,
      });
    } catch (e) {}
  }
  const serverFiles = new Set();
  const dinouConfig = await getDinouConfig();
  const enableReactCompiler = dinouConfig?.reactCompiler !== false;
  const { regex: activeAssetRegex } = getAssetExtensionsInfo(
    dinouConfig,
    process.cwd()
  );
  try {
    generateRouteTypes(process.cwd());
  } catch (e) {}
  const delModule = await import("#rollup-plugin-delete");
  const del = delModule?.default || delModule;
  const clientConfig = {
    input: isDevelopment
      ? {
        runtime: path.resolve(
          __dirname,
          "react-refresh/react-refresh-runtime.js",
        ),
        refresh: path.resolve(
          __dirname,
          "react-refresh/react-refresh-entry.js",
        ),
        main: path.resolve(__dirname, "../core/client.jsx"),
        serverFunctionProxy: path.resolve(
          __dirname,
          "../core/server-function-proxy.js",
        ),
        dinouClientRedirect: path.resolve(
          __dirname,
          "../core/client-redirect.jsx",
        ),
        dinouLink: path.resolve(
          __dirname,
          "../core/link.jsx",
        ),
        dinouSlot: path.resolve(
          __dirname,
          "../core/slot.js",
        ),
      }
      : {
        main: path.resolve(__dirname, "../core/client.jsx"),
        serverFunctionProxy: path.resolve(
          __dirname,
          "../core/server-function-proxy.js",
        ),
        dinouClientRedirect: path.resolve(
          __dirname,
          "../core/client-redirect.jsx",
        ),
        dinouLink: path.resolve(
          __dirname,
          "../core/link.jsx",
        ),
        dinouSlot: path.resolve(
          __dirname,
          "../core/slot.js",
        ),
      },
    output: {
      dir: outputDirectory,
      format: "esm",
      entryFileNames: isDevelopment ? "[name].js" : "[name]-[hash].js",
      chunkFileNames: (chunkInfo) => {
        if (!isDevelopment) return "[name]-[hash].js";
        const moduleIds =
          chunkInfo.moduleIds || Object.keys(chunkInfo.modules || {});
        if (moduleIds.length === 0) return "[name].js";
        const isVendor = moduleIds.every(
          (id) =>
            id.includes("node_modules") ||
            id.includes("\0") ||
            id.includes("commonjsHelpers")
        );
        if (isVendor) {
          return "[name]-[hash].js";
        }
        return "[name].js";
      },
      // 🛑 THE MAGIC SOLUTION 👇
      // Defaults to 'true' in some cases.
      // By setting it to 'false', you force Rollup to use the original exported
      // variable name instead of 'C', 'a', 'b', etc.
      minifyInternalExports: false,
    },
    // 🛑 ADD THIS MAGIC LINE
    // Tells Rollup: "Keep entry point signatures (export names) intact"
    preserveEntrySignatures: "strict",
    perf: isDevelopment,
    treeshake: isDevelopment ? false : true,
    external: [
      "/runtime.js",
      "/refresh.js",
      "/__hmr_client__.js",
      "/__SERVER_FUNCTION_PROXY__",
    ],
    plugins: [
      shouldWriteToDisk &&
        del({
          targets: [
            `${outputDirectory}/*`,
            ...(isDevelopment
              ? [
                  ".dinou/node-dev/react-client-manifest.json",
                  ".dinou/node-dev/server-functions-manifest.json",
                  ".dinou/node-dev/manifest.json",
                ]
              : []),
          ],
          runOnce: true,
          hook: "buildStart",
        }),
      rollupContextualDinouPlugin({ projectRoot: process.cwd() }),
      dinouAssetPlugin({
        include: activeAssetRegex,
        dinouConfig,
        projectRoot: process.cwd(),
      }),
      rollupTsconfigAliasesPlugin({
        projectRoot: process.cwd(),
        assetRegex: activeAssetRegex,
      }),
      replace({
        preventAssignment: true,
        values: rollupExactEnv,
      }),
      replace({
        preventAssignment: true,
        delimiters: ["(?<!\\.)\\b", "\\b"],
        values: rollupObjectEnv,
      }),
      json(),
      resolve({
        extensions: [".mjs", ".js", ".jsx", ".ts", ".tsx", ".cjs", ".json", ".css"],
        exportConditions: ["style"],
        browser: true,
        preferBuiltins: false,
      }),
      commonjs({
        include: isEjected ? [/node_modules/, /dinou/] : /node_modules/,
      }),
      isDevelopment
        ? rollupSwcPlugin()
        : babel({
            babelHelpers: "bundled",
            configFile: false,
            babelrc: false,
            extensions: [".js", ".jsx", ".ts", ".tsx"],
            presets: [
              [presetReact, { runtime: "automatic" }],
              presetTypescript,
            ],
            plugins: [
              enableReactCompiler && pluginReactCompiler,
              pluginSyntaxImportMeta,
            ].filter(Boolean),
            exclude: [
              /node_modules[\\/](?!dinou|react-refresh)/,
              /[\\/]dinou[\\/]compiled[\\/]/,
            ],
          }),
      postcss({
        modules: {
          generateScopedName: (name, filename) =>
            createScopedName(name, filename),
        },
        extract: "styles.css",
        minimize: !isDevelopment,
        plugins: createBasePostCssPlugins(),
        config: false,
      }),
      {
        name: "dinou-rollup-css-assets-and-minify",
        buildStart() {
          getRegisteredCssUrlAssets().clear();
          if (typeof globalThis !== "undefined") {
            globalThis.__DINOU_HAS_COMPILED_STYLES__ = false;
          }
        },
        generateBundle(_options, bundle) {
          const hasCompiledStyles = Boolean(bundle["styles.css"]);
          if (typeof globalThis !== "undefined") {
            globalThis.__DINOU_HAS_COMPILED_STYLES__ = hasCompiledStyles;
            if (!hasCompiledStyles && globalThis.__DINOU_MEM_FILES__) {
              globalThis.__DINOU_MEM_FILES__.delete("styles.css");
              globalThis.__DINOU_MEM_FILES__.delete("/styles.css");
            }
          }
          if (hasCompiledStyles && hasPublicStylesCss(process.cwd())) {
            warnPublicStylesCssCollision(process.cwd());
          }
          for (const [assetFileName, absAssetPath] of getRegisteredCssUrlAssets().entries()) {
            if (!bundle[assetFileName] && fs.existsSync(absAssetPath)) {
              try {
                this.emitFile({
                  type: "asset",
                  fileName: assetFileName,
                  source: fs.readFileSync(absAssetPath),
                });
              } catch (e) {}
            }
          }
          if (!isDevelopment && bundle["styles.css"]?.type === "asset") {
            try {
              const rawCss = Buffer.isBuffer(bundle["styles.css"].source)
                ? bundle["styles.css"].source.toString("utf8")
                : String(bundle["styles.css"].source || "");
              if (rawCss) {
                bundle["styles.css"].source = esbuild.transformSync(rawCss, {
                  loader: "css",
                  minify: true,
                }).code;
              }
            } catch (e) {}
          }
        },
      },
      shouldWriteToDisk && {
        name: "dinou-copy-static",
        writeBundle() {
          copyStaticDirectoriesToOutdir(process.cwd(), outputDirectory);
        },
      },
      reactClientManifest({
        manifestPath: path.join(
          isDevelopment ? ".dinou/node-dev" : ".dinou/dist1",
          "react-client-manifest.json",
        ),
        assetInclude: activeAssetRegex,
        dinouConfig,
        serverFiles,
      }),
      isDevelopment && reactRefreshWrapModules(),
      isDevelopment && esmHmrPlugin(),
      !isDevelopment && manifestGeneratorPlugin(),
      serverFunctionsPlugin({ serverFiles }),
      isDevelopment && rollupMemoryPlugin(),
      !isDevelopment && {
        name: "post-build-ssg",
        closeBundle() {
          const ssgArgs = [
            "--conditions=react-server",
            ...(isUnvendorizedRequested() ? ["--conditions=unvendorized"] : []),
            path.resolve(__dirname, "../core/run-ssg.js"),
          ];
          const ssgRes = spawnSync(process.execPath, ssgArgs, {
            stdio: "inherit",
            env: {
              ...process.env,
              NODE_ENV: "production",
              DINOU_BUILD_TOOL: "rollup",
            },
          });
          if (ssgRes.status !== 0) {
            throw new Error(
              `[Dinou SSG] Static generation exited with code ${ssgRes.status ?? 1}`
            );
          }
        },
      },
    ].filter(Boolean),
    watch: {
      buildDelay: 100,
      exclude: [
        /[\\/]node_modules[\\/]/,
        /[\\/]\.git[\\/]/,
        /[\\/]\.dinou[\\/]/,
        /[\\/]test-results[\\/]/,
        /[\\/]playwright-report[\\/]/,
        "**/node_modules/**",
        "**/.git/**",
        "**/.dinou/**",
        "**/test-results/**",
        "**/playwright-report/**",
      ],
    },
    onwarn(warning, warn) {
      if (warning.code === "CIRCULAR_DEPENDENCY" || warning.code === "THIS_IS_UNDEFINED") {
        return;
      }
      // Ignore eval warning if it comes from our request-context file
      if (warning.code === "EVAL") {
        // Optional: If you want to be very specific and only allow it in that file:
        if (warning.loc && warning.loc.file.includes("request-context.js")) {
          return;
        }
      }
      if (
        warning.message.includes(
          'Module level directives cause errors when bundled, "use client"',
        ) ||
        warning.message.includes(
          'Module level directives cause errors when bundled, "use server"',
        )
      ) {
        return;
      }
      warn(warning);
    },
  };

  return clientConfig;
};
